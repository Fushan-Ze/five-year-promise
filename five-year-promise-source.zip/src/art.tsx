import type { Person } from './content'
import { people } from './content'

const paths: Record<string,string> = {
  music:'M9 18V5l11-2v13M9 18a3 2 0 1 1-6 0 3 2 0 0 1 6 0Zm11-2a3 2 0 1 1-6 0 3 2 0 0 1 6 0ZM9 9l11-2',
  cross:'M9 3h6v6h6v6h-6v6H9v-6H3V9h6z', flag:'M5 21V3m0 1h14l-3 4 3 4H5',
  book:'M12 6C9 4 6 4 3 5v14c3-1 6-1 9 1 3-2 6-2 9-1V5c-3-1-6-1-9 1v14',
  moon:'M20 15.1A8.5 8.5 0 0 1 8.9 4 8.5 8.5 0 1 0 20 15.1Z',
  bolt:'m13 2-9 12h7l-1 8 10-12h-7l1-8z', heart:'M12 20 4.6 12.7C.2 8.2 6.3 2.7 10.3 6.4L12 8l1.7-1.6c4-3.7 10.1 1.8 5.7 6.3z',
  coin:'M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0ZM9 9l3 3 3-3m-5 4h4m-2-1v4',
  home:'m3 10 9-7 9 7v10h-6v-6H9v6H3z', flask:'M8 3h8m-6 0v7L4 19v2h16v-2l-6-9V3M7 15h10',
  cup:'M4 8h12v8a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4zm12 1h2a3 3 0 0 1 0 6h-2M8 3v2m4-2v2',
  map:'m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3zm6-3v15m6-12v15', people:'M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2m13-6a4 4 0 0 1 4 4v2M14 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0Zm3-3a4 4 0 0 1 0 7',
  medal:'m7 3 3 7m7-7-3 7m-2 0a5.5 5.5 0 1 1 0 11 5.5 5.5 0 0 1 0-11z', save:'M4 3h13l4 4v14H3V3zm3 0v6h10V3M7 21v-7h10v7',
  arrow:'M4 12h15m-6-6 6 6-6 6', chevron:'m9 5 7 7-7 7', play:'m8 4 13 8-13 8z',
  lock:'M5 11h14v10H5zM8 11V7a4 4 0 1 1 8 0v4m-4 4v2', close:'m5 5 14 14M19 5 5 19',
  star:'m12 2 3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z',
  compass:'M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-5-4-2 6-6 2 2-6z',
  journal:'M5 3h14v18H5zM8 3v18m3-13h5m-5 4h5', clock:'M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9-5v5l3 2',
  menu:'M4 6h16M4 12h16M4 18h16', check:'m4 12 5 5L20 6',
}
export function Icon({name, size=18}: {name:string; size?:number}) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.65" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={paths[name] ?? paths.star}/></svg>
}

function Pine({x,y,s=1}: {x:number;y:number;s?:number}) {
  return <g transform={`translate(${x} ${y}) scale(${s})`}>
    <path fill="#332943" d="M-2-10h5V2h-5z"/>
    <path fill="#263e4c" d="M-3-34h6v6h5v7h5v7h4v7h-34v-7h4v-7h5v-7h5z"/>
    <path fill="#41605a" d="M-3-34h6v6H0v7h-4v7h-5v6h-8v-6h4v-7h5v-7h5z"/>
    <path fill="#537268" d="M-8-21h4v4h-4zm-4 7h4v4h-4z"/>
  </g>
}

function Building({x,y,w,h, wall='#645575',roof='#493c62',lit='#ffd392', rows=2, cols=5, side=13}: {
  x:number;y:number;w:number;h:number;wall?:string;roof?:string;lit?:string;rows?:number;cols?:number;side?:number
}) {
  return <g transform={`translate(${x} ${y})`}>
    <path d={`M0 ${h}h${w+side}l11 7H11z`} fill="#24243c" opacity=".46"/>
    <path d={`M${w} 0l${side} -8v${h}l-${side} 8z`} fill={roof}/>
    <path d={`M-4 0l${side} -8h${w+8}l-${side} 8z`} fill={roof}/>
    <path d={`M0 0h${w}v${h}H0z`} fill={wall}/>
    <path d={`M-4 0h${w+8}v4H-4z`} fill={lit} opacity=".68"/>
    <path d={`M0 ${h-4}h${w}v4H0z`} fill="#413852"/>
    {Array.from({length:rows*cols}, (_,i) => {
      const dx = Math.round((i % cols + .5)*w/cols)-3
      const dy = Math.round((Math.floor(i/cols) + .7)*h/(rows+.4))
      return <g key={i}><path d={`M${dx-1} ${dy-1}h9v9h-9z`} fill="#4a3b62"/><path d={`M${dx} ${dy}h7v6h-7z`} fill={(i+cols)%5===1 ? '#7c7598':lit}/><path d={`M${dx+3} ${dy}h1v6h-1z`} fill={wall}/></g>
    })}
    <path d={`M${w/2-4} ${h-11}h8v11h-8z`} fill="#3d334e"/>
  </g>
}

export function HeroArt() {
  const clouds = [[13,31,97],[91,18,58],[310,28,113],[453,49,77],[205,44,40],[368,9,55]]
  const city = Array.from({length:32},(_,i) => ({x:i*20-10,h:8+(i*29)%31,w:11+(i*7)%11}))
  return <svg className="hero-art" viewBox="0 0 620 390" preserveAspectRatio="xMidYMid slice" role="img" aria-label="黄昏里的青禾医大像素校园">
    <defs>
      <linearGradient id="hero-sky" x2="0" y2="1"><stop stopColor="#332656"/><stop offset=".46" stopColor="#96688b"/><stop offset="1" stopColor="#efb695"/></linearGradient>
      <linearGradient id="hero-ground" x2="0" y2="1"><stop stopColor="#4d4861"/><stop offset="1" stopColor="#292c49"/></linearGradient>
      <linearGradient id="hero-road" x2="0" y2="1"><stop stopColor="#b786a0"/><stop offset="1" stopColor="#65607a"/></linearGradient>
    </defs>
    <rect width="620" height="216" fill="url(#hero-sky)"/>
    <path fill="#ffc4a5" opacity=".28" d="M0 118h620v5H0zm0 17h620v2H0zm0 23h620v3H0zm0 8h620v2H0z"/>
    <path fill="#ffd79b" d="M435 64h44v6h11v8h8v12h6v36h-6v12h-8v8h-11v6h-44v-6h-11v-8h-8v-12h-6V90h6V78h8v-8h11z"/>
    <path fill="#f2ab97" d="M410 111h94v4h-94zm0 11h94v3h-94zm6 12h82v3h-82zm12 10h59v3h-59z"/>
    {clouds.map(([x,y,w],i)=><g key={x} opacity=".5" transform={`translate(${x} ${y+43})`} fill={i%2?'#e5a3a3':'#c58fa4'}><path d={`M0 10h${w}v5H0zm12-5h${w-24}v5H12zm15-5h${w-36}v5H27z`}/><path d={`M3 19h${w-17}v2H3z`} /></g>)}
    <path d="M0 162h37v-7h38v-11h31v-5h39v5h30v8h35v8h50v-9h33v-12h36v-10h39v-6h53v7h36v11h39v12h47v-7h37v-12h40v66H0z" fill="#a87b93"/>
    <path d="M0 176h42v-6h56v-9h44v8h49v7h41v-5h62v-9h47v-8h44v-6h32v6h41v8h56v11h45v-7h61v47H0z" fill="#806482"/>
    {city.map(({x,h,w})=><path key={x} fill="#675570" d={`M${x} ${207-h}h${w}v${h}h-${w}z`}/>)}
    <path d="M0 207h620v183H0z" fill="url(#hero-ground)"/>
    <path d="M236 202h52l15 43h184l133 66v28L454 266H303l30 124H103l103-129H0v-19h221z" fill="url(#hero-road)"/>
    <path d="M225 244H0m291 4h192l137 68m-353-111 18 45-54 140m60-130 31 129" fill="none" stroke="#b3889e" strokeWidth="3" opacity=".65"/>
    <Building x={45} y={215} w={115} h={58} wall="#7b5d79" roof="#584969" cols={6} side={18}/>
    <Building x={168} y={187} w={71} h={45} wall="#766382" roof="#554968" cols={4}/>
    <Building x={307} y={198} w={166} h={63} wall="#856b85" roof="#5c4c6e" cols={8} side={20}/>
    <Building x={351} y={176} w={64} h={85} wall="#957789" roof="#685572" cols={3} rows={3} side={18}/>
    <path fill="#f5d3af" d="M380 184h7v19h-7zM374 190h19v7h-19z"/>
    <path fill="#55475f" d="M365 238h39v23h-39z"/><path fill="#ffcba1" opacity=".75" d="M371 243h27v18h-27z"/>
    <Building x={495} y={216} w={81} h={58} wall="#725e80" roof="#52466b" cols={4} side={17}/>
    <path fill="#4c405f" d="M368 292h154l63 26v24l-43 21H371l-42-20v-22z"/>
    <path fill="#aa6883" d="M374 295h146l57 24v20l-38 20H374l-39-18v-19z"/>
    <path fill="#564e68" d="M386 304h130l48 18v12l-34 16H387l-37-14v-11z"/>
    <path d="M381 300h138l51 21v16l-35 17H380l-37-16v-15z" fill="none" stroke="#ed9c9c" strokeWidth="1.5"/>
    <path d="M446 305v44m24-44v44" stroke="#77667e" strokeWidth="1"/>
    {[[20,260,1],[184,244,.8],[282,239,.65],[471,231,.75],[589,258,1.12],[30,319,1.25],[65,338,1.55],[109,315,.9],[163,305,.85],[320,315,1],[607,366,1.7],[563,380,1.4],[12,378,1.9]].map(([x,y,s])=><Pine key={x} x={x} y={y} s={s}/>)}
    <path fill="#2e293f" d="M0 379h75v-6h28v6h26v11H0zm483 9v-5h27v-8h17v5h42v-7h21v-9h30v26H483z"/>
    <path fill="#f5bb91" opacity=".8" d="M246 263h3v18h-3zm-3-2h9v3h-9zm44 37h3v22h-3zm-4-3h11v4h-11zm-96 35h3v21h-3zm-4-3h11v4h-11z"/>
    <path fill="#f2c59c" d="M242 316h3v3h-3zm16 13h3v3h-3zm-25 15h3v3h-3zm56 11h3v3h-3z"/>
  </svg>
}

export function MapArt() {
  return <svg className="map-art" viewBox="0 0 600 385" preserveAspectRatio="none" aria-hidden="true">
    <defs><pattern id="map-grid" width="12" height="12" patternUnits="userSpaceOnUse"><path d="M0 12V0h12" fill="none" stroke="#9ca0a9" opacity=".11"/></pattern></defs>
    <path fill="#343b51" d="M0 0h600v385H0z"/>
    <path fill="#464563" d="M0 0h600v37h-86v16h-71v-7h-69v-9h-68v13h-78V36H89v17H0z"/>
    <path fill="#3d5261" d="M0 209h63v18h46v39h-34v21H43v35H0zm600-66h-39v17h-21v37h22v25h38zm0 174h-62v20h-49v48h111z"/>
    <path fill="#56516d" d="M0 52h70v20h56V51h67v17h48v40h-34v43H90v32H0zm336-3h134v19h69v50h-48v34H367v-31h-31zm-113 112h142v54h-33v33h-98v-28h-31zm-99 61h71v43h21v55h-72v14H74v-43h24v-38h26z"/>
    <path fill="#70617b" d="M0 167h198v-17h46V89h17v68h62v-12h33v-15h161v16H359v15h-32v15h-66v45h30v21h65v24h244v16H344v-23h-65v-21h-34v-62h-41v11h-42v48h-17v-50H0zm274 92h17v57h-29v69h-19v-76h31z"/>
    <path d="M0 174h201m59-10h66l35-26h150m-252 90 93 46h248m-323-9v43h-24v77" stroke="#a88ba2" fill="none" opacity=".46" strokeWidth="2" strokeDasharray="8 4"/>
    <Building x={99} y={89} w={110} h={47} rows={2} cols={6} wall="#8b7ba4" roof="#6b5b8b"/>
    <Building x={263} y={38} w={87} h={38} rows={2} cols={5} wall="#748c9a" roof="#566d83" lit="#b8e2d8"/>
    <path d="M301 40h6v18h-6zm-6 6h18v6h-18z" fill="#d0ead8"/>
    <Building x={366} y={62} w={83} h={42} rows={2} cols={5} wall="#ad789a" roof="#6f557e" lit="#f1bfae"/>
    <Building x={244} y={133} w={94} h={47} rows={2} cols={5} wall="#788ca4" roof="#526b87" lit="#b8d9ee"/>
    <Building x={93} y={233} w={99} h={41} rows={1} cols={5} wall="#77958e" roof="#4e6c71" lit="#d4e7a9"/>
    <path fill="#a86e87" d="M390 198h83v7h23v14h12v36h-12v15h-23v7h-83v-7h-23v-15h-12v-36h12v-14h23z"/>
    <path fill="#4b686a" d="M397 212h70v5h18v12h9v17h-9v11h-18v7h-70v-7h-18v-11h-9v-17h9v-12h18z"/>
    <path d="M393 205h77l30 18v28l-30 18h-77l-30-18v-28zM417 216v44m30-44v44m-52-22h75" stroke="#e6a6a7" opacity=".64" fill="none"/>
    {[[16,134,.8],[42,148,1],[68,133,.7],[38,203,.9],[17,240,1.1],[60,262,1],[25,302,1],[57,334,1],[86,349,.8],[111,353,.8],[203,321,.9],[218,291,.6],[225,120,.8],[231,78,1],[351,106,.65],[506,119,1],[526,104,1],[565,114,1.1],[576,148,.7],[557,194,1.2],[580,220,.8],[533,244,.9],[545,348,1.1],[578,339,1.1],[584,364,.8],[496,352,.9],[309,350,1],[325,366,.8],[398,344,.8]].map(([x,y,s])=><Pine key={x} x={x} y={y} s={s}/>)}
    <path fill="#c59e9a" opacity=".7" d="M79 174h4v4h-4zm102 0h4v4h-4zm141-4h4v4h-4zm113-36h4v4h-4zm106 139h4v4h-4zm-256 39h4v4h-4z"/>
    <path fill="#786381" d="M468 143h57v28h-57z"/><path fill="#aa829e" d="M464 141h66v4h-66zm4 26h57v4h-57z"/><path fill="#615875" d="M479 149h32v12h-32z"/>
    <path fill="#586667" d="M284 296h70v46h-70z"/><path fill="#9a8785" d="M282 318h76v6h-76z"/>
    <path fill="#c39a88" d="M287 303h13v12h-13zm49 24h14v12h-14z"/><path fill="#e1b688" d="M290 300h7v8h-7zm49 24h7v8h-7z"/>
    <Building x={52} y={42} w={60} h={28} cols={3} rows={1} side={7} wall="#806883" roof="#604f72"/>
    <Building x={48} y={174} w={62} h={33} cols={4} rows={1} side={8} wall="#71888a" roof="#4b636c" lit="#d9e6b6"/>
    <path fill="#66566c" d="M490 294h54v30h-54z"/><path fill="#93829a" d="M495 297h37v4h-37zm7 6h30v4h-30zm7 6h23v4h-23z"/>
    <path fill="#8c8597" d="M38 295h70v6H38zm7 6h5v26h-5zm50 0h5v26h-5z"/><path fill="#dbc3ad" d="M52 304h37v10H52z"/>
    <Building x={482} y={35} w={61} h={31} wall="#927582" roof="#675574" cols={4} rows={1} side={7}/>
    <path fill="url(#map-grid)" d="M0 0h600v385H0z"/>
  </svg>
}

export function Portrait({person}: {person:Person}) {
  const hair = {lin:'#734456',su:'#353351',chen:'#434858',xu:'#3e314d',tang:'#60453e',shen:'#30364e',yan:'#29394d',lu:'#49354b',qiao:'#483e34',ji:'#30324d',he:'#674955',zhou:'#777180'}[person]
  const suit = {lin:'#a85373',su:'#56778c',chen:'#66708f',xu:'#806493',tang:'#648568',shen:'#61799b',yan:'#45848b',lu:'#9c786c',qiao:'#7e8550',ji:'#6e75ab',he:'#b38161',zhou:'#5b7e72'}[person]
  return <svg className="portrait" viewBox="0 0 40 40" role="img" aria-label={people[person].name} shapeRendering="crispEdges">
    <path fill={people[person].color} opacity=".18" d="M0 0h40v40H0z"/>
    <path fill={hair} d={person==='su' || person==='xu'?'M9 14h3V7h5V5h11v3h5v6h2v16h-7v-3H12v5H7V16z':'M10 10h3V7h6V5h8v3h5v4h2v10H8V13h2z'}/>
    <path fill="#f0bb9e" d="M12 15h4v-4h3v3h9v2h3v10h-3v4h-5v3h-6v-3h-4v-4h-3v-7h2z"/>
    <path fill={hair} d="M15 18h3v3h-3zm10 0h3v3h-3z"/>
    {person==='chen' && <path fill="none" stroke="#4a465b" d="M13.5 17.5h6v5h-6zm10 0h6v5h-6zm-4 2h4"/>}
    <path fill="#ad675e" d="M19 25h5v1h-5z"/>
    <path fill={suit} d="M12 32h5v3h8v-3h5v2h4v6H6v-6h6z"/>
    <path fill="#f9d1af" d="M17 31h8v4h-8z"/>
    {person==='xu' && <path fill="#c2a3df" d="M7 17h4v12H7zm24 0h4v12h-4z"/>}
    {person==='tang' && <path fill="#d4a77d" d="M15 8h11v2H15zm13 2h3v2h-3z"/>}
    {person==='shen' && <path fill="#aac9dc" d="M9 12h24v3H9zm17 23h5v2h-5z"/>}
    {person==='yan' && <path fill="#a9e1db" d="M8 13h27v3H8z"/>}
    {person==='lu' && <path fill="#d8ac88" d="M10 32h4v8h-4zm16 3h9v5h-9z"/>}
    {person==='qiao' && <path fill="#d7dba1" d="M12 33h17v3H12z"/>}
    {person==='ji' && <path fill="#c8d7f1" d="M26 34h8v4h-8z"/>}
    {(person==='he'||person==='zhou') && <path fill="#c6b5b8" d="M11 12h4v5h-4zm20 0h4v5h-4z"/>}
    {person==='lin' && <path fill="#f4c16d" d="M27 9h4v2h-4zm1 3h4v2h-4z"/>}
  </svg>
}
