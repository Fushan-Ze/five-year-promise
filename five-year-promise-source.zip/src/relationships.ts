import { people } from './content.ts'
import type { Choice, LocationId, Story } from './content.ts'
import type { Game } from './game.ts'

export type Gender = 'male'|'female'
export type Identity = {name:string;gender:Gender}
export type CandidateId = 'su'|'lin'|'xu'|'tang'|'shen'|'chen'|'yan'|'lu'|'qiao'|'ji'
type Stage = 'friend'|'interested'|'dating'|'estranged'
type Agreement = 'exclusive'|'open'|'hidden'
export type RelationshipRecord = {stage:Stage;affection:number;trust:number;agreement?:Agreement}
export type LoveLife = {seed:number;risk:number;events:number;lastConflict?:number;hadBreakup?:true;records:Partial<Record<CandidateId,RelationshipRecord>>}
export type LoveAction = 'friend'|'interest'|'distance'|'listen'|'cooperate'|'dismiss'|'exclusive'|'open'|'secret'|'quality'|'broken-date'|'renegotiate'|'end'|'honest'|'deny'|'apologize'|'pressure'
const moments=['meet','meet2','grow','single','open','secret','date','boundary','conflict','estranged'] as const
type Moment=typeof moments[number]
type Candidate={gender:Gender;first:number;last:number;sites:[LocationId,LocationId];chance:number;openness:number;hint:string;
  condition?:(g:Game)=>boolean;meet:[string,string];detail:string;care:string;date:string}
const mark=(g:Game,id:NonNullable<Game['milestones']>[number])=>g.milestones?.includes(id)??false
export const candidates: Record<CandidateId,Candidate> = {
  su:{gender:'female',first:0,last:7,sites:['track','garden'],chance:60,openness:1,hint:'操场晚跑或银杏小径',
    meet:['要一起走一段吗？今天不看配速。','今天不用跑。要一起走到有灯的地方吗？'],detail:'我想先留个能改的时间。你这周真的什么时候有空？',care:'我希望你说想见，也说得出哪天能见。',date:'上次拍这片银杏的时候没有下雨。今天我们可以走慢一点。'},
  lin:{gender:'female',first:0,last:7,sites:['dorm','canteen'],chance:65,openness:0,hint:'宿舍公共区或食堂晚饭',
    meet:['我去食堂，要不要一起？','这里有个座。你愿意坐一会儿，我就不把包放回来了。'],detail:'我今天想留半天给自己。你也说一个不想放掉的安排吧。',care:'说实话比答应每件事省时间。',date:'汤给你往里放了。最近有没有一件特别想讲给别人听的事？'},
  xu:{gender:'female',first:1,last:8,sites:['archive','workshop'],chance:56,openness:2,hint:'参加电台录音或积累知遥羁绊',condition:g=>mark(g,'radio-start')||(g.bonds.xu??0)>=12,
    meet:['这段可以听。有人笑了一下，我听了三遍才认出是我。','你也留下来收东西了？我刚才录到了一次没人说话的散场。'],detail:'别人不想说的事，可以保留空白。你希望我对你也这样吗？',care:'可以慢慢说。我不会替你把空白填上。',date:'录音机关了。今晚这一段不进校史，只留给我们自己。'},
  tang:{gender:'female',first:3,last:8,sites:['community','workshop'],chance:61,openness:1,hint:'先参与社区服务台协作',condition:g=>mark(g,'care-start')||(g.bonds.tang??0)>=12,
    meet:['我还有十分钟。你想坐下说，还是边走边说？','还有一块标识没贴。有空帮我从门口看看字够不够大吗？'],detail:'我最怕一句到时候再说。今天能不能先定一件小事？',care:'把下一步说清楚，剩下的可以慢慢来。',date:'今天工牌不挂了。我给自己留了一整个下午。'},
  shen:{gender:'female',first:6,last:9,sites:['stair','hospital'],chance:57,openness:0,hint:'熟悉夜班巡检或取得负一层线索',condition:g=>mark(g,'ward-lead')||(g.bonds.shen??0)>=10,
    meet:['今晚走亮着的路吧。我下班也想聊点楼层以外的事。','我今天数完了。剩下半小时想找个亮一点的地方坐。'],detail:'我可以陪你去查。但如果你改计划，我希望是你告诉我。',care:'先告诉我发生了什么，我们再决定怎么走。',date:'手电留在值班室。今晚我们从有灯的正门出去。'},
  chen:{gender:'male',first:2,last:8,sites:['lab','library'],chance:62,openness:1,hint:'大二起在实验室或图书馆有机会遇见',
    meet:['食堂还有一会儿才关，我请你吃碗米线。','这张桌子还有一半。先坐下，再决定聊不聊实验。'],detail:'你可以说不确定。我也有几件不太想说成肯定的事。',care:'先把能说的说完，剩下的别硬填。',date:'实验记录没带。米线以外，有没有你想一起试的东西？'},
  yan:{gender:'male',first:0,last:7,sites:['track','gate'],chance:63,openness:2,hint:'操场慢跑或校门等公交',
    meet:['最后一圈不用跑。我正好要走到公交站，要不要一起？','原来你也走这条线。下一班还有一会儿，要一起等吗？'],detail:'我可以约你，但不想替你决定去不去。',care:'你说不去也没关系。能说清楚就行。',date:'计时器我关了。多等一班车，刚好能把话说完。'},
  lu:{gender:'male',first:1,last:8,sites:['workshop','archive'],chance:58,openness:2,hint:'社交达到 30 或开始声音地图',condition:g=>g.stats.social>=30||mark(g,'sound-start'),
    meet:['你刚经过窗边。我可以给你看照片，留不留你说了算。','这张旧照片还没确认授权。你可以先只看不拍。'],detail:'你愿意让我知道哪一部分？有些东西只留给自己也行。',care:'同意了也可以改主意。拍照和见面都是一样。',date:'相机先放这儿。今天我们就聊各自想留下的那个下午。'},
  qiao:{gender:'male',first:3,last:8,sites:['community','workshop'],chance:60,openness:1,hint:'参加社区服务或有临床协作经验',condition:g=>mark(g,'care-start')||g.routes.clinic>=4,
    meet:['你帮我试试，这扇门还能不能打开？','胶带用完直接留这里，下一组找得到。你也常来吗？'],detail:'我还有一件事想留给自己，想听听你要留哪件。',care:'我可以帮忙，但你想怎么做得由你开口。',date:'胶带和工具都留在工坊。今天没有东西非修好不可。'},
  ji:{gender:'male',first:6,last:9,sites:['hospital','gate'],chance:56,openness:0,hint:'学业达到 50 并积累见习经历',condition:g=>g.stats.study>=50&&(g.routes.clinic>=3||mark(g,'clinic-start')),
    meet:['末班车还有一刻钟。如果你不赶，我想走慢一点。','我已经下班了。愿意聊点不用写进交接表的事吗？'],detail:'我有些晚上接不了电话。你如果会介意，我们最好现在谈谈。',care:'可以改约，但我不想等一个没说出口的决定。',date:'交接夹留在柜子里了。今天等车的时候，我们聊点别的。'},
}
const ids=Object.keys(candidates) as CandidateId[]
export const isCandidate=(id:string|undefined):id is CandidateId=>id!==undefined&&Object.hasOwn(candidates,id)
const cap=(n:number)=>Math.max(0,Math.min(100,Math.round(n)))
export const normalizeName=(input:string)=>Array.from(input.normalize('NFC').replace(/[\p{Cc}\p{Cf}]/gu,'').trim().replace(/\s+/g,' ')).slice(0,16).join('').trim()
export const newLoveLife=(seed:number):LoveLife=>({seed:seed>>>0,risk:0,events:0,records:{}})
export const eligiblePeople=(game:Game)=>game.identity?ids.filter(id=>candidates[id].gender!==game.identity?.gender):[]
export const currentPartners=(game:Game)=>eligiblePeople(game).filter(id=>game.loveLife?.records[id]?.stage==='dating')
function seeded(seed:number,key:string){
  let n=seed^2166136261
  for(const char of key)n=Math.imul(n^char.charCodeAt(0),16777619)
  n=Math.imul(n^(n>>>16),0x45d9f3b)
  return ((n^(n>>>16))>>>0)%100
}
export function meetingChance(game:Game,id:CandidateId){
  const c=candidates[id], partners=currentPartners(game)
  return Math.min(85,Math.max(22,Math.round(c.chance+(game.stats.social-40)*.23+((game.talents?.looks??60)-60)*.12
    +(game.selected===c.sites[0]?8:-7)-partners.length*6-(partners.some(p=>game.loveLife?.records[p]?.agreement==='exclusive')?9:0))))
}
const keyOf=(id:CandidateId,moment:Moment)=>'rel-'+id+'-'+moment
export function romanceEvent(id:string){
  const [,person,moment]=id.split('-')
  if(!isCandidate(person)||!moments.includes(moment as Moment)||id!==keyOf(person,moment as Moment))return
  return {person,moment:moment as Moment}
}
export function relationshipOffers(game:Game){
  const life=game.loveLife
  if(!life)return []
  const partners=currentPartners(game), visited=game.conversationsThisTerm??[]
  return eligiblePeople(game).flatMap(id=>{
    const c=candidates[id]
    if(!c.sites.includes(game.selected))return []
    const record=life.records[id], rows:{id:string;entry:string;person:CandidateId;kind:string;tone?:'horror'}[]=[]
    const add=(moment:Moment,entry:string)=>{
      const key=keyOf(id,moment)
      if(!visited.includes(key))rows.push({id:key,entry,person:id,kind:'恋爱关系'})
    }
    const name=people[id].name
    if(!record){
      if(game.term<c.first||game.term>c.last||(c.condition&&!c.condition(game)))return []
      if(visited.includes(keyOf(id,'meet'))||visited.includes(keyOf(id,'meet2')))return []
      if(seeded(life.seed,`meet-${id}-${game.term}-${game.selected}`)<meetingChance(game,id))
        add(game.selected===c.sites[0]?'meet':'meet2','偶遇 · '+name)
    }else if(record.stage==='estranged'){
      if(game.term>c.first&&seeded(life.seed,`estranged-${id}-${game.term}-${game.selected}`)<64)add('estranged','再遇 · '+name)
    }else if(record.stage==='dating'){
      add('date','和'+name+'约会')
      add('boundary','与'+name+'谈关系边界')
    }else{
      add('grow','找'+name+'聊一聊')
      if(record.stage==='interested'&&record.affection>=54&&record.trust>=32){
        const open=partners.every(p=>life.records[p]?.agreement==='open')
        if(!['single','open','secret'].some(moment=>visited.includes(keyOf(id,moment as Moment))))
          add(!partners.length?'single':open?'open':'secret','与'+name+'确认关系')
      }
    }
    return rows
  })
}
const line=(label:string,playerLine:string,reply:string,loveAction:LoveAction,emotion:Choice['emotion']='plain'):Choice=>
  ({label,playerLine,reply:'「'+reply+'」',loveAction,emotion,effect:{},note:loveAction==='secret'?'可能引起约定冲突，增加被发现的风险。':undefined})
export function romanceStory(key:string):Story|undefined{
  const event=romanceEvent(key)
  if(!event)return
  const {person:id,moment}=event,c=candidates[id],name=people[id].name
  const listen=line('说清自己想要什么，也问对方的安排','我想先听你说说，你希望我们怎么相处？',c.care,'listen','warm')
  const cooperate=line('约一个能一起完成的小计划','我们先选一件这周能一起做的事，好吗？',c.care,'cooperate','hope')
  const distance=line('礼貌道别，暂时保持距离','今天先聊到这儿吧。谢谢你跟我说这些。','好。你先忙，我也有事要做。','distance')
  const friend=line('保持朋友关系，别让对方猜','我更想继续做朋友，可以按朋友的方式相处吗？','谢谢你说明白。我愿意按你说的方式继续认识。','friend','warm')
  const interest=line('承认有好感，先慢慢认识','我对你有好感。我们能不能先多见几次？',c.care,'interest','warm')
  const dismiss=line('敷衍打断，说以后不用再找我','这事没什么好聊的，以后也不用找我了。','我听明白了。那我们就各走各的。','dismiss','hurt')
  const offerOpen=line('提议公开、知情的开放交往','我希望先把开放交往的边界谈清楚，你可以拒绝。','我会照自己的边界回答。','open','focused')
  const title={meet:'停下来打个招呼',meet2:'在另一处碰见',grow:'这次可以谈久一点',single:'说清楚以后怎么相处',open:'先把已有约定摆在桌上',secret:'已经有人在等你',date:'给见面留一段时间',boundary:'重新谈一次边界',conflict:'两份说法对不上',estranged:'没想到又在这里遇见'}[moment]
  const text={meet:c.meet[0],meet2:c.meet[1],grow:c.detail,single:c.detail,open:c.detail,secret:c.detail,date:c.date,boundary:c.detail,
    conflict:'你当时跟我说只约了我。另一边的人知道吗？',estranged:'我们在这里遇见了。你想说什么吗？'}[moment]
  const context:Partial<Record<Moment,string>>={single:'对方在等你说清是排他交往，还是开放交往。',open:'对方想知道你与现任的约定。',secret:'你仍有一段没说开的关系。两边的时间可能撞上。',conflict:'两份安排指向同一个晚上。',estranged:'你们都记得上次是怎么分开的。'}
  const choices:Record<Moment,Choice[]>={
    meet:[friend,interest,distance,dismiss],meet2:[friend,interest,distance,dismiss],grow:[listen,cooperate,interest,friend,dismiss],
    single:[line('约定只和对方交往','我想和你确认关系，并且只和你交往。','好。以后如果想改主意，先告诉我。','exclusive','warm'),offerOpen,friend],
    open:[line('坦白现有对象，提议知情交往','我已有交往对象。你愿意在知道现有约定的情况下，再决定要不要开始吗？','我需要按自己的边界来决定。','open','focused'),friend,distance],
    secret:[line('隐瞒现有关系，答应交往','我愿意和你交往。其他的事以后再说。','那我们先约一个真的能见面的日子。','secret','warm'),friend,distance],
    date:[line('留出可靠的约会时间，认真听对方说话','今天我可以把这段时间留给你，想先聊什么？',c.care,'quality','warm'),cooperate,line('临时放鸽子，也不提前解释','今天就先不见了，你不用等。','下次如果来不了，早点告诉我吧。','broken-date','hurt')],
    boundary:[line('坦白现状，重新谈开放边界','我想把现在的交往情况说清楚。你可以不同意改约定。','我会照自己的边界回答。','renegotiate','focused'),listen,line('说明理由，结束这段关系','我想结束这段关系。你愿意的话，我可以把原因讲清楚。','知道了。那接下来先各自过一段时间。','end','hurt')],
    conflict:[line('承认隐瞒，给对方决定的空间','我没有遵守说好的约定。你可以决定还要不要继续。','我会自己决定。你先别替我回答。','honest','hurt'),line('继续否认，指责对方多想','你想多了，这没什么好解释的。','我知道了。我不会再等你解释。','deny','hurt')],
    estranged:[distance,line('道歉，允许对方不接受','上次的话伤到了你，我想道歉。你不用现在回应。','我听到了。要不要重新说话，我想自己决定。','apologize','focused'),line('追上去，要求当场恢复联系','我们现在就说清楚，你不能直接走。','请停一下。我没有答应现在和你谈。','pressure','hurt')],
  }
  return {id:key,person:id,title,kind:moment==='date'?'恋爱约会':moment==='conflict'?'关系冲突':moment==='estranged'?'重遇与边界':'人物关系',
    text:(context[moment]?context[moment]+' ':'')+name+'说：「'+text+'」',choices:choices[moment],
    scene:moment==='conflict'?'station':moment==='date'?(id==='chen'?'canteen':id==='shen'?'gate':c.sites[1]):undefined}
}
function hasHidden(game:Game,life:LoveLife){
  const dating=eligiblePeople(game).map(id=>life.records[id]).filter(r=>r?.stage==='dating')
  return dating.length>1&&dating.some(r=>r?.agreement!=='open')
}
export function changeRelationship(game:Game,id:CandidateId,action:LoveAction):Game{
  if(!game.loveLife||!eligiblePeople(game).includes(id))return game
  const life={...game.loveLife,events:game.loveLife.events+1,records:{...game.loveLife.records}}
  const before=life.records[id]
  if(!before&&action==='distance')return {...game,loveLife:life}
  const r:RelationshipRecord={...(before??{stage:'friend',affection:23,trust:30})}
  const privatePlaces: LocationId[] = ['garden','roof','gate','dorm']
  const workingPlaces: LocationId[] = ['community','workshop','library','lab','hospital','archive']
  const placeWeight = (action==='listen' && privatePlaces.includes(game.selected))
    || (action==='cooperate' && workingPlaces.includes(game.selected)) ? 4 : 0
  const gain=cap(10+((game.talents?.character??60)-60)*.07+(game.selected===candidates[id].sites[0]?2:0)+placeWeight)
  const openness=candidates[id].openness
  switch(action){
    case 'friend': r.stage='friend';r.affection+=5;r.trust+=6;break
    case 'interest': r.stage='interested';r.affection+=gain;r.trust+=6;break
    case 'listen': case 'cooperate': case 'quality': r.affection+=gain;r.trust+=action==='quality'?10:action==='listen'?9:7;break
    case 'dismiss': r.stage='estranged';r.affection-=22;r.trust-=24;break
    case 'exclusive':case 'open':case 'secret':
      if(action==='open'&&(openness===0||(openness===1&&r.trust<48))){r.affection-=3;r.trust+=3;break}
      r.stage='dating';r.agreement=action==='secret'?'hidden':action;r.affection+=8;r.trust+=6
      if(action==='secret')life.risk+=24+currentPartners(game).length*5
      break
    case 'broken-date': r.affection-=10;r.trust-=14;if(hasHidden(game,life))life.risk+=13;break
    case 'renegotiate':
      if(openness>0&&r.trust>=45){r.agreement='open';r.trust+=5;life.risk-=12}
      else if(hasHidden(game,life)){r.stage='estranged';r.trust-=9;life.hadBreakup=true}
      else r.trust-=3
      break
    case 'end':r.stage='estranged';life.hadBreakup=true;break
    case 'honest':r.trust-=20;r.affection-=10;r.stage=r.trust<39||!openness?'estranged':'interested';life.hadBreakup=true;life.risk-=18;break
    case 'deny':r.stage='estranged';r.trust-=35;r.affection-=22;life.hadBreakup=true;life.risk-=12;break
    case 'apologize':r.trust+=12;if(r.trust>=35&&openness>0)r.stage='friend';break
    case 'pressure':r.trust-=13;r.affection-=6;break
    case 'distance':break
  }
  if(r.stage!=='dating')delete r.agreement
  r.trust=cap(r.trust)
  r.affection=cap(r.affection)
  life.records[id]=r
  life.risk=hasHidden(game,life)?cap(life.risk):0
  return {...game,loveLife:life,stats:action==='pressure'?{...game.stats,mind:cap(game.stats.mind-6)}:game.stats}
}
export function checkRelationshipRisk(game:Game,afterTerm=false):Game{
  const life=game.loveLife
  if(!life||!hasHidden(game,life))return game
  const partners=currentPartners(game), pending=[...game.pending]
  const shared=partners.filter(id=>candidates[id].sites.includes(game.selected)).length
  const next={...life,risk:cap(life.risk+(afterTerm?10:4)+shared*3+(partners.length-2)*5),events:life.events+1}
  if(next.risk>=33&&life.lastConflict!==game.term&&!pending.some(id=>romanceEvent(id)?.moment==='conflict')
    &&seeded(life.seed,`risk-${game.term}-${next.events}-${game.seed}`)<next.risk){
    const target=partners.find(id=>life.records[id]?.agreement==='exclusive')??partners.find(id=>life.records[id]?.agreement==='hidden')
    if(target){pending.push(keyOf(target,'conflict'));next.lastConflict=game.term}
  }
  return {...game,loveLife:next,pending}
}
export const validIdentity=(id:Identity)=>!!id&&typeof id.name==='string'&&!!id.name&&normalizeName(id.name)===id.name&&(id.gender==='female'||id.gender==='male')
export function validLoveLife(life:LoveLife,id:Identity){
  const bounded=(n:number,max:number)=>Number.isInteger(n)&&n>=0&&n<=max
  return !!life&&bounded(life.seed,0xffffffff)&&bounded(life.risk,100)&&bounded(life.events,10000)
    &&(life.lastConflict===undefined||bounded(life.lastConflict,9))&&(life.hadBreakup===undefined||life.hadBreakup===true)
    &&!!life.records&&typeof life.records==='object'&&!Array.isArray(life.records)
    &&Object.entries(life.records).every(([key,r])=>isCandidate(key)&&candidates[key].gender!==id.gender&&r
      &&['friend','interested','dating','estranged'].includes(r.stage)&&bounded(r.affection,100)&&bounded(r.trust,100)
      &&(r.stage==='dating'?['exclusive','open','hidden'].includes(r.agreement??''):r.agreement===undefined))
}
