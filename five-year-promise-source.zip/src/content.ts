import type { LoveAction } from './relationships.ts'
import type { Emotion } from './audio-direction.ts'
import type { Talents } from './talents.ts'

export const stats = {
  study: { name: '学业', icon: 'book', color: '#b49af8' },
  mind: { name: '精神', icon: 'moon', color: '#f29fc5' },
  body: { name: '体力', icon: 'bolt', color: '#ffc981' },
  social: { name: '社交', icon: 'heart', color: '#8ce4cd' },
  cash: { name: '金钱', icon: 'coin', color: '#ffd971' },
} as const

export const people = {
  lin: { name: '林小满', role: '嘴硬的室友', color: '#e9a8b7', bio: '全寝最懂外卖券的人。会吐槽你熬夜，也会给你留灯。' },
  su: { name: '苏晚晴', role: '操场上的同级生', color: '#a4d6e2', bio: '讲话轻，跑得快。喜欢晚霞，讨厌敷衍的约定。' },
  xu: { name:'徐知遥', role:'校园电台剪辑', color:'#d2b0e5', bio:'收集旧录音。别人说「随便」，她会再问一遍可以留下哪一段。' },
  tang: { name:'唐禾', role:'社区志愿搭档', color:'#b1d8a4', bio:'总拿一支削短的铅笔记问题。最在意做完以后，谁来接着做。' },
  shen: { name:'沈棠', role:'夜班设备志愿员', color:'#b1c5ed', bio:'夜班只记时间和楼层。她坚持附院的旧楼梯在一楼就到底了。' },
  yan: {name:'顾言',role:'跑团配速员',color:'#94cfc8',bio:'给新手留慢道，最讨厌替别人答应比赛。'},
  lu: {name:'陆闻川',role:'校刊摄影编辑',color:'#d4b2a4',bio:'出片以前一定确认授权，拍坏的照片会自己留着重看。'},
  qiao: {name:'乔致远',role:'社区站物资协管',color:'#c6d3a3',bio:'手边永远有一卷胶带，习惯把长计划拆成明天能做的一件事。'},
  ji: {name:'季明澈',role:'附院见习同组生',color:'#acb9ef',bio:'交接表写得整齐，下班后想过一小时不用讲工作的话。'},
  he: {name:'何阿姨',role:'一号食堂窗口',color:'#e5b88d',bio:'认识半个校园的人，会给晚下课的人留一份热饭。'},
  zhou: {name:'周师傅',role:'校门值守',color:'#a9c0b1',bio:'每晚记最后一班车，从不给别人代签已经错过的时间。'},
  chen: { name: '陈一舟', role: '实验室师兄', color: '#c2adeb', bio: '对原始数据和砂锅米线都有近乎偏执的认真。' },
} as const

export type Stat = keyof typeof stats
export type Person = keyof typeof people
export type CorePerson = 'lin' | 'su' | 'chen'
export const threadFlags = ['radio-start','radio-finish','care-start','care-finish','ward-lead','ward-proof','room-lead','room-proof','tutor-start','tutor-finish','sound-start','sound-finish','clinic-start','clinic-finish','paper-start','paper-finish','rain-start','rain-finish','letters-start','letters-finish'] as const
export type ThreadFlag = typeof threadFlags[number]
export type Route = 'honors' | 'lab' | 'love' | 'friends' | 'rest' | 'clinic'
export type Career = 'trial' | 'product' | 'writing' | 'medicine'
export type Project = 'product' | 'writing'
export type Relationship = 'single' | 'dating' | 'apart'
export type RelationshipPlan = 'open' | 'together' | 'distance'
export type StoryScene = LocationId | 'career' | 'cafe' | 'station' | 'classroom' | 'studio' | 'basement' | 'emptyDorm'
export type Effect = Partial<Record<Stat, number>> & {
  bond?: Partial<Record<Person, number>>
  route?: Partial<Record<Route, number>>
  run?: number
  promise?: boolean
  clue?: SpecialEnding
  growth?: Partial<Talents>
  career?: Career
  project?: Project
  relationship?: Relationship
  plan?: RelationshipPlan
  trust?: number
  contextWeight?: number
  milestone?: ThreadFlag
}
export type Choice = { label: string; effect: Effect; note?: string; outcome?: Ending; reply?: string; followUp?: string; emotion?: Emotion; loveAction?: LoveAction; playerLine?: string }
export type Story = { id: string; kind: string; title: string; text: string; choices: Choice[]; person?: Person; scene?: StoryScene; voice?: string; tone?: 'horror'; emotion?: Emotion }
const c = (label: string, effect: Effect, note?: string): Choice => ({label, effect, note})
const term = (id: number, title: string, text: string, choices: Choice[], person?: Person): Story =>
  ({id: 'term-' + id, kind: '学期剧情', title, text, choices, person})

export const terms = [
  term(0, '第一张校园卡', '报到那天下午，303 寝室的风扇只会摇头。林小满蹲在插座前宣布：“谁能借到拖线板，谁就是本寝第一任外交部长。”窗外广播正念着新生手册，一直念到第十八页。', [
    c('带上室友一起逛校园', {social: 5, mind: 3, bond: {lin: 15}, route: {friends: 1}}),
    c('先弄清楚这学期考什么', {study: 6, mind: -2, route: {honors: 1}}),
    c('铺好床，睡到风扇修好', {mind: 6, body: 5, route: {rest: 1}}),
  ], 'lin'),
  term(1, '四十次校园跑', '辅导员在群里发了倒计时。你还差一截，今晚里面偏偏穿着毛衣。苏晚晴在跑道边递给你一只号码布：“要不先跑一圈？跑完再决定要不要骂这个系统。”', [
    c('一起跑完，顺便约好下次', {body: 4, mind: 3, run: 1, bond: {su: 17}, route: {love: 1}}),
    c('今晚休息，明天再慢慢补', {body: 6, mind: 5, route: {rest: 1}}),
  ], 'su'),
  term(2, '显微镜下的陌生人', '组胚实验室里，隔壁组已经收拾书包。你的视野还是一片粉红色。陈一舟把镜筒推回原位：“先找你认识的那一小块。找不到就从边缘重来。”', [
    c('重调焦距，留一张实验记录', {study: 7, body: -4, bond: {chen: 16}, route: {lab: 2}}),
    c('画份能看懂的结构图发给同学', {study: 4, social: 6, route: {honors: 1, friends: 1}}),
  ], 'chen'),
  term(3, '考试周的第二个太阳', '凌晨一点，台灯热得像第二个太阳。群里有人问考点，有人发了一张“明天全会”的表情包。林小满关掉自己的台灯，问你要不要一起去楼下买豆浆。', [
    c('合上笔记，买完就睡', {mind: 8, body: 5, bond: {lin: 11}, route: {rest: 1}}),
    c('讲完这章，再和室友下楼', {study: 8, mind: -5, bond: {lin: 8}, route: {honors: 2}}),
  ], 'lin'),
  term(4, '一条不漂亮的曲线', '你的第一组数据没有显著变化，第三个样本甚至拐了个弯。师兄把原始表格投上组会屏幕：“来，讲讲这个弯是怎么来的。”', [
    c('保留原始数据，列出复验计划', {study: 5, mind: -3, bond: {chen: 18}, route: {lab: 3}, growth:{wisdom:2,creativity:2}}),
    c('先把这次的限制讲清楚', {study: 4, social: 5, bond: {chen: 8}, route: {honors: 1}}),
  ], 'chen'),
  term(5, '义诊摊位的塑料凳', '社区志愿活动来了好多爷爷奶奶。有人排队量血压，也有人只是想坐下聊聊。你的小队只剩三张塑料凳。', [
    c('重新安排队伍，给大家留出座位', {social: 10, body: -5, route: {friends: 3}}),
    c('请老师带着解释记录单', {study: 5, social: 4, route: {clinic: 2}}),
  ]),
  term(6, '第一件白大褂', '见习第一天，你被喊到床旁。病人把报告折成四折，问：“我女儿说她懂，怎么跟我说的时候，还是那几个我不认识的字？”', [
    c('问她最担心什么，再请带教解释', {social: 7, mind: 2, route: {clinic: 3}, growth:{character:2,resilience:1}}),
    c('复盘老师的话，整理成通俗笔记', {study: 7, route: {honors: 1, clinic: 1}}),
  ]),
  term(7, '十点半的天台', '苏晚晴抱来两瓶汽水，说今晚的月亮像教室投影仪关机时留下的白点。你们在台阶上坐了一会儿，她忽然问起毕业以后。', [
    c('认真告诉她，毕业后也想再见', {mind: 7, bond: {su: 18}, route: {love: 2}}),
    c('聊聊各自想去的城市', {social: 6, bond: {su: 7}, route: {friends: 1}}),
  ], 'su'),
  term(8, '夜班交接本', '临床实习的夜班结束了，窗户刚亮。带教翻开交接本，最后一页写着一个病人的小问题：她想知道什么时候可以给外孙打电话。', [
    c('向带教确认后，把问题交代给白班', {study: 5, social: 4, body: -5, route: {clinic: 3}}),
    c('记下这晚学到的事，回寝补觉', {study: 3, body: 7, mind: 4, route: {rest: 1}}),
  ]),
  term(9, '最后一次点名', '毕业合影前又下了一阵雨。群里催大家交照片，旧教室里却安静得能听见空调滴水。点名册在你手里，第一页有五年前自己的签名。', [
    c('把这页拍下来，发给303', {social: 5, bond: {lin: 10}, route: {friends: 1}}),
    c('给未来的自己留一行字', {mind: 7, route: {rest: 1}}),
    c('去操场赴一场旧约', {mind: 4, bond: {su: 11}, route: {love: 1}}),
  ]),
]

export const sideStories: Story[] = [
  {id:'lin-1', kind:'林小满 · 羁绊 I', title:'303 寝室公约', person:'lin', text:'林小满把一张纸贴在门后，上面写着“禁止在室友做梦时问背完了吗”。下面还有空位，笔就递到了你面前。', choices:[
    c('加一条，难过的人有权叫醒室友', {mind: 7, bond:{lin:12}, route:{friends:2}}), c('加一条，周末的觉要睡够', {body:7, bond:{lin:6}, route:{rest:1}})]},
  {id:'lin-2', kind:'林小满 · 羁绊 II', title:'别退303的群', person:'lin', text:'她把群名改成了“303校外分部”。“我可能会去外地，”她转着手机，等你的反应，“但我生日那天还是会在群里发红包。”', choices:[
    c('订一个每年都能赴的饭局', {social:8, bond:{lin:13}, route:{friends:3}}), c('把那张寝室公约分她一半', {mind:9, bond:{lin:10}, route:{friends:1}})]},
  {id:'su-1', kind:'苏晚晴 · 羁绊 I', title:'跑道的第九道', person:'su', text:'雨把八条跑道刷得发亮。苏晚晴踩上跑道外的水泥沿：“我叫这儿第九道。今天成绩不算，陪我走走？”', choices:[
    c('陪她走一圈，等她慢慢讲', {mind:8, bond:{su:14}, route:{love:2}}), c('把伞留给她，约改天再走', {bond:{su:7}, body:5})]},
  {id:'su-2', kind:'苏晚晴 · 羁绊 II', title:'把约定写在车票背面', person:'su', text:'她从校服口袋里摸出两张旧车票。“如果毕业后不在一个城市，假期里你愿意留一天给我吗？”背面写着你们第一次一起跑步的日期。', choices:[
    c('牵住她的手，说好', {mind:8, bond:{su:12}, route:{love:3}, relationship:'dating'}), c('把票收好，珍惜现在的友情', {mind:6, social:5, bond:{su:7}, route:{friends:2}})]},
  {id:'chen-1', kind:'陈一舟 · 羁绊 I', title:'米线和误差', person:'chen', text:'师兄请你吃米线，把失败实验写在餐巾纸上。他划掉“我做错了”，改成了“我还不知道为什么”。', choices:[
    c('约他明天一起查原始记录', {study:7, bond:{chen:13}, route:{lab:2}}), c('请他今晚先吃完这碗米线', {mind:8, bond:{chen:7}})]},
  {id:'chen-2', kind:'陈一舟 · 羁绊 II', title:'本子上的两个名字', person:'chen', text:'一页新的研究计划摊开着。师兄把你的名字写在自己旁边：“题目还能改，愿不愿意一起从头把这个问题弄明白？”', choices:[
    c('接过本子，写下第一个问题', {study:8, bond:{chen:12}, route:{lab:3}}), c('把交接笔记整理给下一届', {study:4, social:6, route:{friends:1}})]},
]

export const chance: Story[] = [
  {id:'rain', kind:'校园奇遇', title:'刚打卡就下雨', text:'软件弹出“跑步有效”的下一秒，雨砸下来。看台后面有一把标着“可借”的伞，还有一条更近但全是水的路。', choices:[
    c('借伞，明早原位归还', {mind:5, body:3}), c('冲回寝室，抢到第一个洗澡位', {body:-4, mind:8, bond:{lin:4}})]},
  {id:'coupon', kind:'校园奇遇', title:'午夜半价窗口', text:'食堂阿姨正准备关窗，剩下两份布丁。她说五块一起带走，慢一步就要进冰箱过夜了。', choices:[
    c('带两份回寝，顺路分一份', {cash:-5, mind:6, bond:{lin:8}, social:3}), c('让给身后那个抱着书的同学', {social:5, mind:3})]},
  {id:'cat', kind:'校园奇遇', title:'学术会议被猫主持', text:'猫卧在自习室唯一有插座的座位上。旁边写着“已占座”，落款是“医学喵士”。它抬起头，看起来愿意接受谈判。', choices:[
    c('给它拍张证件照', {mind:8, route:{rest:1}}), c('换到窗边，把笔记看完', {study:5, mind:2})]},
  {id:'printer', kind:'校园奇遇', title:'打印店的最后一张纸', text:'打印机卡纸了，队伍安静了两秒。老板从抽屉里摸出一只螺丝刀，把视线投向排在第一位的你。', choices:[
    c('帮忙清纸，顺便指挥排队', {social:6, cash:8, route:{friends:1}}), c('改传电子版，省下打印费', {cash:12, mind:3})]},
  {id:'lights', kind:'校园奇遇', title:'停电了三分钟', text:'宿舍楼突然黑了。有人亮起手电筒，另一栋楼很快传来一声“看得到”。你们打出一排错字很多的摩斯密码。', choices:[
    c('加入楼与楼之间的聊天', {social:6, mind:4, bond:{lin:5}}), c('去走廊看一会儿星星', {mind:9, body:3})]},
  {id:'book', kind:'校园奇遇', title:'旧书里的一张欠条', text:'二手教材里夹着张纸条：“如果你刚好翻到这页，代我去食堂吃一份糖醋里脊。我那年一直忘了吃。”', choices:[
    c('代吃，还写一张给下届', {cash:-8, mind:9, route:{rest:1}}), c('把同页的易错题整理进笔记', {study:6, route:{honors:1}})]},
  {id:'exchange', kind:'校园奇遇', title:'用一张旧讲义换春天', text:'跳蚤市场上有人用手绘明信片换旧讲义。每张卡片背面都画了一个校园里的秘密取景点。', choices:[
    c('换一张，约苏晚晴去找地点', {mind:5, bond:{su:9}, route:{love:1}}), c('把整理过的讲义留在摊位上', {social:7, route:{friends:1}})]},
  {id:'microscope', kind:'校园奇遇', title:'被忘记的载玻片', text:'洗台边留着一枚没有标签的练习切片。陈一舟正在查登记本，旁边的人说反正看不出来是哪一组的。', choices:[
    c('帮师兄查记录，重新贴标签', {study:5, bond:{chen:9}, route:{lab:1}}), c('写张提醒贴在洗台边', {social:4, mind:3})]},
]

export const exams = [
  '医用基础', '系统解剖', '组织胚胎', '病理生理', '药理与实验', '诊断学', '内外科见习', '临床技能', '轮转考核', '毕业考核',
]
export const years = ['初入青禾', '显微镜下', '问号与答案', '走出教室', '白衣与告别']

export const locations = [
  {id:'library', name:'图书馆', icon:'book', hint:'复习与笔记', x:26, y:35, color:'#c4a9fa', unlock:0, actions:[
    c('安静自习', {study:10, body:-5, mind:-3, route:{honors:2}, growth:{wisdom:2}}, '把难懂的知识拆成三页笔记。'),
    c('约同学一起过题', {study:6, social:5, bond:{lin:6}, route:{honors:1, friends:1}, growth:{wisdom:1,character:1}}, '轮流给对方讲一次最容易错的题。')]},
  {id:'dorm', name:'303 宿舍', icon:'home', hint:'休息与室友', x:68, y:27, color:'#f3acc8', unlock:0, actions:[
    c('关灯补觉', {body:18, mind:13, route:{rest:2}, growth:{resilience:1}}, '眼罩一戴，世界安静。'),
    c('和小满夜聊', {mind:9, social:7, bond:{lin:16}, route:{friends:2}, growth:{character:2}}, '从舍友的闹钟聊到毕业之后。')]},
  {id:'track', name:'校园跑道', icon:'bolt', hint:'打卡与晚霞', x:71, y:67, color:'#ffc68c', unlock:0, actions:[
    c('打卡校园跑', {body:5, mind:7, run:1, growth:{looks:1,resilience:2}}, '跑过晚霞，打卡成功，明天依然要跑。'),
    c('约晚晴一起走', {mind:6, social:5, bond:{su:16}, route:{love:2}, growth:{character:2}}, '并肩走一圈，听听她今天在想什么。')]},
  {id:'lab', name:'医学实验楼', icon:'flask', hint:'二年级开放', x:48, y:46, color:'#a8d9f4', unlock:2, actions:[
    c('跟师兄做实验', {study:8, mind:-3, body:-6, bond:{chen:15}, route:{lab:2}, growth:{wisdom:1,creativity:2}}, '写清楚每一次操作，哪怕结果很古怪。'),
    c('整理原始数据', {study:6, cash:20, body:-4, bond:{chen:7}, route:{lab:2}, growth:{wisdom:2}}, '老师发了一点补贴，先把文件名统一。')]},
  {id:'canteen', name:'一号食堂', icon:'cup', hint:'热饭与兼职', x:25, y:72, color:'#a1e6c5', unlock:0, actions:[
    c('吃顿热饭', {cash:-28, body:12, mind:8}, '汤碗落桌，终于轮到你喘口气。'),
    c('参加社团小聚', {cash:-14, social:10, mind:5, route:{friends:2}, growth:{looks:2,character:2}}, '交换学校里最好吃的三家小摊。'),
    c('帮窗口兼职', {cash:65, body:-7, social:4, growth:{character:1,resilience:2}}, '学会一边找零，一边跟阿姨说谢谢。')]},
  {id:'hospital', name:'青禾附院', icon:'cross', hint:'四年级开放', x:51, y:16, color:'#99dfd6', unlock:6, actions:[
    c('跟带教参加见习', {study:7, social:4, body:-7, route:{clinic:2}, growth:{character:1,resilience:2}}, '看带教如何把复杂的话慢慢讲明白。'),
    c('做一次病例复盘', {study:6, mind:-2, route:{clinic:2, honors:1}, growth:{wisdom:2}}, '把这次轮转想问的问题先记下来。')]},
  {id:'roof', name:'教学楼天台', icon:'moon', hint:'夜风与长谈', x:83, y:44, color:'#e4b3ec', unlock:0, actions:[
    c('吹一会儿夜风', {mind:12,growth:{resilience:1},route:{rest:1}},'数到第三辆末班车，再回寝。')]},
  {id:'garden', name:'银杏小径', icon:'heart', hint:'散步与约会', x:53, y:84, color:'#f2cd9e', unlock:0, actions:[
    c('沿银杏小径散步', {body:6,mind:8,growth:{resilience:1}},'捡一片完整的叶子夹进笔记。')]},
  {id:'archive', name:'旧档案室', icon:'book', hint:'校史与电台', x:14, y:17, color:'#d9addc', unlock:0, actions:[
    c('给旧磁带做目录', {study:5,mind:4,growth:{creativity:2}},'把每段可辨认的声音写在标签上。')]},
  {id:'community', name:'社区站', icon:'people', hint:'二年级下开放志愿服务', x:13, y:54, color:'#b1d9a7', unlock:3, actions:[
    c('协助整理服务台', {social:7,body:-3,route:{clinic:1},growth:{character:2}},'把来访者总要问两遍的问题记下来。')]},
  {id:'stair', name:'设备楼梯', icon:'moon', hint:'四年级随附院开放', x:86, y:84, color:'#a9b7d6', unlock:6, actions:[
    c('核对楼层标记', {study:3,mind:3,growth:{resilience:2}},'给坏掉的疏散灯做一条维修记录。')]},
  {id:'gate', name:'校门公交站', icon:'flag', hint:'末班车与送别', x:12, y:85, color:'#a9c0b1', unlock:0, actions:[
    c('等一班不用赶的公交', {mind:9,body:4},'等车时，校园广播刚好结束。')]},
  {id:'workshop', name:'志愿工坊', icon:'compass', hint:'海报、摄影与协作', x:86, y:16, color:'#d5b798', unlock:1, actions:[
    c('帮忙整理公共工作台', {social:6,study:4,growth:{creativity:2}},'把常用的东西留在下一组找得到的地方。')]},
] as const
export type LocationId = typeof locations[number]['id']

export const endings = {
  honors: {name:'绩点之上', icon:'book', text:'毕业那天，有人向你借最后一份复习提纲。你翻到自己写得最早的一页，上面全是问号。五年以后你仍然爱提问，只是已经有人来听你讲答案。'},
  lab: {name:'在微光里求证', icon:'flask', text:'实验楼的灯照在两本叠放的实验记录上。你没有等到一个完美的结果，但今天有了一个可以带走的新问题。陈一舟站在门口，喊你先把米线吃了。'},
  love: {name:'五年之后，下一圈', icon:'heart', text:'毕业后第一个假期，你们按约定在旧跑道见面。苏晚晴把车票翻过来，背面又多了一行字。“下一圈，”她问，“你还跟得上吗？”'},
  distance: {name:'两座城，星期日', icon:'heart', text:'出发那天，你们在车站对过最后一遍日程。她的早班和你的夜班碰不上，每隔一周的星期日却空着。第一个星期日，你收到一条语音。她没有问你为什么没回消息，只说：「我到站了。你慢慢来。」'},
  farewell: {name:'各自的下一站', icon:'flag', text:'晚晴把旧车票还给你，背面那行日期还清楚。你们在站台等了两趟车，把先前没说完的话讲完。上车以后，你把车票夹进毕业册。那段路确实一起走过，现在各自下车也可以。'},
  campusLove:{name:'把下一次见面写下来',icon:'heart',text:'离校那天，你们对了一次日历。下次见面终于有了日期。车来之前，你记下对方说的事：提前到不用等在原地，可以先去买两杯水。'},
  honestLove:{name:'桌上的几份日历',icon:'heart',text:'毕业以后，彼此的地址都变了。你们重新商量见面和独处的时间，有人更改约定，也有人发来新的班表。你认真记下每个人的回答。'},
  brokenTrust:{name:'没能一起赴的约',icon:'flag',text:'合照拍完后，旧聊天框里还留着没有兑现的安排。有人没有回信，有人只回了句毕业快乐。车开走以前，你删掉了那个从来没有确认过的共同日期。'},
  friends: {name:'通讯录里的家', icon:'people', text:'303 的群里弹出一条新消息，是林小满发来的一张塑料饭盒照片。她搬家了，问你要不要来吃第一顿饭。你发现，五年前遇见的人一直在给你留座。'},
  rest: {name:'把日子过回来', icon:'moon', text:'你在寝室里睡了大学时代最后一个午觉。箱子已经收好，阳台还有点太阳。五年里你学会了让自己停一停，也终于明白走得慢的人同样会抵达。'},
  clinic: {name:'白衣口袋里的纸条', icon:'cross', text:'你把第一张交班条叠好，收进白衣口袋。上面除了工作，还有病人说起的那通电话。往后的许多个早晨，你都记得给这样的小事留一行。'},
  ordinary: {name:'青禾未完待续', icon:'flag', text:'你从校门走出去，发现来时的路比记忆里短了不少。五年没有给出唯一答案。你买了杯豆浆，坐上公交，准备去下一站看看。'},
  extension: {name:'再留一个春天', icon:'home', text:'补修通知夹在空白的毕业页里。你回到自习室，窗外正有人跑圈。室友给你发了个座位号，你把新买的笔放在桌上，打算从第一章重新来。'},
  ward: {name:'附院负一层', icon:'cross', text:'毕业考核那天，电梯重新出现了 B1。你按下去，听见身后一整层的人齐声咳嗽。门开时，值班室的交接本摊在桌上。你的字迹写着：门一开，别回头。\n\n你没有回头。桌上的玻璃却倒映着整条走廊。穿着五年前那件校服的你站在最远处，嘴唇动了动。你认出来，那是你报到时问的第一句话：「请问，出去怎么走？」\n\n次日，白班护士在电梯里发现一张毕业证。签发日期是明天，背面多了一行字：今晚有人替我值班。'},
  roommate: {name:'303 的第五张床', icon:'home', text:'拍完毕业照，你按便签上的约定给五号床留了灯。门内的脚步数到四，又多了一声。屋里那个坐在你床沿的人穿着你的旧毛衣，正用你的声音和小满道别。\n\n你推门进去，想问它是谁。小满从桌上拿起手机，给屋里的人发了一条消息。你口袋里的手机同时亮了。她发的是：「到家说一声。」\n\n她把行李拖出门，习惯性地关灯。黑暗里，五号床上的你终于听见有人从走廊里敲门。'},
  ledger: {name:'借阅期限：五年前', icon:'book', text:'你把借书卡塞回那本书。图书馆广播开始催新生去报到，窗外，五年前的你正拖着箱子往 303 走。\n\n你在扉页写下五年来唯一想提前告诉自己的话，犹豫了一下，把「千万别」改成「如果可以」。随后你把书递给那位拎着行李的新生。他问什么时候还。\n\n管理员瞥了一眼你的毕业证：「按老规矩，等上一个借书的人第一次翻开它。」'},
  ninth: {name:'第九道的终点', icon:'bolt', text:'毕业后第一场雨，你沿着第九道走到终点。地面上投着八种晚霞，其中一片正下着雪。每条跑道尽头，都站着一个走了别的路的你。\n\n最外边那个人递来一瓶汽水。他说你迟到了五年。你说你明明刚到。他翻过瓶盖，里面写着你在大一那年随手编的跑步口号。\n\n操场广播响了：「本次打卡有效。」屏幕显示：用时 00:00，距离 5 年。你把汽水分给了离你最近的自己。'},

  radio: {name:'请在播放前叫我的名字', icon:'book', text:'离校前，你和徐知遥完成了最后一期节目。有人撤回了一段录音，你们在那个位置留了五秒空白。播出以后，一位毕业多年的学姐回信说，她第一次听见校园时，广播里有人认真念对了她的名字。'},
  community: {name:'留给下一班的椅子', icon:'people', text:'唐禾把交接册递给新志愿者。你们画过的服务动线被改了几次，最后保留下来的，是等候区多出的一把椅子和一句「需要帮忙可以坐着等」。下次回来看，你坐上那把椅子，等新人把自己的办法讲完。'},
  product: {name:'白大褂之外的产品说明书', icon:'compass', text:'你收起白大褂，带着候诊原型进了医疗产品团队。上线那天，一位阿姨在屏幕上找到自己的名字，没有再问第三遍「轮到我了吗」。你在下个版本的便签上写：再把字放大一点。'},
  writing: {name:'给门外的人写一封信', icon:'book', text:'你去做了科普编辑。第一篇稿子返了七遍，最后只留下一张图和四个短句。林小满把文章转给她妈妈，附了一句「你上次问我的，就是这个」。你把这条消息留在第一本剪报里。'},
  medicine: {name:'再穿一次白大褂', icon:'cross', text:'转行申请和轮转志愿表并排放在桌上。你花几个月认真试了别的工作，最后填的是临床。交班那天，你把去年写坏的候诊指引重新贴好，然后在第一个病人的名字旁边，记下她习惯被怎样称呼。'},
  exploration: {name:'毕业后的第一个试用期', icon:'flag', text:'第一封面试回信说，作品集还少一点实践。你在日历上圈出三个月，找了一份实习，把五年里最想解决的那个问题带过去。毕业照被你夹在新本子的第一页，后面都是空白。'},
} as const
export type Ending = keyof typeof endings

export const detourTones = {
  horror: '恐怖',
  strange: '诡异',
} as const

type Detour = {
  location: LocationId
  unlock: number
  tone: keyof typeof detourTones
  action: Choice
  story: Story
  finale: string
}
function detour(id: SpecialEnding, location: LocationId, unlock: number, tone: Detour['tone'], action: Choice,
  title: string, text: string, choices: Choice[], finale: string): Detour {
  return {location, unlock, tone, action, story:{id, kind:'校园支线 · ' + detourTones[tone], title, text, choices, scene:tone==='horror'?(id==='ward'?'basement':'emptyDorm'):location, tone:tone==='horror'?'horror':undefined}, finale}
}

export type SpecialEnding = 'ward' | 'roommate' | 'ledger' | 'ninth'
export const detours: Record<SpecialEnding, Detour> = {
  ward: detour('ward','hospital',6,'horror',
    c('查一下电梯里的 B1', {}, '交接表上没有这一层。'), '无人认领的夜班',
    '你替护士站送还钥匙。电梯按钮间浮出一个 B1，边缘亮着，像一直被人按住。对讲机响了一声：「给我留灯。」你认出那是自己的声音。门缝底下伸出一张纸，纸上排的是毕业后的夜班，你的名字占了整整一页。',
    [c('把夜班表折起来，记住开门的时间', {mind:-7, milestone:'ward-lead'}, '到设备楼梯找夜班人员核对。'), c('按开门键，退回有人值守的楼层', {mind:3})],
    '午夜回附院，赴纸上的夜班'),
  roommate: detour('roommate','dorm',2,'horror',
    c('数一数寝室里的床位', {}, '小满说她昨晚数到了五。'), '多出来的床牌',
    '303 一直是四人寝。今晚洗漱回来，你在自己的床头摸到两块床牌。第二块刻着「5」，背面贴了一张你的证件照。照片上的你站在 303 门外，穿着毕业那天才会领到的学士服。',
    [c('收起五号床牌，记下背面的约定', {mind:-5, milestone:'room-lead'}, '到旧档案室查 303 的原始平面图。'), c('把牌拿给小满，今晚在楼下待一会儿', {mind:4})],
    '回 303，给五号床留一盏灯'),
  ledger: detour('ledger','library',1,'strange',
    c('查看过期的借书卡', {}, '日期比你入学早了整整五年。'), '逾期尚未开始',
    '那本旧书的借书卡上是你的签名。逾期天数为负数，每翻一页又少一天。管理员说这本书有个奇怪的规矩：借走的人总得亲自还给第一个读者。',
    [c('把书借下来，留下最后一页空白', {study:4, clue:'ledger'}), c('把书留在借还台，抄下需要的那一页', {study:2})],
    '把旧书还给它的第一个读者'),
  ninth: detour('ninth','track',1,'strange',
    c('沿着雨后的第九道走', {}, '地图上只有八道，积水里却多了一条。'), '用时零秒的一圈',
    '积水里一共有九条跑道。第九道的终点线外，正有一个穿着你鞋子的人向你挥手。手机弹出一条打卡记录：这次跑步已经完成，开始时间是毕业以后。',
    [c('记下终点的坐标，等毕业后再来', {body:4, clue:'ninth'}), c('绕开积水，跑完今天这一圈', {body:5, run:1})],
    '等雨落下来，去找第九道的终点'),

}

export const specialEndingIds = Object.keys(detours) as SpecialEnding[]

export function isSpecialEnding(id: string): id is SpecialEnding {
  return Object.hasOwn(detours,id)
}


export const careerStories: Story[] = [
  {id:'career-open', kind:'生涯支线', title:'白大褂之外', scene:'career',
    text:'见习动员会散场后，你在公告栏发现一张项目招募。有人想把候诊流程做成更易懂的产品，也有人想把难懂的医学词写成普通人看得懂的文章。申请表问：如果有一次机会，你想先试什么？',
    choices:[c('先准备见习，照原计划走', {}),c('报名试做，把方向想清楚', {career:'trial',growth:{resilience:1}},'图书馆和实验楼将开放生涯项目。')]},
  {id:'career-decision', kind:'生涯支线', title:'两张表，一支笔', scene:'career',
    text:'轮转报名和毕业求职同时开始。你把这几年做过的项目摊在窗台上。小满问：「如果谁都不会因为你的选项失望，你想把第一份简历投到哪？」',
    choices:[c('继续从医，交回临床志愿表', {career:'medicine',growth:{resilience:2}}),c('转做医疗产品，继续打磨原型', {career:'product'}),c('转做科普编辑，准备作品集', {career:'writing'})]},
]

export const careerActions = {
  product: {location:'lab', action:c('做一版候诊指引原型',{project:'product',study:5,growth:{creativity:3,wisdom:2}},'用纸板试跑一遍，再请人找错。')},
  writing: {location:'library', action:c('写一篇给家属看的科普',{project:'writing',study:5,growth:{character:3,creativity:2}},'让同学圈出读不懂的词，再重写一遍。')},
} as const
export const projectIds = ['product','writing'] as const
export const careerIds = ['trial','product','writing','medicine'] as const

export const badges = {
  arrival: {name:'青禾新生', icon:'flag', text:'开启一段大学生活。'},
  runner: {name:'操场常客', icon:'bolt', text:'累计完成 5 次校园跑。'},
  scholar: {name:'全优笔记', icon:'book', text:'获得 3 次优秀考核。'},
  bond: {name:'有事找我', icon:'heart', text:'与任意一位同学建立 60 点羁绊。'},
  field: {name:'第一件白大褂', icon:'cross', text:'进入四年级见习阶段。'},
  night: {name:'第九道', icon:'moon', text:'秘密成就', hidden:true},
  cat: {name:'首席猫片摄影师', icon:'star', text:'秘密成就', hidden:true},
  graduate: {name:'把毕业帽抛起来', icon:'medal', text:'获得任意毕业结局。'},
  replay: {name:'另一条时间线', icon:'compass', text:'收录 3 种不同结局。'},
} as const
export type Badge = keyof typeof badges
