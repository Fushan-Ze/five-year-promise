import { emotions, endingNarration, protagonistCue, protagonistSample, soundtrack, voiceCue, voices } from './audio-direction'
import { useAudio } from './audio'
import musicCatalog from './music-catalog.json'
import { useEffect, useRef, useState } from 'react'
import { createRoot } from "react-dom/client"
import type { CSSProperties, ReactNode } from 'react'
import { activeSlot, addRun, mergeSaveBooks, readSaveBook, saveRun, selectRun } from './saves'
import type { SaveBook, SaveSlot } from './saves'
import { candidates, currentPartners, eligiblePeople, normalizeName } from './relationships'
import type { Gender, Identity } from './relationships'
import { SceneArt, StudentPortrait } from './scenes'
import type { Scene } from './scenes'
import { talentIds, talentLabels } from './talents'
import { HeroArt, Icon, MapArt, Portrait } from './art'
import { badges, detours, detourTones, endings, exams, isSpecialEnding, locations, people, stats, years } from './content'
import type { Badge, Choice, Ending, Person, Stat, Story } from './content'
import { act, actionLimit, affordable, ACTIONS_PER_TERM, availableActions, availableChapter, availableConversations, bondFor, careerFit, careerTarget, choose, currentStory, effectLabels, endingEpilogue, examScore, examTarget, finishTerm, investigationNotes, isOptionalConversation, leaveConversation, openChapter, openConversation, projectNotes, relationshipFor, SAVE_KEY, selectLocation, startGame, talentsFor, TERM_COUNT, trustFor, unlockExtraTime } from './game'
import type { Game } from './game'
import './style.css'

type Panel = 'help' | 'people' | 'archive' | 'save' | 'identity' | 'journal' | 'ending' | 'scene' | 'audio'
const yearNumber = ['一','二','三','四','五']
const personIds = Object.keys(people) as Person[]
const statIds = Object.keys(stats) as Stat[]
const termLabel = (term: number) => '大' + yearNumber[Math.floor(term / 2)] + ' · ' + (term % 2 === 0 ? '上学期' : '下学期')
const color = (value: string) => ({'--accent':value}) as CSSProperties

const termScenes: Scene[] = ['dorm','track','lab','library','lab','canteen','hospital','roof','hospital','classroom']
const personScenes: Record<Person,Scene> = {lin:'dorm',su:'track',chen:'lab',xu:'studio',tang:'community',shen:'stair',yan:'gate',lu:'workshop',qiao:'community',ji:'hospital',he:'canteen',zhou:'gate'}
const endingScenes: Partial<Record<Ending,Scene>> = {product:'career',writing:'career',medicine:'hospital',exploration:'career',love:'garden',distance:'station',farewell:'station',campusLove:'garden',honestLove:'cafe',brokenTrust:'station',radio:'studio',community:'community'}
const careerNames = {trial:'试做阶段',product:'医疗产品',writing:'医学科普',medicine:'继续从医'} as const

const relationshipNames = {single:'朋友',dating:'恋人',apart:'已分开'} as const
const romanceEndings = ['love','distance','farewell','campusLove','honestLove','brokenTrust']
function sceneFor(story: Story, game: Game): Scene {
  return story.scene ?? (story.id.startsWith('rel-') ? game.selected : story.id.startsWith('term-') ? termScenes[game.term] : story.person ? personScenes[story.person] : game.selected)
}

function TalentCard({game, intro=false}: {game:Game; intro?:boolean}) {
  const talents = talentsFor(game)
  return <section className="talent-card" aria-label="主角属性">
    <div className="talent-heading"><StudentPortrait variant={game.avatar ?? 0} gender={game.identity?.gender}/><div><strong>{game.identity?.name ?? '主角档案'}</strong><small>{intro ? '本周目随机生成 · 满分 100' : '成长属性 / 100'}</small></div></div>
    <dl className="talent-values">{talentIds.map(id=><div key={id}><dt>{talentLabels[id]}</dt><dd>{talents[id]}</dd></div>)}</dl>
  </section>
}

function loadBook() {
  try { return readSaveBook(localStorage.getItem(SAVE_KEY)) }
  catch { return readSaveBook(null) }
}

const saveDate = new Intl.DateTimeFormat('zh-CN',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'})
function SaveCard({slot, current, onLoad}: {slot:SaveSlot; current:boolean; onLoad:()=>void}) {
  const game = slot.game
  return <article className={`slot-card ${current?'current-slot':''}`}>
    <StudentPortrait variant={game.avatar ?? 0} gender={game.identity?.gender}/>
    <div className="slot-meta">
      <strong>{slot.game.identity?.name ? slot.label+' · '+slot.game.identity.name : slot.label}{current && <span>当前</span>}</strong>
      <small>{termLabel(game.term)} · {game.ending ? '已通关' : '行动 '+game.moves+'/'+actionLimit(game)}</small>
      <small>{slot.savedAt ? saveDate.format(slot.savedAt) : '从旧版迁入'}</small>
    </div>
    <Button icon="arrow" onClick={onLoad}>读取</Button>
  </article>
}

function Button({children, icon, onClick, primary, disabled, className = ''}: {
  children:ReactNode; icon?:string; onClick:()=>void; primary?:boolean; disabled?:boolean; className?:string
}) {
  return <button type="button" className={`button ${primary ? 'primary' : ''} ${className}`} disabled={disabled} onClick={onClick}>
    {icon && <Icon name={icon}/>}<span>{children}</span>
  </button>
}

function Dialog({title, label, children, onClose, className = ''}: {
  title:string; label:string; children:ReactNode; onClose?:()=>void; className?:string
}) {
  const ref = useRef<HTMLDialogElement>(null)
  useEffect(() => {
    const dialog = ref.current
    dialog?.showModal()
    return () => dialog?.close()
  }, [])
  return <dialog ref={ref} className={`dialog ${className}`} aria-labelledby="dialog-title" onCancel={event => {event.preventDefault(); onClose?.()}}>
    <div className="dialog-head">
      <div><div className="eyebrow">{label}</div><h2 id="dialog-title">{title}</h2></div>
      {onClose && <button className="icon-button" aria-label="关闭窗口" onClick={onClose}><Icon name="close"/></button>}
    </div>
    {children}
  </dialog>
}

function ChoiceButton({item, game, onClick, index}: {item:Choice; game:Game; onClick:()=>void; index:number}) {
  return <button className="choice" onClick={onClick} disabled={!affordable(game,item)}>
    <span className="choice-index">{String(index + 1).padStart(2,'0')}</span>
    <span className="choice-body"><strong>{item.label}</strong>{item.note && <span className="choice-note">{item.note}</span>}
      <span className="effect-list">{effectLabels(game,item.effect).map(mark => <span className={mark.positive ? 'positive' : 'negative'} key={mark.text}>{mark.text}</span>)}
      {!affordable(game,item) && <span className="negative">余额不足</span>}</span>
    </span><Icon name="chevron" size={15}/>
  </button>
}

function Header({active, goHome, open}: {active:boolean; goHome:()=>void; open:(panel:Panel)=>void}) {
  return <header className="header">
    <button className="brand" onClick={goHome} aria-label={active ? '返回主菜单' : '打开保存与退出'}>
      <span className="brand-mark"><Icon name="cross" size={21}/></span>
      <span><strong>青禾医大</strong><small>QINGHE MEDICAL</small></span>
    </button>
    <nav aria-label="游戏导航">
      <button className={active ? 'nav-button active' : 'nav-button'} onClick={goHome}><Icon name="home" size={16}/><span>{active ? '主菜单' : '暂停'}</span></button>
      <button className="nav-button" onClick={()=>open('people')}><Icon name="people" size={17}/><span>人物</span></button>
      <button className="nav-button" onClick={()=>open('archive')}><Icon name="medal" size={17}/><span>图鉴</span></button>
      <button className="nav-button" onClick={()=>open('save')}><Icon name="save" size={17}/><span>存档</span></button>
    </nav>
  </header>
}

function Menu({book, begin, resume, open}: {book:SaveBook; begin:()=>void; resume:()=>void; open:(panel:Panel)=>void}) {
  const slot = activeSlot(book)
  return <main className="menu-main">
    <div className="topline"><span><i/> 新生报到处</span><button onClick={()=>open('audio')}><Icon name="music" size={14}/> 声音与配乐</button></div>
    <section className="hero">
      <div className="hero-visual"><HeroArt/><div className="scene-stamp"><span>青禾医大 · 傍晚</span><small>18:42 / AUTUMN</small></div></div>
      <div className="hero-copy">
        <div className="eyebrow hero-kicker"><span/> 像素校园 · 叙事养成</div>
        <h1><span>医学生存模拟器</span><em>五年之约<span className="title-star">✦</span></em></h1>
        <p>从 303 宿舍到第一件白大褂。<br/>一学期一段故事，走出自己的五年。</p>
        <div className="menu-buttons">
          <Button primary icon={slot?'arrow':'play'} onClick={slot?()=>resume():begin}>{slot?'继续游戏':'开启新游戏'}</Button>
          {slot && <Button icon="flag" onClick={begin}>开启新游戏</Button>}
          <Button icon={slot?'save':'book'} onClick={()=>open(slot?'save':'help')}>{slot?'读取存档':'玩法说明'}</Button>
        </div>
      </div>
    </section>
    {slot && <section className="home-resume" aria-label="最近周目">
      <StudentPortrait variant={slot.game.avatar ?? 0} gender={slot.game.identity?.gender}/>
      <div><small>上次的校园生活</small><strong>{slot.game.identity?.name ?? slot.label} · {slot.game.ending ? '已完成五年' : termLabel(slot.game.term)}</strong></div>
      <span>{book.slots.length} 份存档</span>
    </section>}
    <div className="menu-strip">
      <div><span className="strip-icon purple"><Icon name="clock"/></span><div><strong>五年十学期</strong><small>每学期都有专题和自由行动</small></div></div>
      <div><span className="strip-icon pink"><Icon name="heart"/></span><div><strong>校园人物与关系</strong><small>不同相遇条件与交往选择</small></div></div>
      <div><span className="strip-icon gold"><Icon name="flag"/></span><div><strong>{Object.keys(endings).length} 种人生结局</strong><small>多周目存档可以并行保留</small></div></div>
    </div>
  </main>
}

function Campus({game, update, open}: {game:Game; update:(game:Game)=>void; open:(panel:Panel)=>void}) {
  const year = Math.floor(game.term / 2)
  const location = locations.find(item => item.id === game.selected)!
  const ready = game.moves >= ACTIONS_PER_TERM
  const limit = actionLimit(game)
  const notes = investigationNotes(game)
  const done = game.ending
  const story = currentStory(game)
  const actions = availableActions(game)
  const conversations = availableConversations(game)
  const last = game.grades.at(-1)
  const chapter = availableChapter(game)
  const projects = projectNotes(game)
  const activeProjects = projects.filter(item=>item.started&&!item.complete).length
  return <main className="game-main">
    <div className="topline"><span><i/> 校园生活进行中</span><span className="top-tools"><button onClick={()=>open('audio')}><Icon name="music" size={14}/> 声音</button><button onClick={()=>open('help')}>玩法说明 <Icon name="chevron" size={13}/></button></span></div>
    <section className="term-heading">
      <div><div className="eyebrow">CHAPTER {String(year+1).padStart(2,'0')} · {termLabel(game.term)}</div><h1>{years[year]}</h1></div>
      <div className="term-progress" aria-label={`第 ${game.term+1} 学期，共 ${TERM_COUNT} 学期`}><span>学期进度 <b>{String(game.term+1).padStart(2,'0')} / {TERM_COUNT}</b></span><div>{exams.map((name,i)=><i key={name} className={i < game.term || done ? 'complete' : i === game.term ? 'current' : ''}/>)}</div></div>
    </section>
    <div className="semester-board" aria-label="学期快捷操作">
      <div className="semester-card"><Icon name="clock"/><div><span>本学期剩余行动</span><strong>{Math.max(0,limit-game.moves)} <small>/ {limit}</small></strong></div></div>
      <button className="semester-card" onClick={()=>open('journal')}><Icon name="journal"/><div><span>项目与调查</span><strong>{activeProjects+notes.length} 项在册</strong></div><Icon name="chevron" size={14}/></button>
      {chapter ? <button className="semester-card chapter-available" onClick={()=>update(openChapter(game))}><Icon name="book"/><div><span>本学期专题</span><strong>{chapter.title}</strong></div><Icon name="chevron" size={14}/></button>
      : <div className="semester-card"><Icon name="flag"/><div><span>本学期考核</span><strong>{done?'已完成五年':ready?'可以参加考核':exams[game.term]}</strong></div></div>}
    </div>
    <div className="dashboard">
      <aside className="panel status-panel">
        <div className="panel-title"><Icon name="heart" size={16}/><h2>角色状态</h2></div>
        <div className="stats">
          {statIds.map(id=><div className="stat" key={id} style={color(stats[id].color)}>
            <div><span><Icon name={stats[id].icon} size={15}/>{stats[id].name}</span><strong>{id === 'cash' ? '¥ ' : ''}{game.stats[id]}</strong></div>
            {id !== 'cash' && <div className="meter" role="progressbar" aria-label={stats[id].name} aria-valuenow={game.stats[id]}><span style={{width:game.stats[id]+'%'}}/></div>}
          </div>)}
        </div>
        <TalentCard game={game}/>
        {!game.identity && relationshipFor(game) !== 'single' && <div className="relationship-status"><Icon name="heart" size={13}/> 晚晴 · {relationshipNames[relationshipFor(game)]} <b>信任 {trustFor(game)}</b></div>}
        {game.identity && <button className="relation-summary" onClick={()=>open('people')}><Icon name="heart" size={14}/> 关系册 <b>{currentPartners(game).length} 段交往</b></button>}
        <div className="status-bottom"><Icon name="bolt" size={14}/> 校园跑 <strong>{game.runs} 次</strong></div>
      </aside>
      <section className="panel map-panel">
        <div className="panel-title map-title"><Icon name="map" size={17}/><h2>校园地图</h2><span>点击地点选择行动</span></div>
        <div className="map"><MapArt/><div className="map-coords">青禾医大 / CAMPUS 01</div>
          {locations.map(item=>{
            const locked = item.unlock > game.term
            const picked = item.id === game.selected
            const label = item.id === 'lab' ? '实验楼' : item.id === 'hospital' ? '附院' : item.id === 'archive' ? '档案室' : item.id === 'stair' ? '楼梯' : item.id === 'roof' ? '天台' : item.name
            return <button className={`pin ${picked ? 'picked' : ''} ${locked ? 'locked' : ''}`} type="button" aria-label={item.name + (locked ? ' · ' + item.hint : '')} aria-pressed={picked} aria-disabled={locked} title={locked ? item.hint : item.hint + ' · ' + item.name}
              onClick={()=>update(selectLocation(game,item.id))} key={item.id} style={{...color(item.color),left:item.x+'%',top:item.y+'%'}}>
              <Icon name={locked ? 'lock' : item.icon} size={15}/><span>{label}</span>
            </button>
          })}
          <div className="map-north" aria-hidden="true"><span>▲</span>N</div>
        </div>
        <div className="map-caption"><span><i/> {location.name}</span>{!done && <button className="text-button scene-link" onClick={()=>open('scene')}>查看地点风景 <Icon name="chevron" size={13}/></button>}</div>
        {!done && <div className="place-picker"><label htmlFor="place-select">快速前往</label><select id="place-select" value={location.id} onChange={event=>{
          const destination=locations.find(item=>item.id===event.target.value)
          if (destination) update(selectLocation(game,destination.id))
        }}>{locations.filter(item=>item.unlock<=game.term).map(item=><option key={item.id} value={item.id}>{item.name}</option>)}</select></div>}
      </section>
      <section className="panel action-panel" aria-label="学期行动">
        <div className="panel-title"><Icon name="compass" size={17}/><h2>{done ? '毕业记录' : '本学期行动'}</h2></div>
        <div className="action-content">
          {!done && <SceneArt scene={location.id} compact/>}
          <div className="action-counter"><span>已用行动</span><div aria-label={game.moves + ' / ' + limit}>{Array.from({length:limit},(_,i)=><i key={i} className={i < game.moves ? 'used' : ''}/>)}</div><strong>{game.moves} / {limit}</strong></div>
          {game.career && !done && <div className="career-status"><strong>生涯 · {careerNames[game.career]}</strong>
            {game.career !== 'medicine' && <small>产品 {careerFit(game,'product')} · 科普 {careerFit(game,'writing')} / 100</small>}
          </div>}
          {done && <div className="exam-box"><span>第五学年 · 学业档案</span><h3>{endings[done].name}</h3><Button primary icon="flag" onClick={()=>open('ending')}>查看结局</Button></div>}
          {!done && ready && <div className="exam-box"><span>本学期考核</span><h3>{exams[game.term]}</h3><p>预估 <b>{examScore(game)} 分</b> · 及格线 {examTarget(game.term)} 分</p>{game.term === TERM_COUNT - 1 && !!game.clues?.length && <p>可复制为分支存档，之后读档体验不同结局。</p>}<Button primary icon="arrow" disabled={!!story} onClick={()=>update(finishTerm(game))}>{game.term === TERM_COUNT - 1 ? '参加毕业考核' : '参加考核 · 下一学期'}</Button>{!game.extraTime && <button className="extra-action" onClick={()=>update(unlockExtraTime(game))}>安排自由时段 <Icon name="arrow" size={13}/></button>}</div>}
          {!done && game.moves < limit && <><div className="location-heading" style={color(location.color)}><Icon name={location.icon} size={20}/><div><h3>{location.name}</h3><p>{location.id==='lab' ? '显微镜与实验记录' : location.id==='hospital' ? '见习与临床轮转' : location.hint}</p></div></div>
          {!!conversations.length && <div className="local-conversations"><h4>这里可以聊聊</h4>{conversations.map(item=><button key={item.id} className={`conversation-entry ${item.tone==='horror'?'investigation-entry':''}`} onClick={()=>update(openConversation(game,item.id))}><Icon name={item.kind.startsWith('恋爱')?'heart':'people'} size={15}/><span>{item.entry}</span><Icon name="chevron" size={13}/></button>)}</div>}
          <div className="choice-list">{actions.map((item,index)=><ChoiceButton key={item.label} item={item} game={game} index={index} onClick={()=>update(act(game,index))}/>)}</div></>}
        </div>
      </section>
    </div>
    <section className="panel journal">
      <div className="panel-title"><Icon name="journal" size={17}/><h2>校园日记</h2><button className="text-button" onClick={()=>open('journal')}>查看日记 <Icon name="arrow" size={15}/></button></div>
      <div className="journal-content" aria-live="polite"><span>{game.log[0]}</span><small>{notes.length ? `调查册 ${notes.length} 项` : game.clues?.length ? `结局线索 ${game.clues.length} 条` : last ? `最近考核 · ${last.grade} / ${last.score} 分` : ''}</small></div>
    </section>
  </main>
}

function App() {
  const [book,setBook] = useState(loadBook)
  const [game,setGame] = useState<Game>()
  const [panel,setPanel] = useState<Panel>()
  const [notice,setNotice] = useState('')
  const [storageIssue,setStorageIssue] = useState(false)
  const noticeTimeout = useRef<number>(undefined)
  const story = game && currentStory(game)
  const replyStory = game?.reply && currentStory({...game,pending:[game.reply.storyId]})
  const replyText = game?.reply && replyStory?.choices[game.reply.choice]?.reply
  const response = game && replyStory && replyText ? {story:replyStory,text:replyText,scene:sceneFor(replyStory,game)} : undefined
  const canLeave = isOptionalConversation(story?.id)
  const [playerName,setPlayerName] = useState('')
  const [playerGender,setPlayerGender] = useState<Gender>('male')
  const shownName = game?.identity?.name
  const close = ()=>setPanel(undefined)
  const selectedSlot = activeSlot(book)
  const pausing = panel === 'save' || panel === 'identity' || panel === 'audio'
  const soundingStory = replyStory || story
  const soundingChoice = game?.reply && replyStory ? replyStory.choices[game.reply.choice] : undefined
  const track = soundtrack(game,soundingStory || undefined,soundingChoice)
  const ending = game?.ending
  const narration = ending && panel==='ending' ? endingNarration(ending) : undefined
  const cue = !pausing ? soundingStory ? voiceCue(soundingStory,soundingChoice) : narration ? voiceCue(narration) : undefined : undefined
  const playerSpeech=soundingChoice?.playerLine ?? (soundingStory?.id==='term-0'?protagonistSample:undefined)
  const lead=!pausing&&game?.identity&&playerSpeech?protagonistCue(game.identity.gender,playerSpeech):undefined
  const sound = useAudio(track,cue,lead)
  const soundtrackInfo = musicCatalog[track]
  const endingScene = ending ? isSpecialEnding(ending) ? detours[ending].story.scene : endingScenes[ending] : undefined
  const unlockedLocations = game ? locations.filter(item=>item.unlock <= game.term) : []
  const currentLocation = unlockedLocations.findIndex(item=>item.id===game?.selected)
  const endingTone = ending && isSpecialEnding(ending) ? detours[ending].tone : undefined

  useEffect(()=>()=>window.clearTimeout(noticeTimeout.current),[])
  function notify(text: string) {
    window.clearTimeout(noticeTimeout.current)
    setNotice(text)
    noticeTimeout.current = window.setTimeout(()=>setNotice(''),3400)
  }
  function persist(next: SaveBook, required=false) {
    let merged = next
    try {
      const latest = readSaveBook(localStorage.getItem(SAVE_KEY))
      merged = mergeSaveBooks(latest,next)
      localStorage.setItem(SAVE_KEY,JSON.stringify(merged))
      setBook(merged)
      setStorageIssue(false)
      return true
    } catch {
      if (!required) setBook(merged)
      setStorageIssue(true)
      return false
    }
  }
  function update(next: Game) {
    if (game === next) return
    setGame(next)
    const saved = saveRun(book,next,Date.now())
    persist(saved)
    const newBadge = saved.badges.find(id=>!book.badges.includes(id) && id!=='arrival')
    if (newBadge) notify('成就解锁 · '+badges[newBadge].name)
    if (next.ending && !game?.ending) setPanel('ending')
  }
  function respond(index: number) {
    if (!game || !story) return
    const next = choose(game,index)
    if (next === game) return
    const reply = story.choices[index].reply
    update(reply ? {...next,reply:{storyId:story.id,choice:index}} : next)
  }
  function dismissReply() {
    if (!game?.reply) return
    const {reply,...rest} = game
    update(rest)
  }
  function browseScene(offset: number) {
    if (!game || !unlockedLocations.length) return
    const index = (currentLocation + offset + unlockedLocations.length) % unlockedLocations.length
    update(selectLocation(game,unlockedLocations[index].id))
  }
  function begin() {
    setPlayerName('')
    setPlayerGender('male')
    setPanel('identity')
  }
  function createGame(identity:Identity) {
    const [seed,idA,idB] = crypto.getRandomValues(new Uint32Array(3))
    const id = idA.toString(16).padStart(8,'0')+idB.toString(16).padStart(8,'0')
    const now = Date.now()
    const newGame = startGame(seed,true,identity)
    const latest = mergeSaveBooks(loadBook(),book)
    const previous = game ? saveRun(latest,game,now) : latest
    const next = addRun(previous,newGame,id,now)
    if (!persist(next,!!game) && game) {
      notify('保存失败，已留在当前周目')
      return
    }
    setGame(newGame)
    close()
  }
  function resume(id = book.activeId) {
    const latest = mergeSaveBooks(loadBook(),book)
    const slot = latest.slots.find(item=>item.id===id)
    if (!slot) return
    persist(selectRun(latest,slot.id))
    setGame(slot.game)
    setPanel(slot.game.ending ? 'ending' : undefined)
  }
  function goHome() {
    if (game) setPanel('save')
    else close()
  }
  function saveCurrent(exit=false) {
    if (!game || !persist(saveRun(book,game,Date.now()),true)) {
      notify('保存失败，已留在当前周目')
      return
    }
    close()
    if (exit) {
      setGame(undefined)
      notify('已保存并返回主菜单')
    } else notify('当前进度已保存')
  }
  function copyCurrent() {
    if (!game) return
    const id = Array.from(crypto.getRandomValues(new Uint32Array(2)),n=>n.toString(16).padStart(8,'0')).join('')
    const now = Date.now()
    const next = addRun(saveRun(mergeSaveBooks(loadBook(),book),game,now),game,id,now,true)
    if (persist(next,true)) notify('分支存档已创建，现在在新档继续')
    else notify('复制失败，已留在原存档')
  }

  return <div className="shell">
    <Header active={!game} goHome={goHome} open={setPanel}/>
    {game ? <Campus game={game} update={update} open={setPanel}/> : <Menu book={book} begin={begin} resume={resume} open={setPanel}/>}
    <footer><span>✦ &nbsp; 青禾校园档案</span><span>五年之约 <i/> V1.7</span><button onClick={()=>setPanel('help')}>游戏指南 <Icon name="arrow" size={13}/></button></footer>
    {storageIssue && <div className="storage-warning" role="alert">浏览器存储不可用。当前进度仍可在此页面继续。</div>}
    {sound.voiceStatus==='unavailable' && !pausing && <div className="toast" role="status">当前台词没有可用语音，可继续阅读字幕。</div>}
    {notice && <div className="toast" role="status"><Icon name="star" size={18}/>{notice}</div>}
    {!pausing && response && <Dialog key={response.story.id+'-reply'} label={response.story.person ? people[response.story.person].name : response.story.voice ?? '对话回应'} title={response.story.title} className={`story-dialog ${response.story.tone ?? ''} mood-${cue?.emotion ?? 'plain'}`}>
      <SceneArt scene={response.scene}/>
      {soundingChoice?.playerLine && <div className="player-line"><strong>{shownName ?? '你'}</strong><p>{soundingChoice.playerLine}</p></div>}
      <p className="story-text">{response.text}</p>
      <div className="story-controls"><Button primary icon="arrow" onClick={dismissReply}>继续</Button><button className="text-button" onClick={sound.replay}><Icon name="music" size={15}/> 重听</button><button className="text-button" onClick={()=>setPanel('save')}><Icon name="save" size={15}/> 存档与退出</button></div>
    </Dialog>}
    {!pausing && !response && story && game && <Dialog key={story.id} label={story.kind} title={story.title} className={`story-dialog ${story.tone ?? ''} mood-${cue?.emotion ?? 'plain'}`} onClose={canLeave ? ()=>update(leaveConversation(game)) : undefined}>
      <SceneArt scene={sceneFor(story,game)}/>
      {story.id === 'term-0' && <TalentCard game={game} intro/>}
      {story.person && <div className="speaker" style={color(people[story.person].color)}><Portrait person={story.person}/><div><strong>{people[story.person].name}</strong><small>{people[story.person].role}</small></div></div>}
      {story.voice && <div className="speaker mentor-voice"><Icon name="cross" size={17}/><strong>{story.voice}</strong></div>}
      {cue && <div className="dialogue-audio"><span>{emotions[cue.emotion]} · {voices[cue.role].label}{sound.voiceStatus==='playing'?' · 配音播放中':sound.voiceStatus==='system'?' · 本机语音播放中':''}</span><button className="text-button" onClick={sound.replay}><Icon name="music" size={15}/> {sound.settings.voice?'重听对白':'播放对白'}</button><button className="text-button" onClick={()=>setPanel('audio')}>声音设置</button></div>}
      <p className="story-text">{story.text}</p>
      {story.id==='term-0' && shownName && <p className="registration-name">{shownName}，请确认你的报到卡，再选择第一件想做的事。</p>}
      <div className="choice-list">{story.choices.map((item,index)=><ChoiceButton key={item.label} item={item} game={game} index={index} onClick={()=>respond(index)}/>)}</div>
      <div className="dialog-foot">{story.id === 'graduation-fork' ? '这次选择会决定本周目收录的结局' : canLeave ? '选择回应后用掉 1 次行动，直接返回可以换地点。' : '剧情选择不消耗行动次数'}<button className="text-button" onClick={()=>setPanel('save')}><Icon name="save" size={15}/> 存档与退出</button></div>
    </Dialog>}
    {panel === 'audio' && <Dialog label="青禾校园 · 声音控制" title="声音与配乐" onClose={close} className="audio-dialog">
      <div className="now-playing"><Icon name="music" size={24}/><div><strong>{soundtrackInfo.title}</strong><small>{soundtrackInfo.usage} · {({off:'音乐已关闭',locked:'点一下页面即可恢复',loading:'正在载入',playing:'正在播放',error:'播放不可用，可重开开关重试'})[sound.musicStatus]}</small></div></div>
      <div className="audio-controls">
        <label><span><strong>背景音乐</strong><small>切换场景时淡入淡出</small></span><input type="checkbox" checked={sound.settings.music} onChange={event=>sound.change({music:event.target.checked})}/></label>
        <label><span>音乐音量</span><input type="range" min="0" max="100" value={sound.settings.musicLevel} onChange={event=>sound.change({musicLevel:Number(event.target.value)})}/><output>{sound.settings.musicLevel}%</output></label>
        <label><span><strong>角色语音</strong><small>有台词时自动降低配乐</small></span><input type="checkbox" checked={sound.settings.voice} onChange={event=>sound.change({voice:event.target.checked})}/></label>
        <label><span>语音音量</span><input type="range" min="0" max="100" value={sound.settings.voiceLevel} onChange={event=>sound.change({voiceLevel:Number(event.target.value)})}/><output>{sound.settings.voiceLevel}%</output></label>
      </div>
      <details className="music-credits"><summary>曲目与授权 · {Object.keys(musicCatalog).length} 首</summary><p>音乐由 Kevin MacLeod 发布，游戏使用经剪辑及响度处理的片段，《Gymnopedie No. 1》原曲为 Erik Satie。<a href="https://creativecommons.org/licenses/by/4.0/" target="_blank" rel="noreferrer">CC BY 4.0</a></p><ul>{Object.values(musicCatalog).map(item=><li key={item.isrc}><a href={'https://incompetech.com/music/royalty-free/index.html?isrc='+item.isrc} target="_blank" rel="noreferrer">{item.title}</a><span>{item.usage}</span></li>)}</ul><p>合成普通话语音使用 <a href="https://k2-fsa.github.io/sherpa/onnx/tts/pretrained_models/vits.html" target="_blank" rel="noreferrer">Sherpa-ONNX / AISHELL-3</a>，部分动态文本可使用设备的本地普通话语音。</p></details>
    </Dialog>}
    {!response && !story && panel === 'scene' && game && <Dialog label="青禾校园 · 地点图景" title={unlockedLocations[currentLocation]?.name ?? '校园风景'} onClose={close} className="scene-dialog">
      <SceneArt scene={game.selected}/>
      <div className="scene-controls"><Button onClick={()=>browseScene(-1)}>上一个地点</Button><small>{currentLocation + 1} / {unlockedLocations.length}</small><Button onClick={()=>browseScene(1)}>下一个地点</Button></div>
    </Dialog>}
    {!response && !story && panel === 'help' && <Dialog label="新生手册" title="怎么玩" onClose={close}>
      <div className="help-list"><p><b>01 · 逛校园</b>每学期先安排 3 次行动，之后可参加考核，或再安排 1 个自由时段。换地点不扣行动。学校的实验楼、社区站和附院会随学期开放。</p><p><b>02 · 应对考试周</b>学业是考核的主要得分来源，精神和体力也有影响。待补修过多，或毕业时学业太低，会触发延毕。</p><p><b>03 · 赴约</b>和同学互动能增加好感，解锁各自的羁绊剧情。持续投入一种生活方式，也会改变毕业结局。可以随时在地图换地点并兼顾不同关系。对话会影响好感和信任。关系册显示交往约定和隐瞒风险。毕业前的安排也会改变两个人的去向。地图上偶尔会多出一项特别行动。恐怖调查可以分学期完成，校园日记会提示下一步。留下最终证据后，毕业考核后可以选择是否赴约。</p><p><b>04 · 主角成长</b>容貌代表打理形象和呈现状态，性格代表相处与沟通能力。初识时，苏晚晴的好感加权为容貌 65%、性格 35%，熟悉后为容貌 20%、性格 80%。智慧主要影响考核，科研还看创意，临床同时看智慧、性格和韧性。行动会提升属性，85 分后成长趋缓。</p><p><b>05 · 从医或转行</b>大三下可报名试做，大五上选择继续从医、医疗产品或科普。产品适配偏创意与智慧，科普偏性格与创意。作品集能提高适配分，毕业时达到 {careerTarget} 分会进入该职业，否则进入探索结局。</p><p><b>06 · 留个存档</b>每个周目各自自动保存。可在对话中保存退出，也可复制当前进度另走一条路线。新游戏会另开存档。</p></div>
      <Button primary onClick={close}>合上手册</Button>
    </Dialog>}
    {!response && !story && panel === 'people' && <Dialog label="人物档案" title="在青禾遇见的人" onClose={close}>
      {(game ?? selectedSlot?.game) && <TalentCard game={(game ?? selectedSlot?.game)!}/>}
      {game?.identity && <section className="relationship-book"><h3>{game.identity.name}的关系册</h3><p>交往 {currentPartners(game).length} 段 · 隐瞒风险 {game.loveLife?.risk ?? 0} / 100</p>
        {eligiblePeople(game).map(id=>{
          const record=game.loveLife?.records[id]
          const stage=record ? ({friend:'朋友',interested:'有好感',dating:'交往中',estranged:'不往来'})[record.stage] : '未建立私人联系'
          const agreement=record?.agreement ? ({open:'知情开放',hidden:'尚未坦白',exclusive:'排他约定'})[record.agreement] : ''
          return <div className="relationship-row" key={id}><Portrait person={id}/><div><strong>{people[id].name} · {stage}</strong><small>{record ? `好感 ${record.affection} · 信任 ${record.trust}${agreement?' · '+agreement:''}` : candidates[id].hint}</small></div></div>
        })}
      </section>}
      <div className="people-list">{personIds.map(id=><article className="person" key={id} style={color(people[id].color)}>
        <Portrait person={id}/><div><h3>{people[id].name} <small>{people[id].role}</small></h3><p>{people[id].bio}</p>
        {game && <div className="bond"><span>羁绊 {bondFor(game,id)} / 100{id==='su' && relationshipFor(game)!=='single' ? ' · '+relationshipNames[relationshipFor(game)]+' · 信任 '+trustFor(game) : ''}</span><div className="meter"><span style={{width:bondFor(game,id)+'%'}}/></div></div>}</div>
      </article>)}</div>
    </Dialog>}
    {!response && !story && panel === 'archive' && <Dialog label="收藏档案" title="成就与结局图鉴" onClose={close} className="archive-dialog">
      <h3 className="archive-title">成就 <span>{book.badges.length} / {Object.keys(badges).length}</span></h3>
      <div className="collection">{(Object.keys(badges) as Badge[]).map(id=>{
        const badge=badges[id], unlocked=book.badges.includes(id), hidden='hidden' in badge && !unlocked
        return <div className={unlocked?'collected':'uncollected'} key={id}><Icon name={hidden?'lock':badge.icon}/><div><b>{hidden?'未发现的秘密':badge.name}</b><small>{hidden?'继续探索校园':unlocked && 'hidden' in badge ? '已发现秘密成就' : badge.text}</small></div></div>
      })}</div>
      <h3 className="archive-title">结局 <span>{book.endings.length} / {Object.keys(endings).length}</span></h3>
      <div className="collection">{(Object.keys(endings) as Ending[]).map(id=>{
        const unlocked = book.endings.includes(id)
        const tone = isSpecialEnding(id) ? detourTones[detours[id].tone] : romanceEndings.includes(id) ? '关系' : id==='radio'?'电台':id==='community'?'社区':endingScenes[id] ? '生涯' : undefined
        return <div className={unlocked?'collected':'uncollected'} key={id}><Icon name={unlocked?endings[id].icon:'lock'}/><div><b>{unlocked?endings[id].name:'未收录结局'}</b>{tone && <small>{tone}支线</small>}</div></div>
      })}</div>
    </Dialog>}
    {panel === 'save' && <Dialog label="校园档案 · 进度管理" title={game?'保存与退出':'选择存档'} onClose={close} className="save-dialog">
      {game && <div className="pause-summary"><StudentPortrait variant={game.avatar ?? 0} gender={game.identity?.gender}/><div><strong>{selectedSlot?.label ?? '当前周目'}</strong><small>{termLabel(game.term)} · {currentStory(game)?.title ?? '行动 '+game.moves+'/'+actionLimit(game)}</small></div></div>}
      {game && <div className="save-buttons">
        <Button primary icon="save" onClick={()=>saveCurrent()}>保存并继续</Button>
        <Button icon="home" onClick={()=>saveCurrent(true)}>保存并退出</Button>
        <Button icon="flag" onClick={begin}>保存并开启新游戏</Button>
        <Button icon="journal" onClick={copyCurrent}>复制为分支存档</Button>
      </div>}
      {notice && <p className="save-feedback" role="status">{notice}</p>}
      <h3 className="archive-title">已保存周目 <span>{book.slots.length} 份</span></h3>
      <div className="slot-list">
        {[...book.slots].sort((a,b)=>b.savedAt-a.savedAt).map(slot=><SaveCard key={slot.id} slot={slot} current={slot.id===book.activeId} onLoad={()=>resume(slot.id)}/>)}
        {!book.slots.length && <p className="muted">还没有存档。新游戏会自动建立一个独立存档。</p>}
      </div>
      {!game && <Button icon="flag" onClick={begin}>开启新游戏</Button>}
      <p className="muted">存档保存在此浏览器。在线版和离线版各自保存进度。</p>
    </Dialog>}
    {panel === 'identity' && <Dialog label="青禾医大 · 新生报到" title="创建你的主角" onClose={()=>setPanel(game?'save':undefined)}>
      <form className="identity-form" onSubmit={event=>{
        event.preventDefault()
        const name=normalizeName(playerName)
        if (name) createGame({name,gender:playerGender})
      }}>
        <label className="name-field">主角姓名<input autoFocus value={playerName} maxLength={32} autoComplete="off" placeholder="输入姓名（最多 16 字）" onChange={event=>setPlayerName(event.target.value)}/></label>
        <fieldset><legend>选择主角性别</legend>{(['male','female'] as const).map(gender=><label key={gender} className={playerGender===gender?'identity-selected':''}><input type="radio" name="player-gender" value={gender} checked={playerGender===gender} onChange={()=>setPlayerGender(gender)}/>{gender==='male'?'男主角':'女主角'}</label>)}</fieldset>
        <button type="button" className="button" onClick={()=>sound.playSample(protagonistCue(playerGender,protagonistSample))}><Icon name="music" size={16}/>试听当前声线</button>
        <p className="muted">每种性别有五位可发展的异性。有些人需要达成条件，也可能在这个周目错过。</p>
        {game && <p className="muted">开始后会保存当前周目，并为新角色建立独立存档。</p>}
        {notice && <p className="save-feedback" role="status">{notice}</p>}
        <button type="submit" className="button primary" disabled={!normalizeName(playerName)}><Icon name="play"/> {game?'保存并报到':'完成报到'}</button>
      </form>
    </Dialog>}
    {!response && !story && panel === 'journal' && game && <Dialog label="青禾校园档案" title={game.identity?game.identity.name+'的校园日记':'校园日记'} onClose={close}>
      {!!investigationNotes(game).length && <section className="casebook"><h3>调查册</h3>{investigationNotes(game).map(note=><div key={note.title}><strong>{note.title}</strong><p>{note.step}</p></div>)}</section>}
      {!!projectNotes(game).length && <section className="project-board"><h3>校园项目</h3>{projectNotes(game).map(item=><article key={item.title}><div><strong>{item.title}</strong><small>{item.detail}{item.location?' · '+item.location.name:''}</small></div>{item.location && !game.ending && <Button icon="arrow" onClick={()=>{update(selectLocation(game,item.location!.id));close()}}>前往</Button>}</article>)}</section>}
      <ol className="timeline">{game.log.map((entry,index)=><li key={index}>{entry}</li>)}</ol>
      {!!game.grades.length && <div className="transcript"><h3>考核记录</h3>{game.grades.map((item,index)=><div key={index}><span>{exams[index]}</span><b>{item.score} 分 · {item.grade}</b></div>)}</div>}
    </Dialog>}
    {!response && !story && panel === 'ending' && game && ending && <Dialog label={endingTone ? detourTones[endingTone] + '支线 / 结局已收录' : '五年之约 / 结局已收录'} title={endings[ending].name} onClose={close} className={`ending-dialog ${endingTone ?? ''}`}>
      <div className="ending-art">{endingScene ? <SceneArt scene={endingScene}/> : <HeroArt/>}<span><Icon name={endings[ending].icon} size={30}/></span></div>
      <button className="text-button ending-voice" onClick={sound.replay}><Icon name="music" size={15}/> 听结局旁白</button>
      <p className="story-text ending-text">{endings[ending].text}</p>
      {endingEpilogue(game) && <p className="story-text ending-epilogue">{endingEpilogue(game)}</p>}
      <div className="ending-stats"><span>考核 {game.grades.length} 次</span><span>优秀 {game.grades.filter(item=>item.grade==='优秀').length} 次</span><span>校园跑 {game.runs} 次</span></div>
      <div className="dialog-actions"><Button icon="home" onClick={()=>saveCurrent(true)}>保存并返回主菜单</Button><Button primary icon="flag" onClick={begin}>保存并开启新游戏</Button></div>
    </Dialog>}
  </div>
}

createRoot(document.getElementById('root')!).render(<App/>)
