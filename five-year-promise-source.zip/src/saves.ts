import { badges, endings } from './content.ts'
import type { Badge, Ending } from './content.ts'
import { readProfile, recordGame, restoreGame } from './game.ts'
import type { Game } from './game.ts'

export type SaveSlot = {id:string; label:string; savedAt:number; game:Game}
export type SaveBook = {version:2; activeId?:string; slots:SaveSlot[]; badges:Badge[]; endings:Ending[]}

const emptyBook = (): SaveBook => ({version:2,slots:[],badges:[],endings:[]})

export function activeSlot(book: SaveBook) {
  return book.slots.find(slot=>slot.id===book.activeId)
}

export function readSaveBook(raw: string | null): SaveBook {
  if (!raw) return emptyBook()
  try {
    const data = JSON.parse(raw)
    if (data?.version===1) {
      const old = readProfile(raw)
      const slots: SaveSlot[] = []
      if (old.auto) slots.push({id:'legacy-auto',label:'原自动档',savedAt:0,game:old.auto})
      if (old.manual) slots.push({id:'legacy-manual',label:'原手动档',savedAt:0,game:old.manual})
      return {version:2,slots,activeId:slots[0]?.id,badges:old.badges,endings:old.endings}
    }
    if (data?.version!==2 || !Array.isArray(data.slots)) return emptyBook()
    const slots: SaveSlot[] = []
    for (const item of data.slots) {
      if (!item || typeof item.id!=='string' || !item.id || slots.some(slot=>slot.id===item.id)) continue
      const game = restoreGame(item.game)
      if (!game) continue
      slots.push({id:item.id,label:typeof item.label==='string' && item.label.trim() ? item.label.slice(0,32) : '校园存档',
        savedAt:Number.isSafeInteger(item.savedAt) && item.savedAt>=0 && item.savedAt<=8.64e15 ? item.savedAt : 0,game})
    }
    return {version:2,slots,activeId:slots.find(slot=>slot.id===data.activeId)?.id ?? slots[0]?.id,
      badges:Array.isArray(data.badges) ? data.badges.filter((id:Badge)=>Object.hasOwn(badges,id)) : [],
      endings:Array.isArray(data.endings) ? data.endings.filter((id:Ending)=>Object.hasOwn(endings,id)) : []}
  } catch {
    return emptyBook()
  }
}

export function saveRun(book: SaveBook, game: Game, savedAt: number): SaveBook {
  if (!activeSlot(book)) return book
  const {badges,endings} = recordGame({version:1,badges:book.badges,endings:book.endings},game)
  const slots = book.slots.map(slot=>slot.id===book.activeId?{...slot,game,savedAt}:slot)
  return {...book,slots,badges,endings}
}

export function addRun(book: SaveBook, game: Game, id: string, savedAt: number, copy=false): SaveBook {
  if (book.slots.some(slot=>slot.id===id)) return book
  const label = (copy ? '分支存档 ' : '周目 ') + String(book.slots.length+1).padStart(2,'0')
  return saveRun({...book,activeId:id,slots:[...book.slots,{id,label,savedAt,game}]},game,savedAt)
}

export function selectRun(book: SaveBook, id: string): SaveBook {
  return book.slots.some(slot=>slot.id===id) ? {...book,activeId:id} : book
}

export function mergeSaveBooks(latest: SaveBook, incoming: SaveBook): SaveBook {
  const slots = new Map(latest.slots.map(slot=>[slot.id,slot]))
  for (const slot of incoming.slots) {
    if ((slots.get(slot.id)?.savedAt ?? -1) <= slot.savedAt) slots.set(slot.id,slot)
  }
  const endings = [...new Set([...latest.endings,...incoming.endings])]
  const badges = [...new Set([...latest.badges,...incoming.badges])]
  if (endings.length>=3 && !badges.includes('replay')) badges.push('replay')
  return {...incoming,slots:[...slots.values()],badges,endings}
}
