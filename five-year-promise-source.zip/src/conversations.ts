import { phaseDialogues } from './phase-dialogues.ts'
import type { Choice, Effect, LocationId, Story, ThreadFlag } from './content.ts'

export type Conversation = Story & {
  location: LocationId
  unlock: number
  through?: number
  minBond?: number
  requires?: 'single' | 'dating' | 'apart'
  entry: string
  needs?: ThreadFlag
  until?: ThreadFlag
  untilClue?: 'ward' | 'roommate'
}
export const say = (label: string, effect: Effect, reply: string, weight=1): Choice =>
  ({label, effect:{...effect,contextWeight:weight}, reply})

export const conversations: Conversation[] = [
  ...phaseDialogues,
  {id:'talk-track',location:'track',unlock:0,person:'su',entry:'找晚晴聊聊配速',kind:'校园对话',title:'慢半步也可以',scene:'track',
    text:'苏晚晴看了眼手表，关掉了配速提示。「有几圈我就是想慢一点。你平时怎么决定什么时候该停？」',
    choices:[
      say('问她今天想怎么跑，陪她按自己的速度走',{bond:{su:8},mind:4,route:{love:1},growth:{character:1}},'「那这圈不用看表。」她把手表转到腕内。',1.25),
      say('约她轮流领跑，把最后一圈留给她定速度',{bond:{su:7},body:7,route:{love:1}},'「成交。下次我来提醒你慢一点。」',1.15),
      say('拿出自己的成绩，催她再快一点',{bond:{su:-5},body:4},'「你先跑吧。我想照自己的节奏。」',1.15),
    ]},
  {id:'talk-library',location:'library',unlock:1,person:'su',minBond:20,entry:'和晚晴拼桌复习',kind:'校园对话',title:'窗边的两份讲义',scene:'library',
    text:'桌上摊开两份讲义。苏晚晴用笔点了点一道题。「我能背下来，可让我讲给别人听，就不知道从哪开始。」',
    choices:[
      say('轮流用自己的话讲，再一起改讲义',{bond:{su:7},study:8,trust:4,route:{honors:2},growth:{wisdom:2}},'「等我把这一段抄下来。你下一题也别光背。」',1.4),
      say('合上讲义，先问问她最近在担心什么',{bond:{su:8},mind:6,trust:5,route:{love:1}},'她压低声音说：「其实我是在想，实习以后还能不能这样坐一会儿。」',.8),
      say('替她把题都做完，让她直接抄答案',{bond:{su:-5},study:4,trust:-3},'她没接过纸。「我想弄明白，我可以再试一次。」',1.2),
    ]},
  {id:'talk-roof',location:'roof',unlock:2,person:'su',minBond:35,entry:'去天台找晚晴',kind:'校园对话',title:'夜风里没说完的话',scene:'roof',
    text:'楼顶看得见最后一班公交。晚晴说这周她不太想跑，然后沉默了很久。你们听着楼下的车门一开一合。',
    choices:[
      say('等她说完，再问希望我怎么陪她',{bond:{su:10},trust:8,mind:5,route:{love:2},growth:{character:2}},'「你陪我站在这儿就行。」过了一会儿，她把刚才没说完的那句接上。',1.35),
      say('把自己最近的烦心事也讲给她',{bond:{su:8},trust:6,mind:6,route:{love:1}},'「原来你也会想这么多。」她挪开一步，给你腾出靠栏杆的位置。',1.1),
      say('说大家都一样，别再想这件事了',{bond:{su:-9},trust:-10},'她点了下头。「那今晚就到这里吧。」',1.25),
    ]},
  {id:'talk-ask',location:'garden',unlock:2,person:'su',minBond:56,requires:'single',entry:'在银杏树下和晚晴谈谈关系',kind:'关系转折',title:'先从一次约会开始',scene:'garden',
    text:'晚晴把捡到的两片叶子叠在一起。「我有时候分不清，你是想找个一起跑步的人，还是想多认识我一点。」',
    choices:[
      say('认真问她愿不愿意和我约会',{bond:{su:9},relationship:'dating',trust:5,route:{love:2}},'「愿意。」她把其中一片叶子给了你，「但下次你要提早约。」',1.1),
      say('告诉她我想继续做朋友，照常一起跑',{bond:{su:5},route:{friends:1}},'「好。那下次还是我来领跑。」'),
      say('含糊地说现在聊这些太麻烦',{bond:{su:-7}},'她把叶子塞回书里。「好，那先不聊了。」'),
    ]},
  {id:'date-roof',location:'roof',unlock:3,person:'su',requires:'dating',entry:'和晚晴谈谈最近的相处',kind:'恋爱长谈',title:'先把彼此的话听完',scene:'roof',
    text:'晚晴没有像往常那样带汽水。「有些时候我觉得你很想和我在一起，有些时候又觉得你根本没听见我。你怎么想？」',
    choices:[
      say('请她举个例子，再一起约定怎样提醒对方',{bond:{su:10},trust:12,route:{love:2}},'「可以。以后我说慢一点，你就停下来听我讲。」',1.35),
      say('说自己需要喘口气，商量一段各忙各的时间',{bond:{su:2},trust:4,mind:6},'「那就各忙到周日，周日再打个电话。」'),
      say('坦白想结束恋爱，认真听她的回应',{bond:{su:-4},relationship:'apart',plan:'open',trust:-5},'她沉默了一阵。「至少今天，我们都把话说清楚了。」'),
      say('反问她为什么总把事情想得这么严重',{bond:{su:-10},trust:-14},'她转过身去看路灯。「等我们都愿意听的时候，再谈吧。」',1.3),
    ]},
  {id:'date-garden',location:'garden',unlock:2,person:'su',requires:'dating',entry:'约晚晴走银杏小径',kind:'恋爱约会',title:'两把伞之间',scene:'garden',
    text:'雨停了，你们还各撑着一把伞。晚晴把两张车票从书页里取出来。「下次见面是什么时候？我想在日历上真的画个圈。」',
    choices:[
      say('一起翻日历，约一个两个人都空的下午',{bond:{su:10},trust:10,mind:5,route:{love:2}},'「那天我来接你。」她把约好的日期写在自己的车票背面。',1.3),
      say('给她拍张雨后的照片，聊聊今天看到的事',{bond:{su:8},trust:4,mind:7,route:{love:1}},'她挑了张你没摆好姿势的照片。「这张留给我。」'),
      say('先应下周末，等有空再改时间',{bond:{su:-8},trust:-12},'「我能接受你没空，」她把日历收起来，「我想听的是你哪天真的有空。」',1.25),
    ]},
  {id:'date-cafe',location:'canteen',unlock:3,person:'su',requires:'dating',entry:'约晚晴去食堂窗边',kind:'恋爱约会',title:'靠窗的两杯热茶',scene:'cafe',
    text:'晚晴把菜单翻到背面，上面有她手画的两张排班表。「下周我两天都晚班。你更想一起吃饭，还是一起把明天的宣教卡做完？」',
    choices:[
      say('各自说说这周的难处，再约能见面的时间',{bond:{su:10},trust:10,mind:5,route:{love:1}},'「那就周三。到时我先排队，你直接来找我。」',1.25),
      say('一起改宣教卡，做完再出去走走',{bond:{su:8},trust:6,study:6,route:{clinic:2},growth:{creativity:1}},'「你读一遍，我看哪里听不懂。」她把笔挪到桌子中间。',1.1),
      say('一边看手机一边说「都行，你定」',{bond:{su:-8},trust:-9},'她把两张表折回去。「等你有空认真聊，我们再定。」',1.2),
    ]},
  {id:'talk-reconcile',location:'garden',unlock:3,person:'su',minBond:40,requires:'apart',entry:'问晚晴愿不愿意再谈一次',kind:'关系转折',title:'把昨天的话说完',scene:'garden',
    text:'晚晴答应走到路灯底下聊十分钟。「你上次说我们应该分开。现在想再谈，你觉得自己会做什么不同的事？」',
    choices:[
      say('道歉，说清会怎么做，也给她拒绝的余地',{bond:{su:8},trust:7,relationship:'dating',plan:'open',route:{love:1}},'「那就从一件小事重新开始。」她等你走到身边，再一起往回走。',1.1),
      say('承认遗憾，商量怎么作为朋友相处',{bond:{su:4},mind:5,route:{friends:2}},'「可以。」她把伞往你这边偏了一点。'),
      say('把责任都推给她，要求今天给个答案',{bond:{su:-12},trust:-8},'「今天到这儿。」她往亮着灯的校门走去。'),
    ]},
  {id:'talk-room',location:'dorm',unlock:0,person:'lin',entry:'和小满商量宿舍安排',kind:'室友对话',title:'303 的熄灯时间',scene:'dorm',
    text:'林小满把闹钟放到你桌上。她明早要早起，你今晚还差两章。「要不咱们定个谁都能睡得着的办法？」',
    choices:[
      say('商量台灯和闹钟的安排，轮流让一步',{bond:{lin:10},mind:5,route:{friends:2},growth:{character:2}},'「成。你去自习室前拿我那把伞。」',1.3),
      say('约好早晨一起过两章，今晚都早点睡',{bond:{lin:7},study:6,body:5,route:{honors:1}},'她在闹钟旁放了两张便签。「我叫醒你，你负责讲第一章。」',1.1),
      say('当没听见，继续开外放听课',{bond:{lin:-9},study:4},'她戴上耳塞，第二天早上也没叫你。',1.2),
    ]},
  {id:'talk-window',location:'canteen',unlock:1,person:'lin',minBond:15,entry:'陪小满吃顿晚饭',kind:'室友对话',title:'晚一点也能留个座',scene:'cafe',
    text:'小满把背包从空座上挪开。她这两周跑社团和实习宣讲跑得很累，却没想好该推掉哪一件。',
    choices:[
      say('问她最想保留什么，一起给其他安排留退路',{bond:{lin:10},mind:6,route:{friends:2}},'「我其实只想把周六空出来。」她总算把招募群的通知静音。',1.2),
      say('提议一起试做志愿活动的排班表',{bond:{lin:7},social:8,route:{friends:2},growth:{creativity:2}},'她把纸巾铺平：「你写人名，我画时间。」'),
      say('替她选，告诉她这个问题没什么好纠结',{bond:{lin:-6}},'「我想的是问你能不能听我说一会儿。」',1.15),
    ]},
  {id:'talk-lab',location:'lab',unlock:2,person:'chen',entry:'和一舟一起看实验数据',kind:'科研对话',title:'结果之外的那列数据',scene:'lab',
    text:'一舟把键盘推过来。有一列结果和预期不一样。「你先看原始记录。我们可以重做，也可以先确认最初的问题值不值得问。」',
    choices:[
      say('标出偏差，和他设计一个复验对照',{bond:{chen:10},study:9,route:{lab:3},growth:{wisdom:2,creativity:2}},'「你写复验目的。我来找上一批的数据。」',1.35),
      say('先讨论怎么把失败讲给下一届听',{bond:{chen:7},study:5,route:{lab:1,friends:1}},'「可以，把我第一次做错的步骤也写进去。」'),
      say('只挑看起来好看的结果交差',{bond:{chen:-11},study:2},'他把文件切回原始表。「这一列得留着。报告你可以先别署名。」',1.25),
    ]},
  {id:'talk-research',location:'library',unlock:3,person:'chen',minBond:20,entry:'听一舟聊研究选题',kind:'科研对话',title:'从摘要里退一步',scene:'library',
    text:'一舟拿着打印出来的摘要在窗边发呆。「我们写了整整一页，还是没说清楚这件事跟谁有关。」',
    choices:[
      say('问这项研究要帮谁，再重写第一个问题',{bond:{chen:9},study:6,route:{lab:2},growth:{creativity:2}},'他划掉两行。「这一句可以留，终于有人听得懂了。」',1.2),
      say('一起对照参考文献，弄清前人回答到了哪',{bond:{chen:6},study:9,route:{honors:2,lab:1}},'「给我个页码。我想把原文也看一遍。」',1.25),
      say('建议直接照着热门题目换个标题',{bond:{chen:-7}},'「那就得先想清楚，我们为什么做它。」'),
    ]},
  {id:'talk-mentor',location:'hospital',unlock:6,voice:'许老师 · 临床带教',entry:'和带教复盘床旁沟通',kind:'临床对话',title:'病人离开后的三分钟',scene:'hospital',
    text:'患者家属走后，许老师合上记录夹。「你记得她问了什么。那你觉得，她最想确认的是什么？」',
    choices:[
      say('复述患者的担忧，问如何解释得更明白',{study:7,social:6,route:{clinic:3},growth:{character:2,wisdom:1}},'「下次先问问她听懂了哪一部分，再从那里往下讲。」'),
      say('请老师一起把告知单改成家属能读懂的句子',{study:6,route:{clinic:2},growth:{creativity:2}},'「你先写第一版，明天我们一起听听家属怎么说。」'),
      say('只复述报告术语，先回办公室整理笔记',{study:5,route:{honors:1}},'「笔记可以晚点写。下次多留一分钟听她讲。」'),
    ]},
  {id:'talk-career',location:'hospital',unlock:8,voice:'许老师 · 临床带教',entry:'和带教重新讨论毕业去向',kind:'生涯对话',title:'允许改一次的志愿表',scene:'career',
    text:'许老师把三张去向表并排放好。「可以改主意。之前做过的项目都算数。你现在更想往哪个方向走？」',
    choices:[
      say('选择继续从医，报名临床轮转',{career:'medicine',route:{clinic:1}},'「下周跟我看一次交班。也把你做过的项目带上。」'),
      say('改投医疗产品，继续做候诊原型',{career:'product'},'「你这几个月看到的问题，值得带去和团队讨论。」'),
      say('改投医学科普，继续准备作品集',{career:'writing'},'「记得拿一篇给家属读一遍，再去投。」'),
      say('先保留现在的打算，回去再想想',{},'「想好了可以再来。这个决定该由你来做。」'),
    ]},
  {id:'talk-radio',location:'archive',unlock:0,person:'xu',entry:'问徐知遥能不能试听旧录音',kind:'校园电台',title:'声音也有借阅单',scene:'studio',until:'radio-start',
    text:'徐知遥把磁带卡进机仓。里面有一位女生在读自己的告别信。知遥按了暂停：「我们想做一期旧校园的节目。先得确认她愿不愿意让别人听见。」',
    choices:[
      say('一起找当事人，问清哪一段能播',{bond:{xu:11},milestone:'radio-start',growth:{character:2}},'「先写她可以随时反悔。我们有时间等。」'),
      say('先帮她整理不涉及个人经历的环境声',{bond:{xu:6},mind:6,growth:{creativity:2}},'「那就从熄灯铃开始。这个我们自己也听过。」'),
      say('建议直接放出去，删掉姓名就行',{bond:{xu:-8}},'她关上机仓。「我想问的是同不同意，不是谁能认出来。」'),
    ]},
  {id:'talk-radio-edit',location:'archive',unlock:2,person:'xu',minBond:12,needs:'radio-start',until:'radio-finish',entry:'和知遥剪毕业回声',kind:'校园电台',title:'空白的五秒',scene:'studio',
    text:'一个受访者发来消息，撤回了刚录完的故事。那段故事正好接在结尾。徐知遥把时间轴停在删掉的位置，等你说话。',
    choices:[
      say('删掉故事，问她愿不愿意只留下窗外的风',{bond:{xu:13},milestone:'radio-finish',growth:{creativity:3,character:2}},'「好。她说可以留风。那就让风吹满五秒。」',1.2),
      say('重排提纲，邀请一位同意公开的受访者讲新版本',{bond:{xu:10},milestone:'radio-finish',study:4},'「我去约时间。这次我们把撤回期限留长一点。」'),
      say('说快到截稿时间，想把撤回的内容照常放进去',{bond:{xu:-10}},'她摘下耳机。「这期可以晚发。那段不会发。」'),
    ]},
  {id:'talk-radio-listen',location:'archive',unlock:2,person:'xu',needs:'radio-start',entry:'跟知遥试听街角的声音',kind:'校园电台',title:'有人认出了那扇铁门',scene:'studio',
    text:'校园录音里有三次金属碰撞。知遥猜是旧宿舍的门，却记不清声音是从里头传出来，还是从走廊传进去。',
    choices:[
      say('分开比较录音和实地的声响',{bond:{xu:6},study:5,growth:{wisdom:2}},'「这一段可以标时间，门的位置写待确认。」'),
      say('请她教我留出停顿，让听众自己听',{bond:{xu:8},mind:5,growth:{creativity:2}},'她摘下一侧耳机，示意你也听一会儿。'),
    ]},
  {id:'talk-community',location:'community',unlock:3,person:'tang',until:'care-start',entry:'陪唐禾走一遍社区服务台',kind:'社区协作',title:'走到第三扇门的人',scene:'community',
    text:'唐禾指着登记纸上一条折痕。来访者已经换过两次队，这回直接离开了。「能不能跟我走一遍？就当我们第一次来。」',
    choices:[
      say('从大门走起，邀请愿意帮忙的人指出哪里卡住',{bond:{tang:11},milestone:'care-start',social:5,route:{clinic:1}},'「先从门口那一级台阶记起，别急着画箭头。」',1.2),
      say('先陪她把服务台挪到容易看见的地方',{bond:{tang:7},body:-3,route:{friends:1}},'「能看见以后再看看，还有谁走不到这里。」'),
      say('说贴一张大字海报就够了，省得挨个问',{bond:{tang:-7}},'唐禾把铅笔夹回本子里。「可是有人一路都在看地上。」'),
    ]},
  {id:'talk-community-check',location:'community',unlock:3,person:'tang',needs:'care-start',entry:'和唐禾核对来访留言',kind:'社区协作',title:'请把字写得大一点',scene:'community',
    text:'有人在留言纸上画了一个很大的箭头，旁边只有一句话：「看不清哪边是出口。」唐禾把笔递给你，问今晚先改哪一块。',
    choices:[
      say('把字放大，请愿意帮忙的来访者走一遍',{bond:{tang:8},social:4,growth:{character:2}},'「这样才知道我们改的是他们的问题。」'),
      say('把旧图和新图一起留下，标清改动的原因',{bond:{tang:6},study:5,growth:{creativity:2}},'「下周他们想再改，至少知道我们为什么这样画。」'),
    ]},
  {id:'talk-community-plan',location:'community',unlock:5,person:'tang',needs:'care-start',minBond:12,until:'care-finish',entry:'和唐禾把工作交给下一班',kind:'社区协作',title:'谁在下周接班',scene:'community',
    text:'新标牌已经摆好。唐禾问你：「毕业以后还有人接这个摊吗？我们得让下一班知道，哪些地方已经试过，哪些还得改。」',
    choices:[
      say('写一页可改的交接单，约新人一起试一遍',{bond:{tang:13},milestone:'care-finish',route:{clinic:2},growth:{character:2}},'「把空白留大一点。他们应该可以写自己的办法。」',1.25),
      say('征求来访者意见，再把过程记录给接班人',{bond:{tang:11},milestone:'care-finish',route:{friends:2}},'「我来问，下次你把记录念给新人听。」'),
      say('把东西全收好，打算有空自己再来管',{bond:{tang:-6},mind:-2},'「有空回来当然好。可下个星期也得有人做。」'),
    ]},
  {id:'talk-shift',location:'stair',unlock:6,person:'shen',entry:'找沈棠核对夜班巡检表',kind:'夜班对话',title:'只有一楼的楼梯',scene:'stair',
    text:'沈棠把一卷反光胶带交给你。巡检表上同一扇防火门在两个时间打过勾。她把笔夹回袖口：「先看现场。我填的那格是二十三点整。」',
    choices:[
      say('陪她复查消防门，记下哪一格还没核实',{bond:{shen:10},study:4,growth:{resilience:2}},'「明天再找另一班确认。别替没到场的人打勾。」'),
      say('把自己的走楼记录交给她比对',{bond:{shen:7},study:5,route:{clinic:1}},'她对着两张表抄下了相同的时间。'),
      say('看时间快到了，替下一班签个字',{bond:{shen:-8}},'「签下去就等于你亲眼看到了。」她把表收回夹板。'),
    ]},
  {id:'hunt-ward-proof',location:'stair',unlock:6,person:'shen',needs:'ward-lead',until:'ward-proof',entry:'拿夜班表去找沈棠',kind:'恐怖调查',title:'楼梯拐了四次',scene:'stair',tone:'horror',
    text:'沈棠把钥匙压进你手心。「从这儿到一楼只有三个转角。下去数。如果数到第四个，先停。」你数到四时，上面传来钥匙落地的声响。钥匙还硌在你掌心里。下面有人开始数：一、二、三。',
    choices:[
      say('关掉手电，贴着墙退回去，记下多出来的门',{bond:{shen:8},mind:-9,milestone:'ward-proof'},'回到上面，沈棠在你掌心找到了第二把钥匙。齿纹和第一把一样，只是还暖着。'),
      say('让沈棠从上面数，自己只记录已经走过的距离',{bond:{shen:12},mind:-5,milestone:'ward-proof'},'她数到三就停了。你把录音带到亮处，里面有第四声，是你自己的声音。'),
      say('回到有人的楼层，改天再核对',{mind:5},'你上楼时听见下面有人也在上楼。你停下来，它还走了一步。'),
    ]},
  {id:'hunt-ward-door',location:'hospital',unlock:6,needs:'ward-proof',untilClue:'ward',entry:'夜里再查一次负一层',kind:'恐怖调查',title:'呼叫器背面贴着你的名字',scene:'basement',tone:'horror',
    text:'B1 走廊每扇门都留了一条缝。呼叫器依次亮起，一路从最远处亮到你身旁。离你最近的一张床空着，被子里却正有一只手在按铃。屏幕上显示的来电人是你。接起之前，里面先传来你刚才咽口水的声音。',
    choices:[
      say('戴着手套拉开值班抽屉，抄走写给自己的那页',{mind:-14,clue:'ward'},'纸上有一行字：听到自己说「进来」时，不要回头。走廊尽头有人替你说了。'),
      say('把门轻轻带上，带着记录返回人多的值班室',{mind:6},'门在你身后闭合。楼层指示灯灭掉之前，亮起了一个 B2。'),
    ]},
  {id:'hunt-room-proof',location:'archive',unlock:2,person:'xu',needs:'room-lead',until:'room-proof',entry:'查 303 的旧平面图',kind:'恐怖调查',title:'被裁掉的第五格',scene:'archive',tone:'horror',
    text:'知遥把旧图纸举到灯下。平面图上只有四张床，背面的描摹纸却有第五张。那一格画在走廊里。你们翻到入住名单，最后一个名字被涂黑了，墨迹下一笔一划透出来，正是你的名字。',
    choices:[
      say('把两张图叠起来，抄下第五格的位置',{bond:{xu:6},mind:-8,milestone:'room-proof'},'知遥去找复印机。那台机器还没预热，出纸口已经吐出了你毕业那天的寝室照片。'),
      say('收起床牌，等白天再查',{mind:5},'熄灯前你摸了一下书包。床牌已经在里面，照片朝外。'),
    ]},
  {id:'hunt-room-lights',location:'dorm',unlock:2,person:'lin',needs:'room-proof',untilClue:'roommate',entry:'在走廊守到 303 熄灯',kind:'恐怖调查',title:'等第五个人说晚安',scene:'emptyDorm',tone:'horror',
    text:'室友都在楼下。你和小满在门外等，屋里却传来四次翻身声，接着是第五次。手机亮了，有一条你发给自己的消息：「能替我关灯吗？」你没碰手机。门底有一块亮起来，又被里面的人一寸寸挡住。',
    choices:[
      say('让小满去叫人，自己把床牌塞进门缝',{bond:{lin:4},mind:-13,clue:'roommate'},'里面有人接住床牌。你的声音说了句谢谢。随即从自己身后又传来同一句话。'),
      say('拉小满下楼，把门交给宿管',{bond:{lin:6},mind:5},'走到一楼，你收到小满的消息：「我还在三楼。你刚才牵的是谁？」'),
    ]},

  {id:'work-tutor',location:'library',unlock:1,person:'lin',until:'tutor-start',entry:'和小满组一个互助自习小组',kind:'学业支线',title:'谁来讲第一道题',scene:'library',
    text:'复习群里有人愿意发答案，却没有人报名讲题。小满把黑板擦递给你：「要不先从各自最不会的一题开始？」',
    choices:[
      say('先讲自己做错的题，邀请大家带着疑问来',{milestone:'tutor-start',study:5,bond:{lin:6}},'小满把原来的报名表改成了「我想问的问题」。'),
      say('先把能验证答案的资料整理出来',{study:7,growth:{wisdom:1}},'「我先存下来，等有人来讲的时候再发。」'),
    ]},
  {id:'work-tutor-finish',location:'library',unlock:3,person:'lin',needs:'tutor-start',until:'tutor-finish',entry:'帮互助小组把讲义交给下届',kind:'学业支线',title:'答案旁边留一列',scene:'classroom',
    text:'小组讲义已经写了半本。下一届的同学看完问，能不能把大家第一次想错的过程也留下。',
    choices:[
      say('找原作者补充错法，再标明每页怎么核对',{milestone:'tutor-finish',study:9,growth:{wisdom:2},route:{honors:2}},'有人把自己先前藏起来的草稿翻了出来。'),
      say('做成可增补的公开讲义，约新人主持一次',{milestone:'tutor-finish',social:7,bond:{lin:7}},'小满把主持人那栏留白，等下一届自己填。'),
    ]},
  {id:'work-sound',location:'archive',unlock:2,person:'xu',until:'sound-start',entry:'和知遥去做一张校园声音地图',kind:'创作支线',title:'录音机打开的三分钟',scene:'studio',
    text:'知遥只有三分钟磁带，想留下明年会消失的声音。操场广播、宿舍楼梯和食堂收档都有人提名。',
    choices:[
      say('先问提名的人想留下什么，再决定怎么录',{milestone:'sound-start',bond:{xu:7},growth:{creativity:2}},'她递给你一支笔：「先把他们记得的写下来。」'),
      say('去听一次收档，把位置和时间记清楚',{bond:{xu:5},mind:6},'最后一扇窗口关上时，你听见有人道了晚安。'),
    ]},
  {id:'work-sound-finish',location:'garden',unlock:4,person:'xu',needs:'sound-start',until:'sound-finish',entry:'在银杏路试播声音地图',kind:'创作支线',title:'听不见铃声的路口',scene:'garden',
    text:'第一位听众说她从来没听见过旧楼的下课铃。知遥拿着试播稿问，你想把这个声音写给谁看。',
    choices:[
      say('和听众一起补地点说明，让她决定哪句好读',{milestone:'sound-finish',bond:{xu:8},growth:{character:2}},'她改掉了说明里的「大家都知道」。'),
      say('保留原始录音，再加一条可以沿路自己找的提示',{milestone:'sound-finish',bond:{xu:7},growth:{creativity:2}},'试播第二次，有人沿着路标找到了原来敲钟的位置。'),
    ]},
  {id:'work-clinic',location:'hospital',unlock:6,voice:'许老师 · 临床带教',until:'clinic-start',entry:'跟许老师做一次家属说明试读',kind:'临床支线',title:'说完以后再问一句',scene:'hospital',
    text:'许老师拿出两份候诊说明，请你先读给同学听。读完以后，对方只复述出一句话，偏偏漏掉了最重要的时间。',
    choices:[
      say('改成先说时间和地点，再请对方用自己的话复述',{milestone:'clinic-start',study:6,route:{clinic:2}},'「把这次没听懂的地方记下来，之后拿去再试。」'),
      say('标出含糊用词，请老师说明哪些信息必须保留',{study:7,growth:{wisdom:1}},'许老师在纸边写了三条核对项。'),
    ]},
  {id:'work-clinic-finish',location:'community',unlock:7,person:'tang',needs:'clinic-start',until:'clinic-finish',entry:'请社区来访者试读新指引',kind:'临床支线',title:'路过的人能不能看懂',scene:'community',
    text:'试读时有位访客看懂了时间，却把楼号读成了窗口号。唐禾问，你愿不愿意再把医院和社区两头的说法对一遍。',
    choices:[
      say('记录误读，重新核对标识再请对方试读',{milestone:'clinic-finish',study:6,route:{clinic:2},bond:{tang:6}},'「这回两处的说法终于是同一件事了。」'),
      say('让来访者选一版易读的，并注明仍需带教核对',{milestone:'clinic-finish',social:7,route:{clinic:2}},'最后一版加了一行很朴素的话：不确定请到这里问。'),
    ]},
  {id:'work-paper',location:'lab',unlock:3,person:'chen',until:'paper-start',entry:'问一舟要不要公开实验的失败记录',kind:'科研支线',title:'摘要之外的表格',scene:'lab',
    text:'别人看过摘要后想做同样的实验。一舟说，实验失败的那几次都没写进去。你们要决定哪些记录先整理、哪些还需要复核。',
    choices:[
      say('先列失败记录与原始编号，再分工复核',{milestone:'paper-start',bond:{chen:7},route:{lab:2},study:5},'他从抽屉里拿出最旧的一本实验日志。'),
      say('重做一次步骤说明，补上原来没写的条件',{study:7,growth:{wisdom:2}},'新说明多了一个条件，原来正是那几次忘记记的。'),
    ]},
  {id:'work-paper-finish',location:'library',unlock:5,person:'chen',needs:'paper-start',until:'paper-finish',entry:'和一舟给下一届写复验说明',kind:'科研支线',title:'应该从哪一步重复',scene:'library',
    text:'一位新同学按你们的日志做出了不一样的曲线。她问你要先改数据，还是先改原先那句「都应该一样」。',
    choices:[
      say('保留三份结果，把它们的条件放在一起比较',{milestone:'paper-finish',bond:{chen:9},route:{lab:3},study:6},'你们把那句「都应该一样」换成了一个可验证的问题。'),
      say('把不确定的因素公开写出，邀请她一起复验',{milestone:'paper-finish',bond:{chen:8},route:{lab:2},growth:{creativity:2}},'她没有改曲线，给它补了原始记录链接。'),
    ]},
  {id:'work-rain',location:'track',unlock:2,person:'su',until:'rain-start',entry:'和晚晴设计下雨天的替代路线',kind:'协作支线',title:'路线不必经过水坑',scene:'track',
    text:'下雨之后，操场东门变成积水区。晚晴说，她想给只想散步的人留出一段不用跟着人群冲过去的路。',
    choices:[
      say('沿着外侧走一遍，记录看不清的转角',{milestone:'rain-start',bond:{su:6},body:5,route:{friends:1}},'她在转角处拍了张照片，准备第二天再去看看。'),
      say('先把被水淹的入口标在群图上',{social:5,bond:{su:4}},'马上有人说，他早上就是在那儿踩湿了鞋。'),
    ]},
  {id:'work-rain-finish',location:'roof',unlock:4,person:'su',needs:'rain-start',until:'rain-finish',entry:'和晚晴核对雨天路线的反馈',kind:'协作支线',title:'让走得慢的人也能用',scene:'roof',
    text:'群里收到两条完全相反的反馈。跑步快的人嫌路绕，走得慢的人说第一次看清了方向。晚晴问你怎么改。',
    choices:[
      say('分别标出快跑和散步的入口，先照顾有积水的路',{milestone:'rain-finish',bond:{su:7},trust:4,body:4},'她把两条路线画成不同颜色，谁都可以自己选。'),
      say('再约走得慢的人来试走，把反馈一起留在地图上',{milestone:'rain-finish',bond:{su:6},social:7},'她在地图角上写：谢谢第一次走这条路的人。'),
    ]},
  {id:'work-letters',location:'dorm',unlock:4,person:'lin',until:'letters-start',entry:'问小满要不要写给未来的信',kind:'友情支线',title:'一年后才拆开的纸袋',scene:'dorm',
    text:'小满在抽屉里找到四个信封，说以前就想给毕业前的自己写一封信。她问你，要不要给每个人都留个能反悔的机会。',
    choices:[
      say('一起写，约好只能本人决定何时拆信',{milestone:'letters-start',bond:{lin:8},mind:5},'她找了一个透明的收纳盒，把四个信封排好。'),
      say('先陪她写自己的，其他人想写再加入',{bond:{lin:7},route:{friends:1}},'她写完把第一张纸递给你，让你别念出来。'),
    ]},
  {id:'work-letters-finish',location:'garden',unlock:7,person:'lin',needs:'letters-start',until:'letters-finish',entry:'和小满带信封去银杏树下',kind:'友情支线',title:'写信的人已经变了',scene:'garden',
    text:'小满拆开自己的信，看到那句「我希望以后一点也不要变」。她读了第二遍，问你有没有一句当年说过、现在想改的话。',
    choices:[
      say('告诉她想改哪句，再约一个毕业后见面的日子',{milestone:'letters-finish',bond:{lin:9},route:{friends:2},mind:5},'她把新日期记在旧信封上，没有擦掉原来的字。'),
      say('只讲自己愿意说的那部分，陪她把信收好',{milestone:'letters-finish',bond:{lin:8},route:{friends:2}},'回寝前，她把信封递还给你，说这次换你收着。'),
    ]},

  {id:'talk-he',location:'canteen',unlock:0,person:'he',entry:'和何阿姨聊聊窗口后面的事',kind:'校园人物',title:'最后一份饭有人留着',scene:'canteen',
    text:'何阿姨把一份饭留在保温盒里。「以前有个学生总赶末班，后来我才知道她每周这个点才下课。你今天也赶吗？」',
    choices:[say('说清下课时间，帮忙贴张取餐提示',{bond:{he:7},mind:5,social:4},'「可以。下次来不及，提前说一声就行。」'),
      say('问阿姨收档后有没有时间先吃口饭',{bond:{he:8},mind:6},'「有。你问了我才想起来，今天还没坐过。」')]},
  {id:'talk-zhou',location:'gate',unlock:0,person:'zhou',entry:'和周师傅核对末班车时间',kind:'校园人物',title:'站牌被换过一次',scene:'gate',
    text:'周师傅撕下站牌上卷角的通知。「上回换站，大家都在原来的地方等。你把这张新的发给要坐车的人吧。」',
    choices:[say('核对方向和时间，再给晚下课的同学发消息',{bond:{zhou:7},social:6,study:3},'「多写一句从校门往左，晚上灯暗容易走错。」'),
      say('陪他把通知贴低一点，让排队的人也看得见',{bond:{zhou:8},mind:6},'「正好，往左再挪一点。」')]},

]

export const conversationById = new Map(conversations.map(item=>[item.id,item]))

export const partnerPlans: Story = {
  id:'partner-plan', kind:'学期剧情 · 关系主线', title:'两张车票摆在一起', person:'su', scene:'station',
  text:'临近毕业，你们已经知道可能去不同的地方。晚晴把两张车票并排放好。「我想听你真正能做到的约定。未来的安排，我们一起定。」',
  choices:[
    say('一起找能落脚的城市，也给彼此保留职业选择',{bond:{su:8},trust:9,plan:'together',route:{love:2}},'「好。先各选两处想去的地方，下次见面交换。」',1.2),
    say('先各赴各的机会，约好联系频率和下次见面',{bond:{su:7},trust:8,plan:'distance',route:{love:2}},'她在车票背面画了个圈。「这个周日，两张表再一起对一次。」',1.15),
    say('把想分开的理由讲清楚，好好道别',{bond:{su:-3},relationship:'apart',plan:'open',trust:-5},'她安静了一会儿，说：「那送我走到检票口吧。」'),
    say('敷衍说毕业自然会有办法，把话题岔开',{bond:{su:-9},trust:-13,plan:'open'},'她收起了自己的车票。「有空的时候，希望你愿意把这件事说完。」',1.2),
  ],
}
