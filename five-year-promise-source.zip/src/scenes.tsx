import { useId } from 'react'
import type { Gender } from './relationships'
import type { StoryScene } from './content'

export type Scene = StoryScene
const sceneNames: Record<Scene,string> = {
  library:'图书馆的晚自习', dorm:'303 宿舍的窗灯', track:'雨后的校园跑道',
  lab:'组胚实验室', canteen:'一号食堂晚班窗口', hospital:'附院的夜班走廊', career:'生涯工作室',
  gate:'校门外的末班车',workshop:'工坊窗下的拼贴桌',
  archive:'旧档案室的阅览灯',community:'社区站的等候区',stair:'设备楼梯的防火门',
  studio:'校园电台的录音间',basement:'附院 B1 · 呼叫灯',emptyDorm:'303 · 熄灯以后',
  roof:'教学楼天台的夜风', garden:'雨后的银杏小径', cafe:'靠窗的两杯热茶', station:'毕业季的站台', classroom:'旧教室的最后一次点名',
}
const palettes: Record<Scene,[string,string,string]> = {
  library:['#3e314f','#262238','#c19181'], dorm:['#4e344d','#2e2743','#d99d92'],
  track:['#645075','#2a3850','#f3b09a'], lab:['#36425a','#232c43','#a6bfd0'],
  canteen:['#66434f','#382a40','#f5b780'], hospital:['#394557','#253143','#9cc9c6'],
  career:['#493855','#2e283e','#dac197'],
  gate:['#465668','#333344','#c7b698'],workshop:['#695263','#43374b','#e5be91'],
  archive:['#594959','#2d263b','#bd9a7d'],community:['#4a6468','#374652','#ceba98'],stair:['#323b48','#191b2a','#799493'],
  studio:['#57435e','#2f293f','#bd92ad'],basement:['#282b37','#141622','#a76472'],emptyDorm:['#242435','#15131f','#b67c89'],
  roof:['#303258','#252643','#b8a3d9'], garden:['#685578','#324952','#ebc18b'],
  cafe:['#62465b','#3c2c46','#f0bd92'], station:['#4e516e','#303950','#e8c28d'], classroom:['#58526b','#37344d','#d9aa94'],
}

function Window({x,y,w=64,h=39}: {x:number;y:number;w?:number;h?:number}) {
  return <g transform={`translate(${x} ${y})`}>
    <rect x="-3" y="-3" width={w+6} height={h+6} fill="#29243d"/>
    <rect width={w} height={h} fill="#5d5279"/>
    <path fill="#f1b38e" d={`M0 ${h-9}H${w}v9H0z`}/>
    <path fill="#ab7891" d={`M0 ${h-17}h${w}v8H0z`}/>
    <path fill="#2e2a49" d={`M0 ${h}v-8h8v-7h13v8h8v-5h11v-6h12v9h${w-52}v9z`}/>
    <path fill="#f4c8a8" d="M9 8h2v2H9zm17 4h2v2h-2zm21-5h3v3h-3z"/>
    <path stroke="#3c3652" strokeWidth="2" d={`M${w/2} 0v${h}M0 ${h/2}h${w}`}/>
    <rect x="-6" y={h+1} width={w+12} height="4" fill="#93819b"/>
  </g>
}

function Bookshelf({x}: {x:number}) {
  const tones=['#a56778','#a089b5','#e4ac83','#68898b','#b8a27a']
  return <g transform={`translate(${x} 34)`}>
    <path fill="#241e32" d="M0 0h58v72H0z"/>
    {[0,1,2].map(row=><g key={row} transform={`translate(0 ${row*23})`}>
      {Array.from({length:9},(_,i)=><rect key={i} x={4+i*5} y={4+(i*7)%7+(i*3+row)%5} width="4" height={16-(i*3+row)%5} fill={tones[(i+row*2)%tones.length]}/>)}
      <path fill="#79536b" d="M0 20h58v4H0z"/>
    </g>)}
    <path fill="#90637b" d="M0 0h3v72H0zm55 0h3v72h-3z"/>
  </g>
}

export function SceneArt({scene,compact=false}: {scene:Scene;compact?:boolean}) {
  const id = useId()
  const [wall,floor,light] = palettes[scene]
  return <div className={`scene-frame ${compact?'scene-compact':''}`}>
    <svg viewBox="0 0 320 120" preserveAspectRatio="xMidYMid slice" role="img" aria-label={sceneNames[scene]} shapeRendering="crispEdges">
      <defs><linearGradient id={id} x2="0" y2="1"><stop stopColor={wall}/><stop offset="1" stopColor={floor}/></linearGradient></defs>
      <rect width="320" height="120" fill={`url(#${id})`}/>
      <path fill={floor} d="M0 86h320v34H0z"/>
      <path stroke={light} opacity=".3" d="M0 86h320m-320 13h320m-320 14h320"/>
      {scene==='library' && <>
        <Bookshelf x={21}/><Bookshelf x={86}/><Window x={186} y={26} w={99} h={49}/>
        <path fill="#8b655f" d="M149 90h147v7H149zm8 7h6v22h-6zm128 0h6v22h-6z"/>
        <path fill="#dc9a80" d="M176 84h45v6h-45zM233 81h37v5h-37z"/>
        <path fill="#f0cd9a" d="M172 65h22v3h5v7h-32v-7h5zm11 10h3v14h-3z"/>
        <path fill="#ece0bb" d="M210 85h9l6 3 6-3h10v4l-16 1-15-1z"/>
      </>}
      {scene==='dorm' && <>
        <Window x={110} y={21} w={96} h={52}/>
        {[22,228].map((x,i)=><g transform={`translate(${x} 30)`} key={x}>
          <path fill="#68465d" d="M0 0h5v72H0zm65 0h5v72h-5zM0 25h70v5H0zm0 35h70v5H0z"/>
          <path fill={i?'#ad819e':'#79919d'} d="M5 16h60v9H5zm0 34h60v10H5z"/>
          <path fill="#e3c2b8" d="M8 12h18v7H8zm39 35h16v6H47z"/>
          <path stroke="#c292a7" d="M9 30v30m11-30v30M9 39h11M9 50h11"/>
        </g>)}
        <path fill="#9b6d77" d="M107 89h107v5H107zm8 5h5v19h-5zm87 0h5v19h-5z"/>
        <path fill="#f9c18d" d="M156 70h18v6h4v5h-26v-5h4zm7 11h4v8h-4z"/>
      </>}
      {scene==='track' && <>
        <path fill="#db9b9f" d="M0 47h320v16H0zm0 5h320v2H0z"/>
        <path fill="#f9c18b" d="M214 16h29v4h6v6h4v17h-4v5h-6v4h-29v-4h-6v-5h-4V26h4v-6h6z"/>
        <path fill="#544766" d="M0 52h45v-7h39v4h32v-6h47v8h37v5h34v-6h32v-5h34v4h20v20H0z"/>
        <path fill="#b36c84" d="M0 68h320v52H0z"/>
        <path fill="#596c73" d="M55 69h199l31 9v8l-32 8H55L31 84v-8z"/>
        <path fill="none" stroke="#ecc3bc" d="M0 109h320m-320 6h320M53 65h204l37 12v11l-37 10H53L23 87V75zM53 62h204l44 13v16l-43 12H52L16 90V73z"/>
        <path fill="#85a7b7" opacity=".75" d="M39 111h33v3H39zm129-7h49v3h-49zm91 10h41v3h-41z"/>
      </>}
      {scene==='lab' && <>
        <Window x={19} y={22} w={95} h={44}/><Window x={207} y={22} w={95} h={44}/>
        <path fill="#7e93a2" d="M0 84h320v8H0z"/><path fill="#53667c" d="M0 92h320v20H0z"/>
        <path fill="#aeb8d4" d="M142 34h16v9h-6v18h20v9h-14v8h19v6h-51v-6h12v-9h-9v-7h13z"/>
        <path fill="#333950" d="M141 33h18v5h-18zm11 36h10v6h-10zm-16 11h36v3h-36z"/>
        {[46,69,94,229,254,277].map((x,i)=><g key={x} transform={`translate(${x} ${i%2?61:66})`}><path fill="#8cb8c7" d="M0 0h9v5H7v6h4v12H-2V11h4V5H0z"/><path fill={i%2?'#bb92ac':'#c6ad8d'} d="M-1 14h11v8H-1z"/></g>)}
      </>}
      {scene==='canteen' && <>
        {[21,121,221].map((x,i)=><g key={x} transform={`translate(${x} 28)`}>
          <path fill="#332b42" d="M0 0h76v60H0z"/><path fill="#a86e66" d="M0 0h76v8H0z"/>
          <path fill="#e6b489" d="M6 13h64v26H6z"/><path fill="#754b59" d="M34 13h5v26h-5z"/>
          <path fill="#d89a77" d="M10 21h11v3H10zm33 7h21v3H43z"/>
          <path fill={i===1?'#f2bf80':'#af837d'} d="M2 40h72v8H2z"/>
        </g>)}
        <path fill="#c68176" d="M0 85h320v8H0z"/><path fill="#5f4555" d="M12 93h295v27H12z"/>
        <path fill="#f6c085" d="M52 81h43v4H52zm80 0h61v4h-61zm89 0h41v4h-41z"/>
      </>}
      {scene==='hospital' && <>
        <path fill="#6d868d" d="M0 18h78l42 22v43L0 116zm320 0h-78l-42 22v43l120 33z"/>
        <path fill="#3c5565" d="M0 85l120-20v11L0 100zm320 0L200 65v11l120 24z"/>
        <path fill="#2b394e" d="M134 31h54v59h-54z"/><path fill="#839eac" d="M140 37h43v51h-43z"/>
        <path stroke="#4b6274" d="M161 37v52"/><path fill="#f49799" d="M151 25h21v4h-21z"/>
        <path fill="#abd9cb" d="M123 17h77v4h-77zm17 9h40v3h-40z" opacity=".7"/>
        <path fill="#394659" d="M23 38h37v49H23zm233 0h39v49h-39z"/>
        <path fill="#bad0c5" d="M29 46h14v4H29zm233 0h14v4h-14z"/>
      </>}
      {scene==='career' && <>
        <Window x={25} y={25} w={102} h={49}/>
        <path fill="#9b7383" d="M151 23h145v54H151z"/><path fill="#bd938b" d="M155 27h137v46H155z"/>
        {[0,1,2,3,4].map((i)=><path key={i} transform={`translate(${168+i*24} ${33+i%2*10})`} fill={['#eed199','#b9b3d2','#c3dbba'][i%3]} d="M0 0h17v24H0z"/>)}
        <path fill="#a97c83" d="M35 88h246v7H35zm9 7h5v25h-5zm225 0h5v25h-5z"/>
        <path fill="#453954" d="M71 67h39v20H71z"/><path fill="#89a8b2" d="M76 72h29v10H76z"/>
        <path fill="#e3b88d" d="M168 81h49v7h-49zm55-4h19v11h-19z"/>
      </>}
      {scene==='roof' && <>
        <path fill="#e2c4dd" d="M220 12h13v3h5v12h-4v4h-14v-3h-4V16h4z"/>
        <path fill="#74658e" d="M228 12h7v9h3v4h-7v-4h-3z"/>
        <path fill="#c7b4d8" d="M32 19h2v2h-2zm55-9h2v2h-2zm50 15h3v2h-3zm146-3h2v2h-2z"/>
        {Array.from({length:18},(_,i)=><g key={i} transform={`translate(${i*19} ${39+i*7%17})`}><path fill="#3c3758" d="M0 0h15v44H0z"/><path fill={i%3===0?'#e5af92':'#8f779d'} d="M3 6h3v3H3zm7 7h3v3h-3zM3 19h3v3H3z"/></g>)}
        <path fill="#67587a" d="M0 76h320v5H0zm0 20h320v5H0z"/>
        <path stroke="#756686" strokeWidth="3" d="M21 80v22m45-22v22m45-22v22m45-22v22m45-22v22m45-22v22m45-22v22"/>
        <path fill="#ba8eaa" d="M145 88h21v5h-21z"/><path fill="#d8a78f" d="M171 85h7v8h-7z"/>
      </>}
      {scene==='garden' && <>
        <path fill="#5f6267" d="M0 66h320v54H0z"/><path fill="#9d8290" d="M143 63h34l91 57H55z"/>
        <path fill="#aba6b9" opacity=".55" d="M72 105h29v3H72zm131 3h35v3h-35zm-66-20h34v2h-34z"/>
        {[[44,58,1],[272,57,.95],[104,48,.63],[227,47,.58]].map(([x,y,scale])=><g key={x} transform={`translate(${x} ${y}) scale(${scale})`}>
          <path fill="#654a59" d="M-3-30h6v67h-6z"/>
          <path fill="#bc857b" d="M-20-42h38v5h12v8h5v11h-6v7h-12v6h-37v-5h-10v-7h-5v-14h7v-7h8z"/>
          <path fill="#e7b57c" d="M-17-42h31v5h10v7h5v10h-8v6H4v-7h-13v7h-15v-8h-5v-8h5v-7h7z"/>
          <path fill="#f8cf91" d="M-15-39h18v5h-18zm23 5h13v5H8z"/>
        </g>)}
        <path fill="#e8b67f" d="M79 87h4v3h-4zm39 11h4v2h-4zm76-13h4v3h-4zm58 15h4v3h-4z"/>
        <path fill="#e4a5b5" d="M137 69h16v4h6v5h-28v-5h6z"/><path fill="#a5bbd3" d="M165 66h16v4h6v5h-28v-5h6z"/>
        <path stroke="#59495f" d="M145 78v11m28-14v12"/>
      </>}
      {scene==='cafe' && <>
        <Window x={28} y={18} w={109} h={57}/><Window x={184} y={18} w={107} h={57}/>
        <path fill="#bd847d" d="M102 92h116v7H102zm7 7h6v21h-6zm96 0h6v21h-6z"/>
        <path fill="#805b6b" d="M60 78h7v42h-7zm190 0h7v42h-7zM59 103h27v6H59zm172 0h26v6h-26z"/>
        <path fill="#ede1bf" d="M120 83h18v6h-3v3h-12v-3h-3zm60 0h18v6h-3v3h-12v-3h-3z"/>
        <path fill="none" stroke="#f5ccb8" opacity=".8" d="M126 80v-4h2v-4m58 8v-4h2v-5"/>
        <path fill="#c1a6c9" d="M145 87h29v5h-29z"/>
      </>}
      {scene==='station' && <>
        <path fill="#a295a2" d="M0 40h320v7H0z"/><path fill="#716575" d="M39 47h5v58h-5zm231 0h5v58h-5z"/>
        <path fill="#657283" d="M0 58h320v27H0z"/><path fill="#b6a6a2" d="M0 84h320v3H0z"/>
        {Array.from({length:9},(_,i)=><rect key={i} x={i*36+4} y="63" width="24" height="10" fill={i%2?'#aeacbb':'#e8ba9b'}/>)}
        <path fill="#2b3045" d="M0 91h320v29H0z"/><path stroke="#88849a" d="M0 98h320m-320 12h320"/>
        <path fill="#555b70" d="M0 114h320v6H0z"/>
        <path fill="#d6b088" d="M121 23h76v18h-76z"/><path fill="#625674" d="M127 27h64v10h-64z"/><path fill="#eed3a4" d="M136 30h25v3h-25zm36 0h12v3h-12z"/>
      </>}
      {scene==='classroom' && <>
        <path fill="#556d71" d="M59 16h201v48H59z"/><path fill="#ad8991" d="M57 63h205v4H57z"/>
        <path stroke="#c6bbb5" opacity=".7" d="M78 33h40m-40 8h54m11-8h54m-40 8h31"/>
        {[0,1,2].map(row=><g key={row} transform={`translate(0 ${row*15})`}><path fill={row%2?'#b58f8c':'#967588'} d="M26 75h64v6H26zm94 0h80v6h-80zm115 0h59v6h-59z"/><path fill="#6b566a" d="M31 81h4v7h-4zm94 0h4v7h-4zm115 0h4v7h-4z"/></g>)}
      </>}
      {scene==='archive' && <>
        <Bookshelf x={18}/><Bookshelf x={244}/>
        <path fill="#7d5863" d="M88 82h145v8H88zm8 8h6v27h-6zm124 0h6v27h-6z"/>
        <path fill="#e3bf8a" d="M113 55h24v5h7v7h-37v-7h6zm11 12h4v15h-4z"/>
        <path fill="#e2ceb0" d="M144 73h44v4h15v5h-60z"/><path stroke="#a99183" d="M149 76h32m-19 3h25"/>
        <path fill="#b2a0a4" d="M188 37h30v25h-30z"/><path fill="#5a4a65" d="M192 41h22v16h-22z"/>
      </>}
      {scene==='studio' && <>
        <path fill="#79637b" d="M21 17h132v54H21z"/><path fill="#35324e" d="M25 22h124v45H25z"/>
        <path fill="#8e7d9a" d="M86 22h3v45h-3z"/><path fill="#685770" d="M31 28h44v31H31zm70 0h40v31h-40z"/>
        <path fill="#b28089" d="M187 22h104v49H187z"/><path fill="#513d54" d="M191 26h96v41h-96z"/>
        {[0,1,2,3,4,5,6].map(i=><path key={i} stroke="#8b6a81" d={`M${197+i*14} 28v36`}/>)}
        <path fill="#98748a" d="M51 87h220v7H51z"/><path fill="#544660" d="M109 76h103v10H109z"/>
        <path fill="#e397aa" d="M119 79h3v3h-3zm9 0h3v3h-3zm8 0h3v3h-3zm30 0h3v3h-3zm31 0h3v3h-3z"/>
        <path fill="#cbb5bc" d="M224 56h7v14h-7z"/><path stroke="#b499ae" d="M227 70v17m-10 0h22"/>
      </>}
      {scene==='community' && <>
        <Window x={25} y={18} w={106} h={50}/>
        <path fill="#b6a897" d="M157 25h103v48H157z"/><path fill="#6c7978" d="M163 30h91v38h-91z"/>
        <path fill="#eed4ac" d="M174 36h26v22h-26zm35 4h32v21h-32z"/><path stroke="#aa917f" d="M177 42h20m-20 5h12m24-1h24m-24 5h18"/>
        <path fill="#819590" d="M24 81h117v7H24zM29 88h5v24h-5zm104 0h5v24h-5z"/>
        <path fill="#a4858e" d="M166 84h26v6h-26zm39 0h26v6h-26zm39 0h26v6h-26zm-76 6h3v17h-3zm37 0h3v17h-3zm39 0h3v17h-3z"/>
      </>}
      {scene==='stair' && <>
        <path fill="#525764" d="M0 17h114v60L0 119zm320 0H207v60l113 42z"/>
        <path fill="#313442" d="M109 16h102v53H109z"/><path fill="#4b4b5a" d="M129 25h58v43h-58z"/>
        <path fill="#737e7e" d="M148 29h24v5h-24z"/><path fill="#a0b6a6" d="M155 29h4v5h-4z"/>
        <path fill="#424452" d="M123 62h70l54 58H71z"/>
        <path stroke="#777381" d="M119 67h80m-87 8h96m-105 10h116m-129 11h143m-155 12h168"/>
        <path stroke="#848293" strokeWidth="3" d="M42 81l82-34m68 0 84 34M58 78v23m185-24v23"/>
      </>}
      {scene==='basement' && <>
        <path fill="#3c3946" d="M0 20h104l37 22v36L0 118zm320 0H215l-37 22v36l142 40z"/>
        <path fill="#262530" d="M17 38h41v55H17zm49 0h39v45H66zm151 0h40v46h-40zm47 0h38v55h-38z"/>
        <path fill="#080910" d="M143 42h34v40h-34z"/><path fill="#39333f" d="M166 47h9v33h-9z"/>
        <path fill="#f18a97" d="M40 39h8v3h-8zm45 3h7v3h-7zm145 0h6v3h-6zm49-3h8v3h-8zm-124-4h12v4h-12z"/>
        <path fill="#774858" opacity=".57" d="M32 101h24v2H32zm129-18h17v2h-17zm93 22h31v3h-31z"/>
        <path fill="#181723" d="M156 56h9v4h4v14h-4v7h-10v-7h-4V61h5z"/>
      </>}
      {scene==='emptyDorm' && <>
        <path fill="#463a4c" d="M0 0h86v120H0zm320 0h-72v120h72z"/>
        <path fill="#181522" d="M91 16h139v99H91z"/><path fill="#423446" d="M98 22h123v93H98z"/>
        <path fill="#826375" d="M142 28h30v10h-30z"/><path fill="#b38994" d="M148 30h3v6h-3zm7 0h3v6h-3zm7 0h3v6h-3z"/>
        <path fill="#191722" d="M110 62h24v13h-24z"/><path fill="#8a6879" d="M198 69h7v3h-7z"/>
        <path fill="#b66d79" d="M107 113h99v3h-99z"/><path fill="#1d1827" d="M154 109h18v9h-18z"/>
        <path fill="#794e62" opacity=".5" d="M119 117h24v2h-24zm56 0h29v2h-29z"/>
      </>}
      {scene==='gate' && <>
        <path fill="#4d5267" d="M0 75h320v45H0z"/><path fill="#a88793" d="M0 87h320v4H0z"/>
        <path fill="#827e98" d="M37 23h121v6H37zm5 6h5v63h-5zm104 0h5v63h-5z"/>
        <path fill="#d4c6a8" d="M54 38h83v33H54z"/><path fill="#6c7285" d="M60 44h70v22H60z"/>
        <path stroke="#cbd3c2" d="M69 51h49m-49 6h32"/>
        <path fill="#97a79d" d="M197 49h99v35h-99z"/><path fill="#65687b" d="M204 55h85v16h-85z"/>
        <path fill="#dcd09d" d="M209 58h17v10h-17zm24 0h17v10h-17zm24 0h18v10h-18z"/>
        <path fill="#343547" d="M209 83h14v8h-14zm61 0h14v8h-14z"/>
        <path fill="#b0a3a5" d="M17 107h39v2H17zm64 0h39v2H81zm64 0h39v2h-39zm64 0h39v2h-39z"/>
      </>}
      {scene==='workshop' && <>
        <Window x={27} y={17} w={93} h={51}/>
        <path fill="#aa8894" d="M155 14h138v61H155z"/><path fill="#756078" d="M160 19h128v50H160z"/>
        <path fill="#edd3a7" d="M173 29h27v28h-27z"/><path fill="#bf9fc4" d="M211 26h31v22h-31z"/>
        <path fill="#94b6b2" d="M248 38h27v22h-27z"/><path stroke="#d3b497" d="M177 37h18m-18 5h12m39-8h10"/>
        <path fill="#a98386" d="M51 86h215v8H51zm11 8h6v26h-6zm190 0h6v26h-6z"/>
        <path fill="#dec8a4" d="M93 79h54v7H93z"/><path fill="#c8abc5" d="M157 77h51v8h-51z"/>
        <path fill="#8c7288" d="M220 73h13v13h-13z"/><path stroke="#e4b6a3" d="M224 74v-8m5 8v-5"/>
      </>}
    </svg>
    <span>{sceneNames[scene]}</span>
  </div>
}

export function StudentPortrait({variant,gender}: {variant:number;gender?:Gender}) {
  const skin = ['#efbfaa','#d9a185','#b97b69','#e2ab93'][variant % 4]
  const hair = ['#352d4a','#654356','#342c40','#634841'][Math.floor(variant / 4)%4]
  const jacket = ['#7d649f','#527c91','#875977','#587e79'][Math.floor(variant/16)%4]
  return <svg className="student-portrait" viewBox="0 0 48 48" role="img" aria-label="本周目的主角像素头像" shapeRendering="crispEdges">
    <path fill="#39304f" d="M0 0h48v48H0z"/>
    <path fill="#817099" d="M3 3h8v1H3zm33 40h8v1h-8z"/>
    <path fill={hair} d={gender==='female'?'M10 13h4V9h5V7h13v3h5v23h-7V21H17v13h-7z':'M12 12h5V8h15v4h5v18H11V15h1z'}/>
    <path fill={skin} d="M14 19h6v-3h6v3h9v12h-5v5H19v-5h-5z"/>
    <path fill="#3b2d43" d="M18 22h3v3h-3zm10 0h3v3h-3z"/>
    <path fill="#9a5e64" d="M22 29h6v2h-6z"/>
    <path fill={jacket} d="M14 36h6v4h8v-4h7v4h5v8H8v-8h6z"/>
    {variant%3===0 && <path fill="none" stroke="#3c3550" d="M16 21h8v6h-8zm10 0h8v6h-8zm-2 3h2"/>}
  </svg>
}
