import { changeRelationship, checkRelationshipRisk, currentPartners, eligiblePeople, isCandidate, newLoveLife, normalizeName, relationshipOffers, romanceEvent, romanceStory, validIdentity, validLoveLife } from './relationships.ts'
import type { Identity, LoveLife } from './relationships.ts'
import { chapters, chapterStories } from './chapters.ts'
import { conversationById, conversations, partnerPlans } from './conversations.ts'
import { badges, careerActions, careerIds, careerStories, chance, detours, detourTones, endings, exams, isSpecialEnding, locations, people, projectIds, sideStories, specialEndingIds, stats, terms, threadFlags } from './content.ts'
import type { Badge, Career, Choice, CorePerson, Effect, Ending, LocationId, Person, Project, Relationship, RelationshipPlan, Route, SpecialEnding, Stat, Story, ThreadFlag } from './content.ts'

import { growTalents, neutralTalents, rollTalents, routeWeights, talentIds, talentLabels, weightedTalent } from './talents.ts'
import type { Talents } from './talents.ts'

type Grade = '优秀' | '通过' | '待补修'
export type Exam = { score: number; grade: Grade }
export type Game = {
  term: number
  moves: number
  stats: Record<Stat, number>
  bonds: Record<CorePerson,number> & Partial<Record<Person,number>>
  routes: Record<Route, number>
  runs: number
  seed: number
  promise: boolean
  selected: LocationId
  pending: string[]
  seen: string[]
  grades: Exam[]
  log: string[]
  badges: Badge[]
  ending?: Ending
  clues?: SpecialEnding[]
  talents?: Talents
  avatar?: number
  career?: Career
  projects?: Record<Project,number>
  relationship?: Relationship
  plan?: RelationshipPlan
  trust?: number
  conversationsThisTerm?: string[]
  milestones?: ThreadFlag[]
  extraTime?: true
  chapterMode?: true
  identity?: Identity
  loveLife?: LoveLife
  reply?: {storyId:string; choice:number}
}
export type Profile = { version: 1; auto?: Game; manual?: Game; badges: Badge[]; endings: Ending[] }
export const emptyProfile = (): Profile => ({version:1, badges:[], endings:[]})
export const SAVE_KEY = 'qinghe-five-year-v1'
export const ACTIONS_PER_TERM = 3
const MAX_ACTIONS_PER_TERM = ACTIONS_PER_TERM + 1
export function actionLimit(game: Game) {
  return game.extraTime ? MAX_ACTIONS_PER_TERM : ACTIONS_PER_TERM
}

export function unlockExtraTime(game: Game): Game {
  if (game.ending || game.pending.length || game.extraTime || game.moves !== ACTIONS_PER_TERM) return game
  return {...game,extraTime:true}
}
export const TERM_COUNT = terms.length
const graduationFork = 'graduation-fork'
const horrorLeads = {ward:'ward-lead',roommate:'room-lead'} as const
function isHorrorLead(id: string): id is keyof typeof horrorLeads {
  return Object.hasOwn(horrorLeads,id)
}
const storyList = [...terms, ...chapterStories, ...chance, ...sideStories, ...careerStories, partnerPlans, ...conversations, ...specialEndingIds.map(id => detours[id].story)]
const statKeys = Object.keys(stats) as Stat[]
const personKeys = Object.keys(people) as Person[]
const corePeople: CorePerson[] = ['lin','su','chen']
const routeKeys: Route[] = ['honors','lab','love','friends','rest','clinic']
const clamp = (n: number, max: number) => Math.min(max, Math.max(0,n))

export function startGame(seed: number, chapterMode=false, identity?:Identity): Game {
  const profile = identity && {...identity,name:normalizeName(identity.name)}
  return {
    ...(profile && validIdentity(profile) ? {identity:profile,loveLife:newLoveLife(seed)} : {}),
    ...(chapterMode ? {chapterMode:true as const} : {}),
    term:0, moves:0, stats:{study:25,mind:72,body:76,social:24,cash:220},
    bonds:{lin:0,su:0,chen:0}, routes:{honors:0,lab:0,love:0,friends:0,rest:0,clinic:0},
    talents:rollTalents(seed), avatar:(seed >>> 10) % 64, runs:0, seed:seed >>> 0, promise:false, selected:'dorm',
    pending:[terms[0].id], seen:[], grades:[], badges:['arrival'],
    log:[(profile?.name || '你')+'在青禾医大签到。行李箱的轮子一路咔哒咔哒。'],
  }
}

export function talentsFor(game: Game) {
  return game.talents ?? neutralTalents
}

export function relationshipFor(game: Game): Relationship {
  if (game.identity) {
    const stage=game.loveLife?.records.su?.stage
    return stage==='dating'?'dating':stage==='estranged'?'apart':'single'
  }
  return game.relationship ?? (game.promise ? 'dating' : 'single')
}

export function trustFor(game: Game) {
  if (game.identity) return game.loveLife?.records.su?.trust ?? 0
  return game.trust ?? (game.promise ? 60 : 0)
}

export function bondFor(game: Game, person: Person) {
  return game.bonds[person] ?? 0
}

export function investigationNotes(game: Game) {
  const notes = [
    {id:'ward', title:'负一层夜班表',lead:'ward-lead',proof:'ward-proof',next:'到设备楼梯找沈棠。',last:'回青禾附院，核对多出来的门。'},
    {id:'roommate',title:'303 的第五张床牌',lead:'room-lead',proof:'room-proof',next:'到旧档案室翻 303 的原图。',last:'回 303 宿舍守到熄灯。'},
  ] as const
  return notes.flatMap(note => {
    if (game.clues?.includes(note.id)) return [{title:note.title,step:'已收录。毕业时可以决定是否赴约。'}]
    if (!game.milestones?.includes(note.lead)) return []
    return [{title:note.title,step:game.milestones.includes(note.proof)?note.last:note.next}]
  })
}

function bondGain(game: Game, person: Person, amount: number, contextWeight=1) {
  if (amount <= 0) return Math.round(amount * contextWeight)
  const {looks,character,wisdom} = talentsFor(game)
  if (person === 'su') {
    const early = game.bonds.su < 35
    const impression = early ? .65 * looks + .35 * character : .2 * looks + .8 * character
    return Math.max(1,Math.round((amount + (impression - 60) / 7) * contextWeight))
  }
  const impression = person === 'lin' ? character : .65 * wisdom + .35 * character
  return Math.max(1,Math.round((amount + (impression - 60) / 12) * contextWeight))
}

export const careerTarget = 70

export function careerFit(game: Game, project: Project) {
  return Math.min(100,Math.round(weightedTalent(talentsFor(game),routeWeights[project])
    + Math.min(18,(game.projects?.[project] ?? 0) * 6)))
}

export function currentStory(game: Game): Story | undefined {
  if (game.pending[0] === graduationFork) {
    const choices: Choice[] = (game.clues ?? []).map(id => ({
      label:detours[id].finale, note:detourTones[detours[id].tone] + '结局', effect:{}, outcome:id,
    }))
    return {
      id:graduationFork, kind:'毕业剧情', title:'毕业照之后',
      text:'最后一门考完了。小满在群里催你下楼拍照。你摸到这几年一直留着的东西，忽然想起还有一处没去。拍完这张合影，你打算去哪里？',
      choices:[...choices, {label:'收好行李，从正门离开', note:'按这五年的成长路线结算', effect:{}, outcome:getEnding(game)}],
    }
  }
  const relationshipStory = romanceStory(game.pending[0] ?? '')
  if (relationshipStory) return relationshipStory
  const story = storyList.find(item => item.id === game.pending[0])
  if (game.identity && story?.id==='term-7') {
    if (currentPartners(game).length) {
      return {...story,scene:'roof',kind:'关系与实习',
        text:'轮转表发了下来，几个原本能见面的晚上被划掉。你打开日历，想起有人还在等你确定下次见面的时间。',
        choices:[{label:'把真实的空档发过去，问对方哪天方便',effect:{trust:8,mind:3},reply:'日历上有了一个双方都确认过的晚上。'},
          {label:'答应随时有空，先把眼下的轮转做完',effect:{trust:-10,study:6},reply:'消息发出去了。那些你已经知道来不了的晚上，依旧空着。'}]}
    }
    return {...story,scene:'roof',text:'夜风里，晚晴问大家毕业后还会不会回来。她把话题交给你，等你说自己想去的地方。',
      choices:[{label:'聊聊各自的去向，约以后有空回来走走',effect:{mind:6,bond:{su:7},route:{friends:1}},reply:'「好。谁先回来，谁发消息。」'},
        {label:'先把轮转和求职的时间列清楚',effect:{study:6,route:{clinic:1}},reply:'「那就先各忙自己的，等安排明白了再约。」'}]}
  }
  if (game.identity && story?.id==='term-9') {
    const plans=currentPartners(game).length
      ? ' 手机里还有毕业后见面的安排等你确认。'
      : game.loveLife?.hadBreakup ? ' 你翻到一条没回的旧消息，想了一会儿，把手机收了起来。' : ''
    return {...story,text:story.text+plans,choices:[...story.choices.slice(0,2),{label:'去校门送同学，记下下一次聚会时间',effect:{mind:5,social:4,route:{friends:1}}}]}
  }
  if (story?.id === 'term-7' && relationshipFor(game) === 'dating') {
    return {...story,scene:'roof',
      text:'晚晴把实习排班表放到你旁边。「上周我们三次见面都被临时调班打断。我还想见你，我们能不能换个安排？」',
      choices:[
        {label:'一起看排班，给彼此留一个真的能见面的晚上',effect:{bond:{su:10},trust:8,route:{love:2}},reply:'「周四可以。我会先问你方不方便，再把它写进日历。」'},
        {label:'商量各忙一周，周末再好好聊',effect:{bond:{su:4},trust:3,body:5},reply:'「好。那我们周日再对一次时间。」'},
        {label:'答应以后都有空，先结束这个话题',effect:{bond:{su:-7},trust:-10},reply:'她把表叠起来。「我只想约定一个你真的做得到的时间。」'},
      ]}
  }
  if (story?.id === 'term-9' && relationshipFor(game) === 'dating') {
    return {...story, text:story.text+' 手机亮了。晚晴问合影之后要不要留十分钟，认真对一下毕业安排。'}
  }
  if (story?.id === 'term-9' && relationshipFor(game) === 'apart') {
    return {...story,text:story.text+' 小满问要不要陪你去车站。你给晚晴发了一句毕业快乐，之后把手机揣回口袋。'}
  }
  if (story?.id === 'career-decision' || story?.id === 'talk-career') {
    return {...story, choices:story.choices.map(choice => {
      const career = choice.effect.career
      if (career !== 'product' && career !== 'writing') return choice
      return {...choice,note:`当前适配 ${careerFit(game,career)}/100 · 达到 ${careerTarget} 可进入该方向，还能继续做项目。`}
    })}
  }
  return story
}

export function availableChapter(game: Game) {
  const chapter = chapters[game.term]?.opening
  if (!chapter || game.ending || game.pending.length || game.seen.includes(chapter.id)) return
  return chapter
}

export function openChapter(game: Game): Game {
  const chapter = availableChapter(game)
  return chapter ? {...game,pending:[chapter.id]} : game
}

const campusProjects = [
  {title:'互助自习',start:'tutor-start',finish:'tutor-finish',first:'library',next:'library',term:1,followTerm:3},
  {title:'校园声音地图',start:'sound-start',finish:'sound-finish',first:'archive',next:'garden',term:2,followTerm:4},
  {title:'家属说明试读',start:'clinic-start',finish:'clinic-finish',first:'hospital',next:'community',term:6,followTerm:7},
  {title:'开放复验记录',start:'paper-start',finish:'paper-finish',first:'lab',next:'library',term:3,followTerm:5},
  {title:'雨天替代路线',start:'rain-start',finish:'rain-finish',first:'track',next:'roof',term:2,followTerm:4},
  {title:'写给未来的信',start:'letters-start',finish:'letters-finish',first:'dorm',next:'garden',term:4,followTerm:7},
] as const
export function projectNotes(game: Game) {
  return campusProjects.filter(item=>item.term<=game.term).map(item=>{
    const complete = game.milestones?.includes(item.finish)
    const started = game.milestones?.includes(item.start)
    const location = locations.find(place=>place.id===(started ? item.next : item.first))!
    const waiting = started && !complete && game.term<item.followTerm
    return {title:item.title,complete,started,location:complete||waiting?undefined:location,
      detail:complete?'已完成':waiting?'后续随学期开放':started?'可以继续':'可开始'}
  })
}

export function availableConversations(game: Game) {
  if (game.ending || game.pending.length || game.moves >= actionLimit(game)) return []
  const normal = conversations.filter(item => (!game.identity || !/^(date-|talk-ask|talk-reconcile|phase-su-dating|phase-su-late)/.test(item.id)) && item.location === game.selected && item.unlock <= game.term
    && (!item.person || !isCandidate(item.person) || game.loveLife?.records[item.person]?.stage !== 'estranged')
    && (item.through === undefined || game.term <= item.through)
    && (!item.requires || item.requires === relationshipFor(game))
    && (!item.person || bondFor(game,item.person) >= (item.minBond ?? 0))
    && (!item.needs || game.milestones?.includes(item.needs))
    && (!item.until || !game.milestones?.includes(item.until))
    && (!item.untilClue || !game.clues?.includes(item.untilClue))
    && !game.conversationsThisTerm?.includes(item.id))
  return [...normal,...relationshipOffers(game)]
}

export function openConversation(game: Game, id: string): Game {
  return availableConversations(game).some(item => item.id === id) ? {...game,pending:[id]} : game
}

export function isOptionalConversation(id:string|undefined) {
  if (!id) return false
  const event=romanceEvent(id)
  return event ? event.moment!=='conflict' : conversationById.has(id)
}
function permittedStory(game:Game,id:string) {
  const event=romanceEvent(id)
  return event ? eligiblePeople(game).includes(event.person) : storyList.some(story=>story.id===id)
}

export function leaveConversation(game: Game): Game {
  return isOptionalConversation(game.pending[0]) ? {...game,pending:game.pending.slice(1)} : game
}

export function availableActions(game: Game): (Choice & {detour?: SpecialEnding})[] {
  const location = locations.find(item => item.id === game.selected)
  if (!location || location.unlock > game.term) return []
  const extras = specialEndingIds.filter(id => {
    const detour = detours[id]
    if (detour.location !== location.id || detour.unlock > game.term) return false
    if (!game.seen.includes(id)) return true
    return isHorrorLead(id) && !game.clues?.includes(id) && !game.milestones?.includes(horrorLeads[id])
      && !game.conversationsThisTerm?.includes(id)
  })
  const projects = projectIds.filter(id => !!game.career
    && careerActions[id].location === location.id)
  return [...location.actions, ...extras.map(id => ({...detours[id].action, detour:id})),
    ...projects.map(id => careerActions[id].action)]
}

function addLog(game: Game, text: string) {
  return {...game, log:[text, ...game.log].slice(0,16)}
}

function apply(game: Game, effect: Effect, storyId?: string): Game {
  const values = {...game.stats}
  const bonds = {...game.bonds}
  const routes = {...game.routes}
  for (const stat of statKeys) values[stat] = clamp(values[stat] + (effect[stat] ?? 0), stat === 'cash' ? 9999 : 100)
  for (const person of personKeys) {
    const amount = effect.bond?.[person]
    if (amount) bonds[person] = clamp(bondFor(game,person) + bondGain(game,person,amount,effect.contextWeight),100)
  }
  for (const route of routeKeys) routes[route] += effect.route?.[route] ?? 0
  const next = {...game, stats:values, bonds, routes, runs:game.runs + (effect.run ?? 0), promise:game.promise || !!effect.promise}
  if (effect.relationship) {
    next.relationship = effect.relationship
    next.promise = effect.relationship === 'dating'
  }
  if (effect.plan) next.plan = effect.plan
  if (game.identity && game.loveLife && effect.trust) {
    const records = {...game.loveLife.records}
    for (const id of currentPartners(game)) {
      if (storyId==='term-7' || id==='su') {
        const record = records[id]!
        records[id] = {...record,trust:clamp(record.trust+effect.trust,100)}
      }
    }
    next.loveLife = {...game.loveLife,records}
  } else if ((effect.relationship ?? relationshipFor(game)) !== 'single' && (effect.trust || effect.relationship)) {
    const trust = effect.relationship === 'dating' && relationshipFor(game) !== 'dating'
      ? Math.max(50,trustFor(game)) : trustFor(game)
    next.trust = clamp(trust + (effect.trust ?? 0),100)
  }
  if (effect.growth) next.talents = growTalents(talentsFor(game),effect.growth)
  if (effect.career) next.career = effect.career
  if (effect.project) {
    const projects = {...game.projects ?? {product:0,writing:0}}
    projects[effect.project]++
    next.projects = projects
  }
  if (effect.milestone) next.milestones = [...new Set([...(game.milestones ?? []),effect.milestone])]
  if (effect.clue) next.clues = [...new Set([...(game.clues ?? []),effect.clue])]
  return next
}

function unlock(game: Game, badge: Badge): Game {
  return game.badges.includes(badge) ? game : {...game, badges:[...game.badges, badge]}
}

function updateBadges(game: Game) {
  let next = game
  if (next.runs >= 5) next = unlock(next, 'runner')
  if (next.grades.filter(grade => grade.grade === '优秀').length >= 3) next = unlock(next, 'scholar')
  if (Object.values(next.bonds).some(bond => bond >= 60)) next = unlock(next, 'bond')
  if (next.term >= 6) next = unlock(next, 'field')
  if (next.ending && qualifiesForGraduation(next)) next = unlock(next, 'graduate')
  return next
}

function queueStories(game: Game): Game {
  const pending = [...game.pending]
  for (const person of corePeople) {
    if (game.loveLife?.records[person]?.stage==='estranged') continue
    const first = person + '-1'
    const second = person + '-2'
    if (game.bonds[person] >= 28 && !game.seen.includes(first) && !pending.includes(first)) pending.push(first)
    if ((person !== 'su' || (!game.identity && relationshipFor(game) === 'single')) && game.term >= 5 && game.bonds[person] >= 65 && game.seen.includes(first) && !game.seen.includes(second) && !pending.includes(second)) pending.push(second)
  }
  const chapter = chapters[game.term].opening
  if (game.chapterMode && !game.seen.includes(chapter.id) && !pending.includes(chapter.id)
      && !pending.includes(terms[game.term].id)) pending.push(chapter.id)
  const careerStory = game.career === 'trial' && game.term >= 8 ? 'career-decision'
    : !game.career && game.term >= 5 ? 'career-open' : undefined
  if (careerStory && !game.seen.includes(careerStory) && !pending.includes(careerStory)
      && !pending.includes(terms[game.term].id)) pending.push(careerStory)
  if (!game.identity && game.term === TERM_COUNT-1 && relationshipFor(game) === 'dating'
      && !game.seen.includes(partnerPlans.id) && !pending.includes(partnerPlans.id)
      && !pending.includes(terms[game.term].id)) pending.push(partnerPlans.id)
  return {...game, pending}
}

export function effectLabels(game: Game, effect: Effect) {
  const marks = statKeys.flatMap(key => {
    const amount = effect[key]
    return amount ? [{text:stats[key].name + (amount > 0 ? '+' : '−') + Math.abs(amount), positive:amount > 0}] : []
  })
  for (const person of personKeys) {
    const bond = bondFor(game,person)
    const amount = clamp(bond + bondGain(game,person,effect.bond?.[person] ?? 0,effect.contextWeight),100) - bond
    if (amount) marks.push({text:people[person].name + ' ♥' + (amount > 0 ? '+' : '−') + Math.abs(amount), positive:amount > 0})
  }
  if (effect.growth) {
    const current = talentsFor(game)
    const improved = growTalents(current,effect.growth)
    for (const id of talentIds) {
      if (improved[id] > current[id]) marks.push({text:talentLabels[id]+'+'+(improved[id]-current[id]),positive:true})
    }
  }
  if (effect.trust && game.identity && game.pending[0]==='term-7' && currentPartners(game).length) {
    marks.push({text:'关系信任 '+(effect.trust>0?'+':'−')+Math.abs(effect.trust),positive:effect.trust>0})
  } else if (effect.trust && (effect.relationship ?? relationshipFor(game)) !== 'single') {
    const trust = effect.relationship === 'dating' && relationshipFor(game) !== 'dating' ? Math.max(50,trustFor(game)) : trustFor(game)
    const delta = clamp(trust + effect.trust,100) - trust
    if (delta) marks.push({text:'信任'+(delta > 0 ? '+' : '−')+Math.abs(delta),positive:delta>0})
  }
  if (effect.project) marks.push({text:'作品集 +1',positive:true})
  if (effect.run) marks.push({text:'跑步 +' + effect.run, positive:true})
  if (effect.milestone) marks.push({text:'推进支线',positive:true})
  if (effect.clue) marks.push({text:'保留结局线索', positive:true})
  return marks
}

export function affordable(game: Game, choice: Choice) {
  return game.stats.cash + (choice.effect.cash ?? 0) >= 0
}

export function selectLocation(game: Game, id: LocationId): Game {
  const location = locations.find(item => item.id === id)
  return location && location.unlock <= game.term && !game.ending && !game.pending.length ? {...game, selected:id} : game
}

export function act(game: Game, index: number): Game {
  const location = locations.find(item => item.id === game.selected)
  const choice = availableActions(game)[index]
  if (!location || !choice || game.ending || game.pending.length || game.moves >= actionLimit(game) || !affordable(game, choice)) return game
  const seed = (Math.imul(game.seed, 1664525) + 1013904223) >>> 0
  let next = addLog({...apply(game, choice.effect), moves:game.moves + 1, seed}, location.name + ' · ' + choice.label + '。' + choice.note)
  if (choice.detour) next = {...next, pending:[choice.detour]}
  else if (seed % 100 < 24) {
    const candidates = chance.filter(event => !next.seen.includes(event.id))
    if (candidates.length) next = {...next, pending:[candidates[(seed >>> 8) % candidates.length].id]}
  }
  return updateBadges(queueStories(checkRelationshipRisk(next)))
}

export function choose(game: Game, index: number): Game {
  const story = currentStory(game)
  const choice = story?.choices[index]
  if (!story || !choice || !affordable(game, choice) || game.ending) return game
  if (choice.outcome) {
    const next = addLog({...game, pending:[], ending:choice.outcome}, '毕业照之后 · ' + choice.label + '。')
    return updateBadges(next)
  }
  const romance = romanceEvent(story.id)
  const conversation = isOptionalConversation(story.id)
  if (conversation && game.moves >= actionLimit(game)) return game
  let next = apply({...game, pending:game.pending.slice(1),
    seen:game.seen.includes(story.id) ? game.seen : [...game.seen, story.id]}, choice.effect, story.id)
  if (romance && choice.loveAction) next=changeRelationship(next,romance.person,choice.loveAction)
  if (choice.followUp) next.pending = [choice.followUp,...next.pending]
  if (conversation) next.moves++
  if (conversation || isHorrorLead(story.id)) {
    next.conversationsThisTerm = [...(game.conversationsThisTerm ?? []),story.id]
  }
  if (story.id === 'su-1' && index === 0) next = unlock(next, 'night')
  if (story.id === 'cat' && index === 0) next = unlock(next, 'cat')
  return updateBadges(queueStories(addLog(conversation?checkRelationshipRisk(next):next, story.title + ' · ' + choice.label + '。' + (choice.reply ?? ''))))
}

export function examTarget(term: number) {
  return 39 + term * 4
}

export function examScore(game: Game) {
  const aptitude = (weightedTalent(talentsFor(game),routeWeights.honors) - 60) / 10
  return clamp(Math.round(game.stats.study * .76 + game.stats.mind * .14 + game.stats.body * .10 + aptitude),100)
}

function qualifiesForGraduation(game: Game) {
  return game.grades.filter(item => item.grade === '待补修').length <= 3 && game.stats.study >= 48
}

function romanceEnding(game: Game): Ending | undefined {
  if (game.identity) {
    const partners=currentPartners(game).map(id=>game.loveLife!.records[id]!)
    if (partners.length>1 && partners.every(record=>record.agreement==='open'&&record.trust>=45)) return 'honestLove'
    if (partners.length>1) return 'brokenTrust'
    const affinity=weightedTalent(talentsFor(game),routeWeights.love)
    const threshold=60-Math.round((affinity-60)/5)
    if (partners.length===1 && partners[0].trust>=40 && partners[0].affection>=threshold) return 'campusLove'
    if (game.loveLife?.hadBreakup || partners.length) return 'brokenTrust'
    return
  }
  const status = relationshipFor(game)
  if (status === 'single') return
  if (status === 'apart' || trustFor(game) < 40) return 'farewell'
  const threshold = 75 - Math.round((weightedTalent(talentsFor(game),routeWeights.love) - 60) / 6)
  if (game.bonds.su < threshold) return 'farewell'
  if (game.plan === 'distance') return trustFor(game) >= 58 ? 'distance' : 'farewell'
  return 'love'
}

function relationshipEpilogue(game: Game): string | undefined {
  const ending = game.ending
  if (game.identity && ending && !isSpecialEnding(ending)) {
    const names=currentPartners(game).map(id=>people[id].name)
    if (names.length && ending!=='brokenTrust') return game.identity.name+'和'+names.join('、')+'重新确认了毕业后的安排。'
    if (ending==='brokenTrust') {
      const ended=eligiblePeople(game).filter(id=>game.loveLife?.records[id]?.stage==='estranged').map(id=>people[id].name)
      if (ended.length) return game.identity.name+'最后一次写下'+ended.join('、')+'的名字，想起有些事只能让对方自己决定。'
    }
    return
  }
  if (!ending || isSpecialEnding(ending)) return
  if (ending === 'distance' || ending === 'farewell') {
    const career = game.career === 'product' || game.career === 'writing' ? game.career : undefined
    if (career) return careerFit(game,career) >= careerTarget
      ? (career === 'product' ? '到新城市后，你入职了医疗产品团队。' : '到新城市后，你去了科普编辑部。')
      : '你的作品集还差一轮实测。你找了份实习，打算边做边补。'
    if (game.career === 'medicine') return '隔天，你带着排班表去报到，开始第一段临床轮转。'
  } else if (ending !== 'love' && relationshipFor(game) === 'dating') {
    return '从校门出来时，晚晴在路口等你。她把两个人约好的下一个空档圈在日历上，和你各留一份。'
  }
}

export function endingEpilogue(game: Game) {
  const relationship = relationshipEpilogue(game)
  if (!game.ending || isSpecialEnding(game.ending)) return relationship
  const scenes: Partial<Record<ThreadFlag,string>> = {
    'tutor-finish':'下一届发来新版互助讲义，最后一栏还留着你们的错题。',
    'sound-finish':'知遥把校园声音地图的试听链接发来。你戴上一侧耳机，听完了旧楼那次下课铃。',
    'clinic-finish':'出发前，社区站用上了你们一起试读过的新版指引。',
    'paper-finish':'一舟发来新的复验记录。表格里仍留着没有解释的那一列。',
    'rain-finish':'下雨时，跑步群里还有人把你们画的替代路线转给新生。',
    'letters-finish':'小满按信封上的日期发来消息，问你原先约的周末还空不空。',
  }
  const memory = [...(game.milestones ?? [])].reverse().find(id=>scenes[id])
  return [relationship,memory && scenes[memory]].filter(Boolean).join('\n\n') || undefined
}

export function getEnding(game: Game): Ending {
  if (!qualifiesForGraduation(game)) return 'extension'
  const romance = romanceEnding(game)
  if (romance === 'distance' || romance === 'farewell' || romance==='brokenTrust') return romance
  if (game.career === 'medicine') return 'medicine'
  if (game.career === 'product' || game.career === 'writing') {
    return careerFit(game,game.career) >= careerTarget ? game.career : 'exploration'
  }
  const talents = talentsFor(game)
  if (romance) return romance
  const radio = game.milestones?.includes('radio-finish') && bondFor(game,'xu') >= 23
  const community = game.milestones?.includes('care-finish') && bondFor(game,'tang') >= 25
  if (community && (!radio || bondFor(game,'tang') >= bondFor(game,'xu'))) return 'community'
  if (radio) return 'radio'
  const candidates: {id: Exclude<Route,'love'>; value: number; eligible: boolean}[] = [
    {id:'lab', value:game.routes.lab, eligible:game.routes.lab >= 12 && game.bonds.chen >= 52},
    {id:'honors', value:game.routes.honors, eligible:game.routes.honors >= 11 && game.grades.filter(item => item.grade === '优秀').length >= 4},
    {id:'friends', value:game.routes.friends, eligible:game.routes.friends >= 12 && game.stats.social >= 65},
    {id:'rest', value:game.routes.rest, eligible:game.routes.rest >= 12 && game.stats.mind >= 66 && game.stats.body >= 60},
    {id:'clinic', value:game.routes.clinic, eligible:game.routes.clinic >= 10 && game.stats.study >= 66},
  ]
  const weightedScore = (item: typeof candidates[number]) =>
    item.value * (1 + (weightedTalent(talents,routeWeights[item.id]) - 60) / 125)
  return candidates.filter(item => item.eligible).sort((a,b) => weightedScore(b) - weightedScore(a))[0]?.id ?? 'ordinary'
}

export function finishTerm(game: Game): Game {
  if (game.ending || game.pending.length || game.moves < ACTIONS_PER_TERM) return game
  const checked = checkRelationshipRisk(game,true)
  if (checked.pending.length) return checked
  game = checked
  const score = examScore(game)
  const target = examTarget(game.term)
  const grade: Grade = score >= target + 15 ? '优秀' : score >= target ? '通过' : '待补修'
  const bonus = grade === '优秀' ? 48 : grade === '通过' ? 18 : 0
  const grades = [...game.grades, {score, grade}]
  let next = addLog(apply({...game, grades}, {cash:bonus, mind:grade === '待补修' ? -5 : 4}), exams[game.term] + '考核 · ' + grade + '（' + score + ' 分）')
  if (game.term === TERM_COUNT - 1) {
    return updateBadges(game.clues?.length
      ? {...next, pending:[graduationFork]}
      : {...next, ending:getEnding(next)})
  }
  const term = game.term + 1
  next = apply({...next, term, moves:0, pending:[terms[term].id]}, {body:9, mind:6, cash:85})
  if (game.conversationsThisTerm) next.conversationsThisTerm = []
  delete next.extraTime
  return updateBadges(queueStories(next))
}

function hasRecord(value: unknown, keys: readonly string[], max: number) {
  if (!value || typeof value !== 'object') return false
  const record = value as Record<string, unknown>
  return keys.every(key => Number.isInteger(record[key]) && Number(record[key]) >= 0 && Number(record[key]) <= max)
}

function validGame(value: unknown): value is Game {
  if (!value || typeof value !== 'object') return false
  const game = value as Game
  const awaitingGraduation = Array.isArray(game.pending) && game.pending.length === 1 && game.pending[0] === graduationFork
  return Number.isInteger(game.term) && game.term >= 0 && game.term < TERM_COUNT
    && Number.isInteger(game.moves) && game.moves >= 0 && game.moves <= actionLimit(game)
    && Number.isInteger(game.seed) && game.seed >= 0 && game.seed <= 0xffffffff
    && Number.isInteger(game.runs) && game.runs >= 0 && typeof game.promise === 'boolean'
    && hasRecord(game.stats, statKeys.filter(key => key !== 'cash'), 100) && hasRecord(game.stats, ['cash'], 9999)
    && (game.avatar === undefined || (Number.isInteger(game.avatar) && game.avatar >= 0 && game.avatar < 64))
    && (game.talents === undefined || hasRecord(game.talents,talentIds,100))
    && (game.projects === undefined || hasRecord(game.projects,projectIds,MAX_ACTIONS_PER_TERM * TERM_COUNT))
    && (game.relationship === undefined || ['single','dating','apart'].includes(game.relationship))
    && (game.plan === undefined || ['open','together','distance'].includes(game.plan))
    && (game.trust === undefined || (Number.isInteger(game.trust) && game.trust >= 0 && game.trust <= 100))
    && (game.conversationsThisTerm === undefined || (Array.isArray(game.conversationsThisTerm)
      && game.conversationsThisTerm.every(id => conversationById.has(id) || isHorrorLead(id) || (typeof id==='string' && !!romanceEvent(id) && permittedStory(game,id)))))
    && (game.career === undefined || careerIds.includes(game.career))
    && ((game.identity===undefined && game.loveLife===undefined) || (game.identity!==undefined
      && game.loveLife!==undefined && validIdentity(game.identity) && validLoveLife(game.loveLife,game.identity)))
    && (game.reply === undefined || (game.reply && typeof game.reply.storyId==='string' && Number.isInteger(game.reply.choice)
      && game.reply.choice >= 0 && permittedStory(game,game.reply.storyId)
      && game.reply.choice < (currentStory({...game,pending:[game.reply.storyId]})?.choices.length ?? 0)))
    && (game.chapterMode === undefined || game.chapterMode === true)
    && (game.extraTime === undefined || game.extraTime === true)
    && (game.milestones === undefined || (Array.isArray(game.milestones) && game.milestones.every(id => threadFlags.includes(id))))
    && hasRecord(game.bonds, corePeople, 100)
    && hasRecord(game.bonds, personKeys.filter(id => Object.hasOwn(game.bonds,id)), 100) && hasRecord(game.routes, routeKeys, 1000)
    && locations.some(location => location.id === game.selected && location.unlock <= game.term)
    && Array.isArray(game.pending) && (awaitingGraduation || game.pending.every(id => typeof id==='string' && permittedStory(game,id)))
    && (game.clues === undefined || (Array.isArray(game.clues) && game.clues.every(id => typeof id === 'string' && isSpecialEnding(id))))
    && Array.isArray(game.seen) && game.seen.every(id => typeof id==='string' && permittedStory(game,id))
    && Array.isArray(game.log) && game.log.every(item => typeof item === 'string')
    && Array.isArray(game.badges) && game.badges.every(id => Object.hasOwn(badges,id))
    && Array.isArray(game.grades) && game.grades.length === game.term + (game.ending || awaitingGraduation ? 1 : 0)
    && game.grades.every(item => item && Number.isInteger(item.score) && item.score >= 0 && item.score <= 100 && ['优秀','通过','待补修'].includes(item.grade))
    && (!awaitingGraduation || (!game.ending && game.term === TERM_COUNT - 1 && game.moves >= ACTIONS_PER_TERM && !!game.clues?.length))
    && (!game.ending || (game.term === TERM_COUNT - 1 && game.moves >= ACTIONS_PER_TERM && !game.pending.length && Object.hasOwn(endings,game.ending)))
}

// Retired routes can still be present in either save slot.
export function restoreGame(value: unknown): Game | undefined {
  if (validGame(value)) return value
  if (!value || typeof value !== 'object') return
  const game = value as Game
  if (!Array.isArray(game.pending) || !Array.isArray(game.seen)) return
  const retired = (id: string | undefined) => id === 'catPhd' || id === 'canteen'
  const wasRetiredEnding = retired(game.ending)
  const withoutRetired = (items: string[]) => items.filter(item => !retired(item))
  const clues = Array.isArray(game.clues) ? game.clues.filter(id => !retired(id)) : game.clues
  const pending = withoutRetired(game.pending)
  const lostFinale = pending[0] === graduationFork && !clues?.length && Array.isArray(game.clues) && game.clues.some(retired)
  if (lostFinale) pending.shift()
  const candidate = {...game, pending, seen:withoutRetired(game.seen), clues,
    ending:wasRetiredEnding || lostFinale ? 'ordinary' as const : game.ending}
  if (!validGame(candidate)) return
  return wasRetiredEnding || lostFinale ? {...candidate,ending:getEnding(candidate)} : candidate
}

export function readProfile(raw: string | null): Profile {
  if (!raw) return emptyProfile()
  try {
    const value = JSON.parse(raw) as Partial<Profile> | null
    if (value?.version !== 1) return emptyProfile()
    return {
      version:1,
      auto:restoreGame(value.auto),
      manual:restoreGame(value.manual),
      badges:Array.isArray(value.badges) ? value.badges.filter(id => Object.hasOwn(badges,id)) : [],
      endings:Array.isArray(value.endings) ? value.endings.filter(id => Object.hasOwn(endings,id)) : [],
    }
  } catch {
    return emptyProfile()
  }
}

export function recordGame(profile: Profile, game: Game): Profile {
  const endings = [...new Set([...profile.endings, ...(game.ending ? [game.ending] : [])])]
  const badges = [...new Set([...profile.badges, ...game.badges])]
  if (endings.length >= 3 && !badges.includes('replay')) badges.push('replay')
  return {...profile, auto:game, badges, endings}
}
