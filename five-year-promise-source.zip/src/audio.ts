import { useEffect, useRef, useState } from 'react'
import { performance, voices } from './audio-direction'
import type { Track, VoiceCue } from './audio-direction'
import voiceFiles from './voice-catalog.json'

const localVoices = new Set<string>(voiceFiles)
const settingsKey = 'qinghe-audio-v1'
type AudioSettings = {music:boolean; voice:boolean; musicLevel:number; voiceLevel:number}
const defaults: AudioSettings = {music:false,voice:false,musicLevel:55,voiceLevel:75}
const level = (n: unknown,fallback:number) => typeof n==='number'&&Number.isFinite(n)?Math.min(100,Math.max(0,n)):fallback
function loadSettings(): AudioSettings {
  try {
    const value = JSON.parse(localStorage.getItem(settingsKey) ?? '{}')
    return {music:value.music===true,voice:value.voice===true,musicLevel:level(value.musicLevel,55),voiceLevel:level(value.voiceLevel,75)}
  } catch { return defaults }
}

type Embedded = Window & {qingheAudio?: Record<string,string>; webkitAudioContext?: typeof AudioContext}
function fileUrl(path: string) {
  return (window as Embedded).qingheAudio?.[path] ?? import.meta.env.BASE_URL + path
}
type Playing = {source:AudioBufferSourceNode; gain:GainNode; start:number; offset:number; key:Track}
type MusicStatus = 'off'|'locked'|'loading'|'playing'|'error'
type VoiceStatus = 'idle'|'playing'|'system'|'unavailable'

class Mixer {
  context?: AudioContext
  music?: Playing
  voice?: AudioBufferSourceNode
  voiceBus?: GainNode
  musicBus?: GainNode
  voiceLevel = .75
  musicLevel = .55
  speaking = false
  private musicRequest = 0
  private voiceRequest = 0
  private tracks = new Map<string,Promise<AudioBuffer>>()
  private offsets = new Map<Track,number>()

  async activate() {
    const Constructor = window.AudioContext ?? (window as Embedded).webkitAudioContext
    if (!Constructor) throw Error('AudioContext unavailable')
    if (!this.context) {
      const context = this.context = new Constructor()
      this.musicBus = context.createGain()
      this.voiceBus = context.createGain()
      this.musicBus.connect(context.destination)
      this.voiceBus.connect(context.destination)
      this.setLevels(this.musicLevel*100,this.voiceLevel*100)
    }
    if (this.context.state!=='running') await this.context.resume()
  }

  setLevels(music:number,voice:number) {
    this.musicLevel = music/100
    this.voiceLevel = voice/100
    const now = this.context?.currentTime ?? 0
    this.musicBus?.gain.setTargetAtTime(this.musicLevel*(this.speaking ? .28 : .67),now,.075)
    this.voiceBus?.gain.setTargetAtTime(this.voiceLevel*.85,now,.06)
  }

  private buffer(path:string) {
    const load = async () => {
      const response = await fetch(fileUrl(path))
      if (!response.ok) throw Error('Audio fetch failed')
      return this.context!.decodeAudioData(await response.arrayBuffer())
    }
    if (!path.startsWith('bgm/')) return load()
    const existing = this.tracks.get(path)
    if (existing) return existing
    const pending = load().catch(error=>{this.tracks.delete(path);throw error})
    this.tracks.set(path,pending)
    if (this.tracks.size>5) this.tracks.delete(this.tracks.keys().next().value!)
    return pending
  }

  async playMusic(key:Track) {
    if (!this.context || this.context.state!=='running') return false
    const request=++this.musicRequest
    if (this.music?.key===key) return true
    const buffer=await this.buffer('bgm/'+key+'.mp3')
    if (request!==this.musicRequest) return false
    const context=this.context
    const source=context.createBufferSource()
    source.buffer=buffer
    source.loop=true
    const gain=context.createGain()
    source.connect(gain).connect(this.musicBus!)
    const offset=(this.offsets.get(key) ?? 0)%buffer.duration
    const now=context.currentTime
    gain.gain.setValueAtTime(0,now)
    gain.gain.linearRampToValueAtTime(1,now+1.1)
    this.fadeMusic(.95)
    source.start(now,offset)
    source.onended=()=>{source.disconnect();gain.disconnect()}
    this.music={source,gain,key,start:now,offset}
    return true
  }

  private fadeMusic(seconds:number) {
    const old=this.music
    if (!old || !this.context) return
    const now=this.context.currentTime
    this.offsets.set(old.key,old.offset+now-old.start)
    const gain=old.gain.gain
    gain.cancelScheduledValues(now)
    gain.setValueAtTime(gain.value,now)
    gain.linearRampToValueAtTime(0,now+seconds)
    old.source.stop(now+seconds+.02)
    this.music=undefined
  }

  stopMusic() {
    this.musicRequest++
    this.fadeMusic(.3)
  }

  private duck(value:boolean) {
    this.speaking=value
    this.setLevels(this.musicLevel*100,this.voiceLevel*100)
  }

  stopVoice() {
    this.voiceRequest++
    if (this.voice) {
      this.voice.onended=null
      this.voice.stop()
      this.voice.disconnect()
      this.voice=undefined
    }
    window.speechSynthesis?.cancel()
    this.duck(false)
  }

  async playVoice(cue:VoiceCue,setStatus:(status:VoiceStatus)=>void,after?:()=>void) {
    this.stopVoice()
    const request=++this.voiceRequest
    if (localVoices.has(cue.key) && this.context?.state==='running') {
      try {
        const buffer=await this.buffer('voice/'+cue.key+'.mp3')
        if(request!==this.voiceRequest) return
        const source=this.context.createBufferSource()
        source.buffer=buffer
        source.connect(this.voiceBus!)
        this.voice=source
        this.duck(true)
        setStatus('playing')
        source.onended=()=>{
          source.disconnect()
          if(request===this.voiceRequest){this.voice=undefined;this.duck(false);setStatus('idle');after?.()}
        }
        source.start()
        return
      } catch { /* Fall through to a local system voice. */ }
    }
    if(request!==this.voiceRequest) return
    const speech=window.speechSynthesis
    const available=speech?.getVoices().filter(voice=>voice.localService && /^zh([-_]|$)/i.test(voice.lang)) ?? []
    if (!available.length || !('SpeechSynthesisUtterance' in window)) {setStatus('unavailable');after?.();return}
    const profile=voices[cue.role]
    const emotion=performance[cue.emotion]
    const preferred=available.filter(voice=>/cn|hans/i.test(voice.lang))
    const pool=preferred.length?preferred:available
    const line=new SpeechSynthesisUtterance(cue.text)
    line.voice=pool[profile.sid%pool.length]
    line.lang=line.voice.lang
    line.rate=profile.rate*emotion.rate
    line.pitch=profile.pitch*emotion.pitch
    line.volume=this.voiceLevel
    line.onstart=()=>{if(request===this.voiceRequest){this.duck(true);setStatus('system')}}
    line.onend=()=>{if(request===this.voiceRequest){this.duck(false);setStatus('idle');after?.()}}
    line.onerror=()=>{if(request===this.voiceRequest){this.duck(false);setStatus('unavailable');after?.()}}
    speech.speak(line)
  }

  close() {
    this.stopMusic()
    this.stopVoice()
    void this.context?.close().catch(()=>{})
  }
}

export function useAudio(track:Track,cue?:VoiceCue,lead?:VoiceCue) {
  const [settings,setSettings]=useState(loadSettings)
  const [unlocked,setUnlocked]=useState(false)
  const [musicStatus,setMusicStatus]=useState<MusicStatus>('off')
  const [voiceStatus,setVoiceStatus]=useState<VoiceStatus>('idle')
  const mixer=useRef<Mixer|null>(null)
  if(!mixer.current) mixer.current=new Mixer()
  const output=mixer.current
  const currentCue=useRef({cue,lead})
  currentCue.current={cue,lead}
  function playLines(line:VoiceCue,opening?:VoiceCue) {
    if(opening) void output.playVoice(opening,setVoiceStatus,()=>{void output.playVoice(line,setVoiceStatus)})
    else void output.playVoice(line,setVoiceStatus)
  }
  async function activate() {
    try {await output.activate();setUnlocked(true)}
    catch {setMusicStatus('error')}
  }

  useEffect(()=>{
    function unlockOnGesture() {if(settings.music||settings.voice) void activate()}
    if(!unlocked) {
      window.addEventListener('pointerdown',unlockOnGesture)
      window.addEventListener('keydown',unlockOnGesture)
    }
    return ()=>{
      window.removeEventListener('pointerdown',unlockOnGesture)
      window.removeEventListener('keydown',unlockOnGesture)
    }
  },[unlocked,settings.music,settings.voice])
  useEffect(()=>()=>output.close(),[output])
  useEffect(()=>{
    output.setLevels(settings.musicLevel,settings.voiceLevel)
    try {localStorage.setItem(settingsKey,JSON.stringify(settings))} catch { /* In-memory controls remain available. */ }
  },[output,settings])
  useEffect(()=>{
    let active=true
    if(!settings.music || !unlocked) {
      output.stopMusic()
      setMusicStatus(settings.music?'locked':'off')
      return
    }
    setMusicStatus('loading')
    output.playMusic(track).then(playing=>{if(active)setMusicStatus(playing?'playing':'locked')})
      .catch(()=>{if(active)setMusicStatus('error')})
    return ()=>{active=false}
  },[track,settings.music,unlocked,output])
  useEffect(()=>{
    const {cue:line,lead:opening}=currentCue.current
    if(settings.voice && unlocked && line) playLines(line,opening)
    else {output.stopVoice();setVoiceStatus('idle')}
    return ()=>output.stopVoice()
  },[cue?.key,lead?.key,settings.voice,unlocked,output])

  function change(update:Partial<AudioSettings>) {
    if(update.music===true||update.voice===true) void activate()
    setSettings(settings=>({...settings,...update}))
  }
  function replay() {
    if(!cue) return
    if(!unlocked||!settings.voice){change({voice:true});return}
    playLines(cue,lead)
  }
  async function playSample(sample:VoiceCue) {
    try {await output.activate();await output.playVoice(sample,setVoiceStatus)}
    catch {setVoiceStatus('unavailable')}
  }
  return {settings,change,replay,playSample,musicStatus,voiceStatus}
}
