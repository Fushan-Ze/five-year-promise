export const talentLabels = {
  looks:'容貌', character:'性格', wisdom:'智慧', resilience:'韧性', creativity:'创意',
} as const
export type Talent = keyof typeof talentLabels
export type Talents = Record<Talent,number>
export const talentIds = Object.keys(talentLabels) as Talent[]
export const neutralTalents: Talents = {looks:60,character:60,wisdom:60,resilience:60,creativity:60}

export function rollTalents(seed: number): Talents {
  // A separate random stream keeps campus encounters independent of character generation.
  let state = (seed ^ 0x9e3779b9) >>> 0
  function uniform() {
    state = (state + 0x6d2b79f5) >>> 0
    let bits = Math.imul(state ^ (state >>> 15), state | 1)
    bits ^= bits + Math.imul(bits ^ (bits >>> 7), bits | 61)
    return ((bits ^ (bits >>> 14)) >>> 0) / 4294967296
  }
  const shared = (uniform() - .5) * 10
  const next = {...neutralTalents}
  for (const id of talentIds) {
    const center = id === 'wisdom' ? 65 : 60
    const independent = (uniform() + uniform() + uniform() - 1.5) * 23
    next[id] = Math.round(Math.min(95,Math.max(25,center + shared + independent)))
  }
  return next
}

export function growTalents(talents: Talents, growth: Partial<Talents>): Talents {
  const next = {...talents}
  for (const id of talentIds) {
    const amount = growth[id] ?? 0
    const adjusted = talents[id] >= 85 ? Math.ceil(amount / 2) : amount
    next[id] = Math.min(100,talents[id] + adjusted)
  }
  return next
}

export const routeWeights = {
  honors:{wisdom:.75,resilience:.25},
  lab:{wisdom:.55,creativity:.30,resilience:.15},
  love:{looks:.35,character:.55,resilience:.10},
  friends:{character:.70,resilience:.20,looks:.10},
  rest:{resilience:.80,character:.20},
  clinic:{wisdom:.40,character:.30,resilience:.30},
  product:{creativity:.45,wisdom:.35,resilience:.20},
  writing:{character:.40,creativity:.40,wisdom:.20},
} satisfies Record<string, Partial<Talents>>

export function weightedTalent(talents: Talents, weights: Partial<Talents>) {
  return talentIds.reduce((sum,id) => sum + talents[id] * (weights[id] ?? 0),0)
}
