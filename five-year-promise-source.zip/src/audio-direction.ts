import { endings } from './content.ts'
import type { Choice, Ending, Person, Story, StoryScene } from './content.ts'
import type { Gender } from './relationships.ts'
import type { Game } from './game.ts'

export type Track = 'menu'|'arrival'|'study'|'lab'|'community'|'dorm'|'clinical'|'date'|'warm'|'conflict'|'mystery'|'dread'|'danger'|'decision'|'farewell'|'ending'
export type Emotion = 'plain'|'warm'|'focused'|'hurt'|'fear'|'hope'
export type VoiceRole = Person | 'mentor' | 'narrator' | 'playerMale' | 'playerFemale'
export const emotions: Record<Emotion,string> = {plain:'平静',warm:'亲近',focused:'认真',hurt:'失落',fear:'紧张',hope:'轻快'}
export const voices: Record<VoiceRole,{sid:number;rate:number;pitch:number;label:string}> = {
  lin:{sid:61,rate:1.06,pitch:1.05,label:'干脆 · 有笑意'},
  su:{sid:7,rate:.94,pitch:1.02,label:'轻柔 · 留停顿'},
  chen:{sid:40,rate:.98,pitch:.96,label:'克制 · 清楚'},
  xu:{sid:18,rate:1.01,pitch:1.04,label:'细腻 · 清亮'},
  tang:{sid:24,rate:1.05,pitch:1.01,label:'直率 · 温暖'},
  shen:{sid:80,rate:.92,pitch:.96,label:'低声 · 谨慎'},
  yan:{sid:75,rate:1.06,pitch:.98,label:'明快 · 爽朗'},
  lu:{sid:32,rate:.91,pitch:.87,label:'慢声 · 克制'},
  qiao:{sid:144,rate:1,pitch:.84,label:'扎实 · 平稳'},
  ji:{sid:23,rate:.95,pitch:.85,label:'清晰 · 留白'},
  he:{sid:44,rate:1.02,pitch:.89,label:'热情 · 松弛'},
  zhou:{sid:83,rate:.94,pitch:.85,label:'平缓 · 沉着'},
  playerMale:{sid:15,rate:1.02,pitch:.99,label:'主角 · 男声'},
  playerFemale:{sid:9,rate:1.01,pitch:1.02,label:'主角 · 女声'},
  mentor:{sid:145,rate:.96,pitch:.94,label:'沉稳 · 平缓'},
  narrator:{sid:100,rate:1,pitch:1,label:'旁白 · 平稳'},
}
export const performance: Record<Emotion,{rate:number;pitch:number;gain:number;contour:number}> = {
  plain:{rate:1,pitch:1,gain:1,contour:.018}, warm:{rate:.94,pitch:1.04,gain:.95,contour:.052},
  focused:{rate:1.025,pitch:.98,gain:1,contour:.026}, hurt:{rate:.88,pitch:.94,gain:.92,contour:.040},
  fear:{rate:1.04,pitch:1.09,gain:.94,contour:.085}, hope:{rate:1.045,pitch:1.06,gain:1,contour:.062},
}

const romance = /^(rel-.*-(date|single|open|secret)$|date-|talk-ask|talk-reconcile|partner-plan|su-2)/
const climax = /^(hunt-ward-door|hunt-room-lights)$/
const termTracks: Track[] = ['arrival','arrival','lab','study','lab','community','clinical','warm','clinical','farewell']
const strange = /^(ledger|ninth|graduation-fork)$/

export function storyEmotion(story: Story, choice?: Choice): Emotion {
  if (choice?.emotion) return choice.emotion
  if (story.tone==='horror') return 'fear'
  if (choice && ((choice.effect.trust ?? 0)<0 || Object.values(choice.effect.bond ?? {}).some(n=>n<0))) return 'hurt'
  if (romance.test(story.id) || story.kind.includes('恋爱')) return 'warm'
  if (/科研|临床|生涯/.test(story.kind)) return 'focused'
  if (choice?.effect.milestone) return 'hope'
  return story.emotion ?? 'plain'
}

export function soundtrack(game?: Game, story?: Story, choice?: Choice): Track {
  if (!game) return 'menu'
  if (story) {
    if (story.tone==='horror') return climax.test(story.id) ? 'danger' : 'dread'
    if (story.kind==='关系冲突' || story.kind==='重遇与边界') return 'conflict'
    if (strange.test(story.id)) return 'mystery'
    const emotion = storyEmotion(story,choice)
    if (emotion==='hurt') return 'conflict'
    if (romance.test(story.id) || story.kind.includes('恋爱')) return story.id==='partner-plan' && !choice ? 'farewell' : 'date'
    if (emotion==='warm') return 'warm'
    if (/科研/.test(story.kind)) return 'lab'
    if (/临床/.test(story.kind)) return 'clinical'
    if (/生涯/.test(story.kind)) return 'decision'
    if (story.id==='term-9' || story.scene==='station') return 'farewell'
    if (story.id.startsWith('term-')) return termTracks[game.term] ?? 'warm'
    if (story.scene) return locationTrack(story.scene,game.term)
  }
  if (game.ending) return endingTrack(game.ending)
  if (game.moves >= 3 && game.term>=7) return game.term===9 ? 'farewell' : 'decision'
  return locationTrack(game.selected,game.term)
}

function locationTrack(scene: StoryScene, term: number): Track {
  switch(scene) {
    case 'library': case 'classroom': return term>=9?'farewell':'study'
    case 'lab': return 'lab'
    case 'hospital': return 'clinical'
    case 'basement': case 'emptyDorm': return 'danger'
    case 'stair': return 'mystery'
    case 'community': case 'canteen': return 'community'
    case 'garden': case 'cafe': return 'date'
    case 'roof': return term>=7?'farewell':'warm'
    case 'station': return 'farewell'
    case 'career': return 'decision'
    case 'gate': return term>=7?'farewell':'arrival'
    case 'workshop': return 'warm'
    case 'archive': case 'studio': return 'warm'
    case 'dorm': return term>=8?'farewell':'dorm'
    default: return term<4?'arrival':term>=8?'farewell':'warm'
  }
}
function endingTrack(ending: Ending): Track {
  if (ending==='ward' || ending==='roommate') return 'danger'
  if (ending==='ledger' || ending==='ninth') return 'mystery'
  if (ending==='love' || ending==='distance' || ending==='campusLove' || ending==='honestLove') return 'ending'
  if (ending==='farewell' || ending==='extension' || ending==='brokenTrust') return 'farewell'
  return 'ending'
}

export type VoiceCue = {key:string;text:string;role:VoiceRole;emotion:Emotion}
export function voiceCue(story: Story, choice?: Choice): VoiceCue {
  const source = (choice?.reply ?? story.text).trim()
  const dialogue = [...source.matchAll(/[「“]([^」”]+)[」”]/g)].map(match=>match[1]).join(' ')
  const role = story.person ?? (story.voice ? 'mentor' : 'narrator')
  const text = role==='narrator' ? source : (dialogue || source)
  return makeCue(role,storyEmotion(story,choice),text)
}
function makeCue(role:VoiceRole,emotion:Emotion,text:string): VoiceCue {
  let hash=2166136261
  for (const char of role+':'+emotion+':'+text) hash=Math.imul(hash^char.codePointAt(0)!,16777619)
  return {key:(hash>>>0).toString(16).padStart(8,'0'),text,role,emotion}
}

export function endingNarration(id:Ending): Story {
  const ending=endings[id]
  const tone=id==='ward'||id==='roommate'?'horror':undefined
  return {id:'ending-'+id,kind:'结局',title:ending.name,text:ending.text,choices:[],tone,
    emotion:id==='farewell'||id==='extension'?'hurt':tone?'fear':'warm'}
}

export const protagonistSample = '你好，我是来青禾医大报到的新生。'
export function protagonistCue(gender:Gender,text:string,emotion:Emotion='plain') {
  return makeCue(gender==='female'?'playerFemale':'playerMale',emotion,text)
}
