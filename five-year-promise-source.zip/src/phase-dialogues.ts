import type { Choice, Effect, LocationId, Person } from './content.ts'
import type { Emotion } from './audio-direction.ts'
import type { Conversation } from './conversations.ts'

const response = (label:string,reply:string,emotion:Emotion,effect:Effect): Choice=>({label,reply,emotion,effect})
function scene(id:string,person:Person,location:LocationId,unlock:number,through:number,entry:string,title:string,text:string,
  emotion:Emotion,choices:Choice[],when:Partial<Conversation>={}): Conversation {
  return {id,person,location,scene:location,unlock,through,entry,title,text,emotion,choices,kind:'阶段对话',...when}
}
export const phaseDialogues: Conversation[] = [
  scene('phase-lin-early','lin','dorm',0,2,'问小满习惯几点关灯','宿舍里的第一条规矩','小满把刚买的台灯转向墙面。「我睡得早，但你不用跟着我。我们先试一晚，哪里别扭就改。」','hope',[
    response('先试一晚，明早交换意见','「行。我明早小声一点，你也别替我按闹钟。」','warm',{bond:{lin:6},mind:3}),
    response('照自己的习惯来，不必商量','「那我就先戴耳塞。要改的时候你再跟我说。」','hurt',{bond:{lin:-4}})]),
  scene('phase-lin-middle','lin','canteen',3,6,'听小满说一次改主意','她把报名表折了起来','小满盯着两份实习报名表。「我好像一直在选别人听了会说好的事。今天我想先吃完饭，再选一次。」','plain',[
    response('问她自己最舍不得放掉哪件事','「其实是周末的志愿班。说出口以后，我才发现我早选好了。」','warm',{bond:{lin:8},mind:4}),
    response('帮她把两个选项的时间成本列清楚','「好，先把我不能挪的周六圈出来。」','focused',{bond:{lin:6},study:4})]),
  scene('phase-lin-late','lin','garden',7,9,'跟小满谈毕业后的联系','群名不用改了','小满把手机扣在长椅上。「我怕以后只剩群里过年发红包。你有空的时候，可不可以说一声你现在在哪儿？」','warm',[
    response('约好彼此方便的日子，有变化再重新约','「那先约一个我真的能去的周末，别从一年后开始等。」','hope',{bond:{lin:8},route:{friends:2}}),
    response('告诉她不用每次都有事才联系','「那我下次拍到好看的晚霞就直接发给你。」','warm',{bond:{lin:7},mind:5})],{minBond:22}),
  scene('phase-su-early','su','track',0,2,'和晚晴聊起跑步的理由','手表已经关了','晚晴拿着手表，却没按下开始。「我以前跑完才敢休息。现在我想试试，今天不跑够也可以回去吃饭。」','plain',[
    response('陪她走一段，今天不记成绩','「好。到路灯那边我们就转回去，不多绕一圈。」','warm',{bond:{su:7},mind:4}),
    response('问她下次要不要一起分配体力','「可以，下次先听我说今天想跑多远。」','focused',{bond:{su:5},body:5})]),
  scene('phase-su-dating','su','garden',3,8,'和晚晴约一次不用赶时间的散步','下次从这棵树出发','雨后的小径只剩一把长椅是干的。晚晴把你们第一次合照翻出来。「那天我很紧张。你是不是以为我一直在看手机？」','warm',[
    response('说自己当时也紧张，约下次再一起走','「那我们下次都不用装镇定。先从这棵树出发。」','hope',{bond:{su:8},trust:7,route:{love:1}}),
    response('说自己没留意，请她再讲讲那天','「其实我打了三遍想说的话，最后一遍也没发出去。」','warm',{bond:{su:6},trust:5}),
    response('说那只是小事，转身催她走','「你先走吧。我想自己再坐一会儿。」','hurt',{bond:{su:-7},trust:-8})],{requires:'dating',kind:'恋爱约会'}),
  scene('phase-su-late','su','roof',7,9,'问晚晴异地以后最担心什么','那张表要留两个人的空档','晚晴把车票放在栏杆上，手没有松开。「我不怕换城市。我怕我们每次都只问对方什么时候有空。」','warm',[
    response('各说一件愿意为下次见面做的事','「我会提前查车次。你也说一件你真的愿意做的事。」','hope',{bond:{su:7},trust:9,route:{love:1}}),
    response('先讨论没办法见面时怎么说','「先说想见，再说今天为什么见不了。我希望我们都能这样。」','focused',{bond:{su:5},trust:7}),
    response('说到时候自然有办法','「这句话我听过几次了。我想知道下一次具体是哪天。」','hurt',{bond:{su:-8},trust:-10})],{requires:'dating',kind:'恋爱长谈'}),
  scene('phase-chen-early','chen','lab',2,3,'请一舟教我记录第一次复验','从哪一行开始','一舟把空白记录本放到桌边。「我第一次复验，把时间写在了手套上。等我脱下来，那一整段就丢了。」','focused',[
    response('先说自己最怕忘记的步骤，请他帮忙核对','「好。把提醒写到最前面，我们按顺序做。」','focused',{bond:{chen:6},study:5}),
    response('请他保留那段失败经历，讲给下一届','「也可以。原来这件事比结果还容易记住。」','warm',{bond:{chen:6},growth:{creativity:1}})],{kind:'科研对话'}),
  scene('phase-chen-middle','chen','lab',4,6,'跟一舟核对互相矛盾的两条曲线','两份结果都先留下','一舟把两张图投在同一面墙上。「它们不可能同时是同一回事。但在查到不同之前，我想先把两份都留下。」','focused',[
    response('比对采样条件，把不能确定的地方标出来','「对。先别把猜测写成结论。」','focused',{bond:{chen:7},study:7,route:{lab:1}}),
    response('建议用更好看的那张先交差','「那之后的人怎么知道我们删掉了什么？」','hurt',{bond:{chen:-6}})],{kind:'科研对话'}),
  scene('phase-chen-late','chen','library',7,9,'与一舟整理交给新组员的文件','把空白也交出去','一舟把压缩包命名为交接稿，却没点发送。「我原本想把最后几列都填上。后来发现，留着没查过的地方更诚实。」','focused',[
    response('写清最后一次核对发生在什么时候','「我再补一句，下次遇到不同的数据先留下来。」','warm',{bond:{chen:8},study:6,route:{lab:2}}),
    response('把没回答的几个问题写成后续提纲','「这样挺好。新的人可以从自己的问题开始。」','hope',{bond:{chen:7},growth:{creativity:2}})],{minBond:22,kind:'科研对话'}),
  scene('phase-xu-early','xu','archive',0,2,'问知遥第一次录到什么','她先按了暂停','知遥从盒里抽出一卷磁带。「最早录的是闭馆广播。里面也有人说了不想被录进去的话。所以我现在总先问。」','plain',[
    response('问清她愿意把哪一段放给我听','「开头三秒可以。后面有人在说私事，我们停一下。」','focused',{bond:{xu:6},growth:{character:1}}),
    response('一起录一段自己同意留下的环境声','「好。你负责听，我负责按下录音键。」','hope',{bond:{xu:6},growth:{creativity:1}})]),
  scene('phase-xu-middle','xu','archive',3,6,'和知遥试听剪掉的五秒','五秒也能留下来','知遥拉开音轨里的空白。「对方说不想重录。有人觉得听众会嫌断，我觉得断一下也可以。」','focused',[
    response('把空白保留，说明当事人选择撤回','「那我们留的是她的选择。够了。」','warm',{bond:{xu:8},growth:{character:2}}),
    response('先确认她想不想留下环境声','「我再问一次。她不回的话，就留空白。」','focused',{bond:{xu:7},growth:{creativity:2}})],{needs:'radio-start'}),
  scene('phase-xu-late','xu','garden',7,9,'和知遥在银杏路听最终节目','最后一声铃来自谁','知遥把一侧耳机让给你。「这段播完以后，会有一届新生进来。我想知道他们最先会记住哪一声。」','hope',[
    response('把新生的第一条留言也留进校史记录','「好，记得先问他同不同意。我们可以从新的声音接下去。」','warm',{bond:{xu:8},growth:{creativity:2}}),
    response('把旧版留在原处，再给下一届留空音轨','「让他们自己按第一次录音键。这样最好。」','hope',{bond:{xu:8},mind:6})],{needs:'radio-finish'}),
  scene('phase-tang-early','tang','community',3,4,'请唐禾说说她为什么一直来','坐下来的人比较敢问','唐禾把椅子拉离墙边。「有人站着就总觉得自己该走了。坐下来以后，他才会把真正想问的那句说出来。」','plain',[
    response('陪她看看哪个位置坐下最方便','「先从进门那边试。有拐杖的人不用绕过排队的线。」','focused',{bond:{tang:6},social:5}),
    response('问她上次有谁在这里多坐了一会儿','「一位刚来这座城的人。她问完路以后，又问了下次还开不开。」','warm',{bond:{tang:6},mind:4})]),
  scene('phase-tang-middle','tang','community',5,7,'和唐禾谈那条没改好的指引','先听走错的人讲','唐禾拿来一张标满箭头的纸。「改了两轮还有人走错。我们如果现在去问，可能会听见不太好听的话。」','focused',[
    response('愿意一起听，先不急着解释','「那我来记，等他说完我们再问从哪里开始走错。」','hope',{bond:{tang:8},social:5,route:{clinic:1}}),
    response('先标出仍然不确定的地方，等下班再查','「好，留到下一班也可以。记得写清楚我们试过什么。」','focused',{bond:{tang:6},study:4})],{needs:'care-start'}),
  scene('phase-tang-late','tang','community',8,9,'请唐禾带我见接班的志愿者','她把钥匙交出去','唐禾把钥匙放到新人桌上。「我原来怕他们把东西都改回去。现在我比较想知道，他们会看到我们没看到的什么。」','hope',[
    response('听新人讲自己的办法，只补交接时漏掉的信息','「我也来听，今天先不替他们改。」','warm',{bond:{tang:8},route:{friends:2}}),
    response('邀请新人和来访者再走一遍','「好。这回我站最后，让他们自己带路。」','hope',{bond:{tang:8},route:{clinic:2}})],{needs:'care-finish'}),
  scene('phase-shen-early','shen','stair',6,6,'问沈棠为什么总多看一次门缝','楼层记录上的空格','沈棠把楼层记录折到背面。「上一个人说他亲眼看见门关了。但没说是从里往外看，还是从外往里看。」','focused',[
    response('和她一起从两边各核对一次','「你站亮处。听到我报楼层再下来。」','focused',{bond:{shen:7},study:4}),
    response('把没有确认的那格先留空','「对。只写我们知道的，空着也算一种记录。」','plain',{bond:{shen:6},growth:{resilience:2}})]),
  scene('phase-shen-evidence','shen','stair',6,9,'找沈棠复听那段楼梯录音','多出来的一次呼吸','沈棠把录音音量调低。「我只数了三次。第四次后面，为什么还有一口气？我们两个人都在屏住呼吸。」','fear',[
    response('按掉录音，先一起走到灯亮的地方','「好。上去再说，别在这里把那一口气听第二遍。」','fear',{bond:{shen:8},mind:5}),
    response('先记下时间，再把录音锁起来','「记好了就合上本子。刚才那一秒，又长了一点。」','fear',{bond:{shen:6},mind:-5})],{needs:'ward-proof',tone:'horror',kind:'恐怖调查'}),
  scene('phase-shen-late','shen','hospital',8,9,'和沈棠对最后一份交接表','交班以后把门留给白天','沈棠把名字划到已交接的一栏。「如果下一班没看到我们看到的东西，也不必逼他们相信。写清楚发生过什么就够了。」','focused',[
    response('分开写亲眼所见和还未证实的部分','「这样他们至少知道该从哪里重新查。」','warm',{bond:{shen:8},growth:{resilience:2}}),
    response('问她有没有想留给白班的话','「如果有人说楼梯多了一层，先陪他走回有人的地方。」','plain',{bond:{shen:7},mind:5})],{minBond:15}),
]
