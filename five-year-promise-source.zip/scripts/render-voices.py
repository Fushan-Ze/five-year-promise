"""Render generated Mandarin cues. Requires sherpa-onnx, numpy and ffmpeg."""
import concurrent.futures
import json
import pathlib
import subprocess
import sys

import numpy as np
import sherpa_onnx

tts = None
output = None

def setup(model_dir, destination):
    global tts, output
    path = pathlib.Path(model_dir)
    output = pathlib.Path(destination)
    vits = sherpa_onnx.OfflineTtsVitsModelConfig(model=str(path/'model.onnx'),
        lexicon=str(path/'lexicon.txt'), tokens=str(path/'tokens.txt'))
    model = sherpa_onnx.OfflineTtsModelConfig(vits=vits,num_threads=1)
    config = sherpa_onnx.OfflineTtsConfig(model=model,
        rule_fsts=','.join(str(path/name) for name in ('phone.fst','date.fst','number.fst','new_heteronym.fst')))
    tts = sherpa_onnx.OfflineTts(config)

def render(cue):
    target = output/(cue['key']+'.mp3')
    if target.exists() and target.stat().st_size>300:
        return cue['key']
    line = cue['text'].replace('B1','负一层').replace('B2','负二层').replace(' · ','，')
    spoken = tts.generate(line,sid=cue['sid'],speed=cue['rate']/cue['pitch'])
    samples = np.asarray(spoken.samples,dtype=np.float32)
    if samples.size<1000 or not np.isfinite(samples).all():
        raise ValueError(cue['key']+' produced invalid speech')
    time = np.linspace(0,1,samples.size,endpoint=False)
    pitch = cue['pitch']*(1+cue['contour']*np.sin(np.pi*time)*(1-2*time))
    position = np.cumsum(pitch)
    index = np.arange(np.searchsorted(position,samples.size-1))
    shaped = np.interp(position[index],np.arange(samples.size),samples)
    peak = max(float(np.max(np.abs(shaped))),0.001)
    rms = max(float(np.sqrt(np.mean(shaped**2))),0.001)
    shaped *= min(.9/peak,.115/rms)*cue['gain']
    subprocess.run(['ffmpeg','-v','error','-y','-f','f32le','-ar',str(spoken.sample_rate),
                    '-ac','1','-i','-','-ar','24000','-b:a','32k',str(target)],
                   input=shaped.astype('<f4').tobytes(),check=True)
    return cue['key']

if __name__=='__main__':
    model,script,dest,catalog=sys.argv[1:]
    pathlib.Path(dest).mkdir(parents=True,exist_ok=True)
    cues=json.loads(pathlib.Path(script).read_text())
    keys=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=4,initializer=setup,initargs=(model,dest)) as pool:
        for key in pool.map(render,cues):
            keys.append(key)
            if len(keys)%40==0:
                print(f'{len(keys)}/{len(cues)}',flush=True)
    pathlib.Path(catalog).write_text(json.dumps(keys,indent=2)+'\n')
    print(f'{len(keys)} voice clips',flush=True)
