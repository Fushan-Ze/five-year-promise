import { candidates, romanceStory } from '../src/relationships.ts'
import { endingNarration, performance, protagonistCue, protagonistSample, voiceCue, voices } from '../src/audio-direction.ts'
import { chapters, chapterStories } from '../src/chapters.ts'
import { careerStories, chance, detours, endings, sideStories, terms } from '../src/content.ts'
import { conversations, partnerPlans } from '../src/conversations.ts'
import { currentStory, startGame } from '../src/game.ts'

const state = startGame(42)
const named = startGame(42,true,{name:'示例',gender:'male'})
const dating = {...named,loveLife:{...named.loveLife,records:{su:{stage:'dating',affection:65,trust:58,agreement:'exclusive'}}}}
const dynamic = [
  currentStory({...state,term:7,pending:['term-7'],relationship:'dating'}),
  currentStory({...named,term:7,pending:['term-7']}),
  currentStory({...dating,term:7,pending:['term-7']}),
  currentStory({...dating,term:9,pending:['term-9']}),
  currentStory({...named,loveLife:{...named.loveLife,hadBreakup:true},term:9,pending:['term-9']}),
  currentStory({...state,term:9,pending:['term-9'],relationship:'dating'}),
  currentStory({...state,term:9,pending:['term-9'],relationship:'apart'}),
  currentStory({...state,term:9,pending:['graduation-fork'],clues:['ward']}),
]
const moments = ['meet','meet2','grow','single','open','secret','date','boundary','conflict','estranged']
const relationships = Object.keys(candidates).flatMap(id=>moments.map(moment=>romanceStory('rel-'+id+'-'+moment)))
const stories = [...relationships,...conversations,partnerPlans,...terms,...chapters.map(chapter=>chapter.opening),
  ...chapterStories,...Object.values(detours).map(item=>item.story),...careerStories,...sideStories,...chance,
  ...dynamic,...Object.keys(endings).map(endingNarration)]
const cues = new Map()
function append(cue) {
  const voice = voices[cue.role], emotion = performance[cue.emotion]
  cues.set(cue.key,{...cue,sid:voice.sid,rate:voice.rate*emotion.rate,pitch:voice.pitch*emotion.pitch,gain:emotion.gain,contour:emotion.contour})
}
for (const story of stories) {
  for (const choice of [undefined,...story.choices.filter(item=>item.reply)]) {
    append(voiceCue(story,choice))
    if (choice?.playerLine) append(protagonistCue(candidates[story.person].gender==='male'?'female':'male',choice.playerLine))
  }
}
for(const gender of ['male','female']) append(protagonistCue(gender,protagonistSample))
console.log(JSON.stringify([...cues.values()],null,2))
