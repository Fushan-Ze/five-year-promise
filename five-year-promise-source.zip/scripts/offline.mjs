import { readFile, readdir, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'

const folder = new URL('../dist/', import.meta.url)
const output = resolve(process.argv[2] ?? 'play-offline.html')
const html = await readFile(new URL('index.html', folder), 'utf8')
const script = html.match(/<script type="module"[^>]* src="([^"]+)"[^>]*><\/script>/)
const stylesheet = html.match(/<link rel="stylesheet"[^>]* href="([^"]+)"[^>]*>/)
if (!script || !stylesheet) throw new Error('Missing Vite build assets. Run npm run build first.')
const js = await readFile(new URL(script[1],folder),'utf8')
const css = await readFile(new URL(stylesheet[1],folder),'utf8')
const embedded = {}
for (const directory of ['bgm','voice']) {
  const assets = new URL(directory+'/',folder)
  for (const name of (await readdir(assets)).sort()) {
    if (!name.endsWith('.mp3')) continue
    const bytes = await readFile(new URL(name,assets))
    embedded[directory+'/'+name] = 'data:audio/mpeg;base64,'+bytes.toString('base64')
  }
}
const audio = '<script>window.qingheAudio='+JSON.stringify(embedded)+'</script>'
await writeFile(output, html.replace(script[0], () => audio + '<script type="module">' + js.replace(/<\/script/gi, '<\\/script') + '</script>')
  .replace(stylesheet[0], () => '<style>' + css + '</style>'))
console.log(output)
