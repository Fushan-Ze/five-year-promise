import { activeSlot, addRun, mergeSaveBooks, readSaveBook, saveRun, selectRun } from '../src/saves.ts'
import assert from 'node:assert/strict'
import test from 'node:test'
import { neutralTalents, rollTalents, talentIds } from '../src/talents.ts'
import { chance, detours, endings, specialEndingIds, terms } from '../src/content.ts'
import { act, actionLimit, availableActions, availableChapter, availableConversations, bondFor, careerFit, choose, currentStory, emptyProfile, endingEpilogue, finishTerm, getEnding, investigationNotes, leaveConversation, openChapter, openConversation, projectNotes, readProfile, recordGame, relationshipFor, selectLocation, startGame, talentsFor, trustFor, unlockExtraTime } from '../src/game.ts'

function clearStories(game, plan) {
  while (currentStory(game)) {
    const story = currentStory(game)
    const pick = plan?.story?.(story.id, game.term) ?? 0
    const next = choose(game, pick)
    assert.notEqual(next, game, story.id)
    game = next
  }
  return game
}

const study = ['library',0]
const sleep = ['dorm',0]
const room = ['dorm',1]
const stroll = ['track',1]
const run = ['track',0]
const lab = ['lab',0]
const clinic = ['hospital',0]
const work = ['canteen',2]
const path = (opening, later, split = 3) => (term, move) => (term < split ? opening : later)[move]

const plans = {
  honors: {action:path([study,study,sleep],[study,sleep,run]), story:id => id === 'term-0' ? 1 : 0},
  lab: {action:path([study,study,sleep],[lab,lab,sleep],2)},
  love: {action:path([study,stroll,study],[stroll,study,sleep],2)},
  friends: {action:path([study,room,study],[room,study,room],2)},
  rest: {action:path([study,sleep,study],[sleep,sleep,study],2), story:id => id === 'term-0' ? 2 : 0},
  clinic: {action:path([study,run,work],[clinic,clinic,sleep],6), story:id => id === 'term-5' ? 1 : 0},
  ordinary: {action:path([study,work,run],[work,run,run],5), story:id => id === 'term-5' ? 1 : 0},
  extension: {action:()=>sleep},
}

test('开场剧情、地点开放、余额和行动次数限制', () => {
  const opening = startGame(1)
  assert.equal(act(opening,0), opening)
  const game = choose(opening,1)
  assert.equal(game.moves,0)
  assert.equal(game.stats.study,31)
  assert.equal(selectLocation(game,'lab'),game)
  assert.equal(selectLocation(game,'hospital'),game)
  assert.equal(finishTerm(game),game)
  const broke = {...selectLocation(game,'canteen'), stats:{...game.stats,cash:0}}
  assert.equal(act(broke,0),broke)
  assert.equal(act(broke,2).stats.cash,65)
})

test('随机事件可重现，未读剧情与手动存档可恢复', () => {
  const game = choose(startGame(0),0)
  const rolled = act(game,0)
  assert.equal(rolled.seed,1013904223)
  assert.ok(chance.some(event => event.id === currentStory(rolled)?.id))
  assert.deepEqual(act(game,0),rolled)
  const profile = {...recordGame(emptyProfile(),rolled),manual:game}
  const saved = readProfile(JSON.stringify(profile))
  assert.deepEqual(saved,profile)
  assert.equal(currentStory(saved.auto).id,currentStory(rolled).id)
  assert.deepEqual(readProfile('{bad'),emptyProfile())
  assert.equal(readProfile(JSON.stringify({...profile,auto:{...rolled,term:99}})).auto,undefined)
})

let collection = emptyProfile()
for (const [expected,base] of Object.entries(plans)) {
  const plan = {...base, story:(id,term) => id === 'su-2' && expected !== 'love' ? 1 : base.story?.(id,term) ?? 0}
  test('完整十学期可到达结局 · ' + endings[expected].name, () => {
    let game = clearStories(startGame(42), plan)
    for (let term=0; term<terms.length; term++) {
      assert.equal(game.term,term)
      for (let move=0; move<3; move++) {
        const [id,index] = plan.action(term,move)
        game = selectLocation(game,id)
        assert.equal(game.selected,id)
        game = clearStories(act(game,index),plan)
        assert.equal(game.moves,move+1)
      }
      assert.equal(act(game,0),game)
      game = clearStories(finishTerm(game),plan)
      assert.equal(game.grades.length,term+1)
    }
    assert.equal(game.ending,expected,JSON.stringify({routes:game.routes,stats:game.stats,grades:game.grades}))
    assert.equal(finishTerm(game),game)
    assert.deepEqual(readProfile(JSON.stringify(recordGame(emptyProfile(),game))).auto,game)
    collection = recordGame(collection,game)
  })
}
test('跨周目图鉴去重并保留手动档', () => {
  assert.equal(collection.endings.length,8)
  assert.ok(collection.badges.includes('replay'))
  assert.ok(collection.badges.includes('night'))
  assert.ok(collection.badges.includes('runner'))
  const manual = collection.auto
  const replay = recordGame({...collection,manual}, startGame(2))
  assert.equal(replay.manual,manual)
  assert.equal(replay.endings.length,8)
  assert.equal(replay.auto.term,0)
})

function visitDetours({decline = []} = {}) {
  const plan = plans.honors
  let game = clearStories(startGame(42),plan)
  for (let term=0; term<terms.length; term++) {
    for (let move=0; move<3; move++) {
      const detour = specialEndingIds.filter(id => detours[id].unlock === term)[move]
      if (!detour) {
        const investigations = term===3 && !decline.includes('roommate')
          ? [['archive','hunt-room-proof'],['dorm','hunt-room-lights']]
          : term===7 && !decline.includes('ward') ? [['stair','hunt-ward-proof'],['hospital','hunt-ward-door']] : []
        if (investigations[move]) {
          const [place,id] = investigations[move]
          game = openConversation(selectLocation(game,place),id)
          assert.equal(currentStory(game).id,id)
          game = clearStories(choose(game,0),plan)
          continue
        }
        const [place,index] = plan.action(term,move)
        game = clearStories(act(selectLocation(game,place),index),plan)
        continue
      }
      game = selectLocation(game,detours[detour].location)
      const index = availableActions(game).findIndex(action => action.detour === detour)
      assert.ok(index >= 0, detour)
      game = act(game,index)
      assert.equal(game.moves,move+1)
      assert.equal(currentStory(game).id,detour)
      const restored = readProfile(JSON.stringify(recordGame(emptyProfile(),game))).auto
      assert.deepEqual(restored,game)
      game = clearStories(restored,{story:id => decline.includes(id) ? 1 : 0})
      assert.ok(!availableActions(game).some(action => action.detour === detour))
    }
    game = finishTerm(game)
    if (term < terms.length-1) game = clearStories(game,plan)
  }
  return game
}

test('四条地图支线和四种结局均可在十学期内走通', () => {
  const fork = visitDetours()
  assert.equal(fork.ending,undefined)
  assert.equal(fork.grades.length,10)
  assert.equal(currentStory(fork).title,'毕业照之后')
  const restored = readProfile(JSON.stringify({...recordGame(collection,fork),manual:fork}))
  assert.deepEqual(restored.auto,fork)
  assert.deepEqual(restored.manual,fork)
  let archive = restored
  for (const id of specialEndingIds) {
    const index = currentStory(restored.auto).choices.findIndex(choice => choice.outcome === id)
    assert.ok(index >= 0, id)
    const finished = choose(restored.auto,index)
    assert.equal(finished.ending,id)
    assert.equal(finished.grades.length,10)
    assert.equal(currentStory(finished),undefined)
    archive = recordGame(archive,finished)
    assert.deepEqual(readProfile(JSON.stringify(archive)).auto,finished)
  }
  assert.equal(archive.endings.length,8+specialEndingIds.length)
  assert.equal(archive.manual.ending,undefined)
  const regular = choose(restored.manual,specialEndingIds.length)
  assert.equal(regular.ending,getEnding(fork))
  assert.deepEqual(regular.grades,fork.grades)
})

test('提前到场或放弃调查不会解锁对应结局', () => {
  const opening = clearStories(startGame(42))
  assert.ok(!availableActions(selectLocation(opening,'dorm')).some(action => action.detour === 'roommate'))
  const ordinary = visitDetours({decline:specialEndingIds})
  assert.equal(currentStory(ordinary),undefined)
  assert.equal(ordinary.ending,getEnding(ordinary))
  assert.equal(ordinary.clues,undefined)
})

test('旧版通关存档与收集记录可以直接继续使用', () => {
  const {talents,avatar,...oldGame} = collection.auto
  const v1 = {...collection,auto:oldGame,manual:oldGame}
  assert.ok(!Object.hasOwn(v1.auto,'clues'))
  assert.deepEqual(readProfile(JSON.stringify(v1)),v1)
  assert.equal(readProfile(JSON.stringify(v1)).endings.length,8)
})

test('开局属性有界且集中，读档不会重新摇点', () => {
  const profiles = Array.from({length:3000},(_,seed)=>rollTalents(seed))
  for (const id of talentIds) {
    const values = profiles.map(profile=>profile[id])
    assert.ok(values.every(value=>Number.isInteger(value) && value>=25 && value<=95))
    assert.ok(values.filter(value=>value>=45 && value<=80).length>2500,id)
  }
  assert.notDeepEqual(profiles[7],profiles[8])
  const game = startGame(42)
  assert.deepEqual(readProfile(JSON.stringify(recordGame(emptyProfile(),game))).auto.talents,game.talents)
})

test('容貌影响初次好感，熟悉后性格权重更高，行动可以提高分数', () => {
  const base = choose(startGame(42),1)
  const first = selectLocation(base,'track')
  const looks = { ...neutralTalents,looks:85,character:40 }
  const character = { ...neutralTalents,looks:40,character:85 }
  const gain = (talents,su) => act({...first,talents,bonds:{...first.bonds,su}},1).bonds.su - su
  assert.ok(gain(looks,0)>gain(character,0))
  assert.ok(gain(looks,50)<gain(character,50))
  const study = selectLocation({...base,talents:neutralTalents},'library')
  assert.equal(act(study,0).talents.wisdom,62)
  assert.equal(act({...study,talents:{...neutralTalents,wisdom:99}},0).talents.wisdom,100)
})

test('不同权重可以改变同路线点数的结局', () => {
  const game = {...startGame(42),stats:{study:85,mind:85,body:80,social:85,cash:220},
    routes:{honors:0,lab:15,love:0,friends:15,rest:0,clinic:0},bonds:{lin:0,su:0,chen:60}}
  assert.equal(getEnding({...game,talents:{...neutralTalents,wisdom:86,creativity:80,character:42}}),'lab')
  assert.equal(getEnding({...game,talents:{...neutralTalents,wisdom:48,creativity:42,character:88}}),'friends')
  assert.notEqual(getEnding({...game,talents:{...neutralTalents,looks:100},bonds:{lin:0,su:100,chen:60}}),'love')
})

for (const [ending,decision,project] of [['product',1,'product'],['writing',2,'writing'],['medicine',0],['exploration',1]]) {
  test('完整十学期生涯路线 · '+ending, () => {
    const plan = {story:id => id === 'career-open' ? 1 : id === 'career-decision' ? decision : 0}
    let game = clearStories({...startGame(42),talents:{looks:60,character:50,wisdom:55,resilience:45,creativity:45}},plan)
    for (let term=0; term<terms.length; term++) {
      for (let move=0; move<3; move++) {
        if (project && term>=5 && term<=7 && move===2) {
          game = selectLocation(game,project==='product'?'lab':'library')
          const index = availableActions(game).findIndex(action=>action.effect.project===project)
          assert.ok(index>=0)
          const prior = careerFit(game,project)
          game = clearStories(act(game,index),plan)
          assert.ok(careerFit(game,project)>prior)
        } else {
          game = clearStories(act(selectLocation(game,'library'),0),plan)
        }
      }
      game = clearStories(finishTerm(game),plan)
    }
    assert.ok(game.seen.includes('career-open') && game.seen.includes('career-decision'))
    assert.equal(game.ending,ending)
    assert.deepEqual(readProfile(JSON.stringify(recordGame(emptyProfile(),game))).auto,game)
  })
}

test('退役的搞笑支线会从旧存档迁移，其他进度照常可用', () => {
  const active = choose(startGame(1),1)
  const fork = visitDetours()
  const retired = readProfile(JSON.stringify({
    ...collection,endings:['honors','catPhd','canteen'],
    auto:{...active,pending:['canteen'],seen:['catPhd','canteen'],clues:['catPhd','canteen']},
    manual:{...fork,clues:['canteen']},
  }))
  assert.deepEqual(retired.endings,['honors'])
  assert.equal(retired.auto.stats.study,active.stats.study)
  assert.equal(retired.auto.pending.length,0)
  assert.equal(retired.manual.ending,getEnding(fork))
  assert.equal(retired.manual.grades.length,10)
  assert.ok(!Object.hasOwn(endings,'catPhd'))
  const completed = readProfile(JSON.stringify({...retired,manual:{...fork,clues:['catPhd'],pending:[],ending:'catPhd'}}))
  assert.equal(completed.manual.ending,getEnding(fork))
  assert.deepEqual(talentsFor({...active,talents:undefined}),neutralTalents)
})

test('可以免费预览对话并换地点，回应扣行动且地点影响好感', () => {
  const game = choose({...startGame(42),talents:neutralTalents},1)
  const library = selectLocation(game,'library')
  assert.equal(openConversation(library,'talk-library'),library)
  const track = selectLocation(game,'track')
  const preview = openConversation(track,'talk-track')
  assert.equal(preview.moves,track.moves)
  assert.deepEqual(readProfile(JSON.stringify(recordGame(emptyProfile(),preview))).auto,preview)
  assert.equal(currentStory(preview).title,'慢半步也可以')
  assert.deepEqual(leaveConversation(preview),track)
  const dorm = selectLocation(leaveConversation(preview),'dorm')
  assert.ok(availableConversations(dorm).some(item=>item.id==='talk-room'))
  const after = choose(preview,0)
  assert.equal(after.moves,1)
  assert.equal(after.bonds.su,10)
  assert.ok(after.log[0].includes('不用看表'))
  assert.equal(openConversation(after,'talk-track'),after)
  const later = { ...game, term:2, bonds:{...game.bonds,su:50} }
  const libraryChat = openConversation(selectLocation(later,'library'),'talk-library')
  const roofChat = openConversation(selectLocation(later,'roof'),'talk-roof')
  assert.equal(choose(libraryChat,1).bonds.su-50,6)
  assert.equal(choose(roofChat,0).bonds.su-50,14)
})

test('确定关系后约会开放，信任会下降，可以分开也可以修复', () => {
  const base = choose(startGame(42),1)
  const game = {...base,term:3,bonds:{...base.bonds,su:62},talents:neutralTalents}
  const single = selectLocation(game,'garden')
  assert.ok(!availableConversations(single).some(item=>item.id==='date-garden'))
  const dating = clearStories(choose(openConversation(single,'talk-ask'),0))
  assert.equal(relationshipFor(dating),'dating')
  const date = openConversation(dating,'date-garden')
  const hurt = choose(date,2)
  const cared = choose(date,0)
  assert.equal(hurt.bonds.su,dating.bonds.su-10)
  assert.equal(trustFor(hurt),trustFor(dating)-12)
  assert.equal(trustFor(cared),trustFor(dating)+10)
  const apart = clearStories(choose(openConversation(selectLocation(hurt,'roof'),'date-roof'),2))
  assert.equal(relationshipFor(apart),'apart')
  const reconciled = clearStories(choose(openConversation(selectLocation({...apart,moves:0},'garden'),'talk-reconcile'),0))
  assert.equal(relationshipFor(reconciled),'dating')
})

for (const [decision,ending] of [[0,'love'],[1,'distance'],[2,'farewell']]) {
  test('完整十学期关系结局 · '+ending, () => {
    let sawCoupleMain = false
    const plan = {story:(id)=>id==='partner-plan'?decision:0}
    let game = clearStories(startGame(42),plan)
    for (let term=0;term<terms.length;term++) {
      for (const [place,index] of [study,stroll,study]) {
        game=clearStories(act(selectLocation(game,place),index),plan)
      }
      game=finishTerm(game)
      if(currentStory(game)?.id==='term-7') sawCoupleMain=currentStory(game).text.includes('实习排班表')
      game=clearStories(game,plan)
    }
    assert.ok(sawCoupleMain)
    assert.ok(game.seen.includes('partner-plan'))
    assert.equal(game.ending,ending)
    assert.equal(game.grades.length,10)
    assert.deepEqual(readProfile(JSON.stringify(recordGame(emptyProfile(),game))).auto,game)
    if (ending==='distance') assert.match(endingEpilogue({...game,career:'medicine'}),/临床/)
  })
}

test('附院对话可以换求职方向，作品集和地图调查互不锁定', () => {
  const active = choose(startGame(42),1)
  const game = {...active,term:8,career:'product',projects:{product:2,writing:1}}
  const hospital = selectLocation(game,'hospital')
  const switched = choose(openConversation(hospital,'talk-career'),2)
  assert.equal(switched.career,'writing')
  assert.deepEqual(switched.projects,game.projects)
  const lab = selectLocation(clearStories(switched),'lab')
  assert.ok(availableActions(lab).some(action=>action.effect.project==='product'))
  assert.ok(availableConversations(lab).some(item=>item.id==='talk-lab'))
})

test('自由时段可选，最多使用四次，跨学期重置且旧考核照常', () => {
  const seed = clearStories(startGame(123))
  let game = seed
  for (let i=0;i<3;i++) game=clearStories(act(selectLocation(game,'library'),0))
  assert.equal(actionLimit(game),3)
  assert.equal(finishTerm(game).term,1)
  const open = unlockExtraTime(game)
  assert.equal(actionLimit(open),4)
  assert.equal(finishTerm(open).term,1)
  assert.deepEqual(readProfile(JSON.stringify(recordGame(emptyProfile(),open))).auto,open)
  const fourth = clearStories(choose(openConversation(selectLocation(open,'archive'),'talk-radio'),0))
  assert.equal(fourth.moves,4)
  assert.equal(act(fourth,0),fourth)
  const next = finishTerm(fourth)
  assert.equal(actionLimit(next),3)
  assert.equal(next.moves,0)
  assert.ok(next.milestones.includes('radio-start'))
})

test('恐怖调查逐步给出地点，撤退可以隔学期再回来', () => {
  const base = clearStories(startGame(42))
  const term = {...base,term:2}
  const dorm = selectLocation(term,'dorm')
  const start = act(dorm,availableActions(dorm).findIndex(action=>action.detour==='roommate'))
  assert.equal(currentStory(start).tone,'horror')
  const firstRetreat = clearStories(choose(start,1))
  assert.ok(!availableActions(firstRetreat).some(item=>item.detour==='roommate'))
  assert.ok(availableActions({...firstRetreat,term:3,conversationsThisTerm:[]}).some(item=>item.detour==='roommate'))
  const found = clearStories(choose(start,0))
  assert.equal(found.clues,undefined)
  assert.match(investigationNotes(found)[0].step,/档案室/)
  assert.ok(!availableConversations(found).some(item=>item.id==='hunt-room-lights'))
  const search = openConversation(selectLocation(found,'archive'),'hunt-room-proof')
  const retreat = clearStories(choose(search,1))
  assert.match(investigationNotes(retreat)[0].step,/档案室/)
  assert.ok(!availableConversations(retreat).some(item=>item.id==='hunt-room-proof'))
  const next = {...retreat,term:3,moves:0,conversationsThisTerm:[]}
  const evidence = clearStories(choose(openConversation(next,'hunt-room-proof'),0))
  assert.match(investigationNotes(evidence)[0].step,/303/)
  const night = openConversation(selectLocation(evidence,'dorm'),'hunt-room-lights')
  assert.equal(currentStory(night).scene,'emptyDorm')
  const confirmed = clearStories(choose(night,0))
  assert.deepEqual(confirmed.clues,['roommate'])
  assert.match(investigationNotes(confirmed)[0].step,/已收录/)
})

for (const [ending,place,steps,person] of [
  ['radio','archive',[[0,'talk-radio'],[2,'talk-radio-listen'],[3,'talk-radio-edit']],'xu'],
  ['community','community',[[3,'talk-community'],[4,'talk-community-check'],[5,'talk-community-plan']],'tang'],
]) {
  test('完整十学期新增人物线 · '+ending, () => {
    const plan = {story:id=>id==='su-2'?1:0}
    let game = clearStories(startGame(42),plan)
    for (let term=0;term<terms.length;term++) {
      for (let move=0;move<3;move++) {
        const id = move===0 && steps.find(([when])=>when===term)?.[1]
        if (id) {
          game=openConversation(selectLocation(game,place),id)
          assert.equal(currentStory(game).id,id)
          game=clearStories(choose(game,0),plan)
        } else {
          game=clearStories(act(selectLocation(game,'library'),0),plan)
        }
      }
      game=clearStories(finishTerm(game),plan)
    }
    assert.ok(bondFor(game,person)>=25)
    assert.equal(game.ending,ending)
    assert.deepEqual(readProfile(JSON.stringify(recordGame(emptyProfile(),game))).auto,game)
  })
}

test('旧自动档与手动档分别迁移，可以并行保存、开新游戏和分叉', () => {
  const auto = startGame(42)
  const manual = choose(auto,1)
  const old = recordGame({...emptyProfile(),manual},auto)
  const migrated = readSaveBook(JSON.stringify(old))
  assert.equal(migrated.slots.length,2)
  assert.deepEqual(activeSlot(migrated).game,auto)
  const newRun = addRun(migrated,startGame(123,true),'second-run',1)
  const branched = addRun(selectRun(newRun,'legacy-manual'),manual,'fork-run',2,true)
  const changed = saveRun(branched,act(selectLocation(manual,'library'),0),3)
  const restored = readSaveBook(JSON.stringify(changed))
  assert.equal(restored.slots.length,4)
  assert.equal(activeSlot(restored).game.moves,1)
  assert.equal(restored.slots.find(slot=>slot.id==='legacy-manual').game.moves,0)
  assert.equal(restored.slots.find(slot=>slot.id==='second-run').game.chapterMode,true)
  assert.equal(restored.slots.find(slot=>slot.id==='legacy-auto').game.pending[0],'term-0')
})

test('不同存档的并行变更会合并，损坏的条目不会吞掉其他进度', () => {
  const first = addRun(readSaveBook(null),startGame(21),'one',1)
  const second = addRun(first,startGame(22),'two',2)
  const updatedFirst = saveRun(first,choose(activeSlot(first).game,0),3)
  const merged = mergeSaveBooks(second,updatedFirst)
  const bad = {id:'broken',game:{...startGame(11),pending:['graduation-fork'],clues:'bad'}}
  const restored = readSaveBook(JSON.stringify({...merged,slots:[bad,...merged.slots]}))
  assert.equal(restored.slots.length,2)
  assert.equal(activeSlot(restored).game.pending.length,0)
  assert.equal(restored.slots.find(slot=>slot.id==='two').game.pending[0],'term-0')
})

test('专题可选择两条不同后续，原周目可主动开启或跳过', () => {
  const legacy = choose(startGame(42),1)
  assert.equal(availableChapter(legacy).id,'chapter-0')
  const open = openChapter(legacy)
  const a = choose(open,0)
  const b = choose(open,1)
  assert.equal(currentStory(a).id,'chapter-0-0')
  assert.equal(currentStory(b).id,'chapter-0-1')
  assert.equal(choose(open,2).pending.length,0)
  assert.equal(a.moves,0)
  const pendingReply = {...a,reply:{storyId:'chapter-0',choice:0}}
  const saved = addRun(readSaveBook(null),pendingReply,'reply',1)
  assert.deepEqual(activeSlot(readSaveBook(JSON.stringify(saved))).game,pendingReply)
})

test('新版路线可走完十学期，专题和跨地点项目在同一周目并行', context => {
  let game = startGame(42,true)
  let dialogueChoices = 0
  let readingLength = 0
  const count = value=>value?.replace(/\s/g,'').length ?? 0
  const read = current => {
    while (currentStory(current)) {
      const story = currentStory(current)
      const index = story.id==='su-2' ? 1 : 0
      readingLength += count(story.title)+count(story.text)+count(story.choices[index].reply)
        + story.choices.reduce((n,choice)=>n+count(choice.label)+count(choice.note),0)
      dialogueChoices++
      const next = choose(current,index)
      assert.notEqual(next,current,story.id)
      current = next
    }
    return current
  }
  let actions = 0
  const projects = new Map([[1,['library','work-tutor']],[2,['archive','work-sound']],
    [3,['lab','work-paper']],[4,['garden','work-sound-finish']],[5,['library','work-paper-finish']],
    [6,['hospital','work-clinic']],[7,['community','work-clinic-finish']]])
  for (let term=0;term<terms.length;term++) {
    game=read(game)
    for (let move=0;move<3;move++) {
      if (move===0 && projects.has(term)) {
        const [place,id] = projects.get(term)
        game=openConversation(selectLocation(game,place),id)
        assert.equal(currentStory(game).id,id)
        game=read(game)
      } else {
        game=read(act(selectLocation(game,move===2?'dorm':'library'),0))
        actions++
      }
    }
    game=finishTerm(game)
  }
  assert.ok(game.ending)
  assert.equal(game.grades.length,10)
  assert.equal(game.seen.filter(id=>/^chapter-\d$/.test(id)).length,10)
  assert.equal(game.seen.filter(id=>/^chapter-\d-[01]$/.test(id)).length,10)
  assert.ok(projectNotes(game).filter(item=>item.complete).length>=3)
  assert.match(endingEpilogue(game),/新版指引/)
  context.diagnostic(`样例周目：${dialogueChoices} 次对话选择，${actions} 次其他行动，10 次考核，${readingLength} 字对话及选项`)
})
