import assert from 'node:assert/strict'
import { existsSync, readFileSync, statSync } from 'node:fs'
import test from 'node:test'
import { endingNarration, performance, soundtrack, voiceCue, voices } from '../src/audio-direction.ts'
import { conversationById } from '../src/conversations.ts'
import { terms } from '../src/content.ts'
import { availableConversations, currentStory, readProfile, recordGame, emptyProfile, startGame } from '../src/game.ts'

const catalog = JSON.parse(readFileSync(new URL('../src/music-catalog.json',import.meta.url)))
const clips = new Set(JSON.parse(readFileSync(new URL('../src/voice-catalog.json',import.meta.url))))
const dialogue = id=>conversationById.get(id)

test('音乐随学期、地点、约会回应、恐怖升级和结局切换',()=>{
  const game=startGame(42)
  assert.equal(soundtrack(),'menu')
  assert.equal(soundtrack(game,terms[0]),'arrival')
  assert.equal(soundtrack({...game,selected:'archive'},terms[0]),'arrival')
  assert.equal(soundtrack({...game,term:2},terms[2]),'lab')
  assert.equal(soundtrack({...game,term:6},terms[6]),'clinical')
  assert.equal(soundtrack({...game,selected:'library'}),'study')
  assert.equal(soundtrack({...game,selected:'library',term:9}),'farewell')
  const date=dialogue('phase-su-dating')
  assert.equal(soundtrack(game,date),'date')
  assert.equal(soundtrack(game,date,date.choices[2]),'conflict')
  assert.equal(soundtrack(game,dialogue('hunt-ward-proof')),'dread')
  assert.equal(soundtrack(game,dialogue('hunt-ward-door')),'danger')
  assert.equal(soundtrack({...game,ending:'love'}),'ending')
})

test('阶段对白遵守学期、恋爱关系与调查证据',()=>{
  const game={...startGame(42),pending:[],selected:'garden',term:4}
  const available=state=>availableConversations(state).map(item=>item.id)
  assert.ok(!available(game).includes('phase-su-dating'))
  assert.ok(available({...game,relationship:'dating'}).includes('phase-su-dating'))
  assert.ok(!available({...game,term:9,relationship:'dating'}).includes('phase-su-dating'))
  const stair={...game,selected:'stair',term:7}
  assert.ok(!available(stair).includes('phase-shen-evidence'))
  assert.ok(available({...stair,milestones:['ward-proof']}).includes('phase-shen-evidence'))
  const archive={...game,selected:'archive'}
  assert.ok(!available(archive).includes('phase-xu-middle'))
  assert.ok(available({...archive,milestones:['radio-start']}).includes('phase-xu-middle'))
})

test('同角色的情绪和配音键在读档后稳定',()=>{
  const story=dialogue('phase-su-dating')
  const hopeful=voiceCue(story,story.choices[0])
  const hurt=voiceCue(story,story.choices[2])
  assert.equal(hopeful.role,hurt.role)
  assert.equal(hopeful.emotion,'hope')
  assert.equal(hurt.emotion,'hurt')
  assert.notEqual(hopeful.key,hurt.key)
  assert.notEqual(performance.hope.rate,performance.hurt.rate)
  assert.equal(new Set(Object.values(voices).map(item=>item.sid)).size,16)
  const game={...startGame(42),selected:'garden',term:4,relationship:'dating',pending:[story.id],
    grades:Array.from({length:4},()=>({score:90,grade:'优秀'}))}
  const saved=readProfile(JSON.stringify(recordGame(emptyProfile(),game))).auto
  assert.equal(voiceCue(currentStory(saved),story.choices[2]).key,hurt.key)
  for(const cue of [hopeful,hurt,voiceCue(story),voiceCue(endingNarration('ward'))]) assert.ok(clips.has(cue.key))
})

test('曲目和预生成语音资产均完整存在',()=>{
  assert.equal(Object.keys(catalog).length,16)
  assert.ok(clips.size>=610)
  for(const [track,item] of Object.entries(catalog)){
    assert.match(item.isrc,/^USUAN\d{7}$/)
    assert.ok(statSync(new URL('../public/bgm/'+track+'.mp3',import.meta.url)).size>100000)
  }
  for(const cue of clips) assert.ok(existsSync(new URL('../public/voice/'+cue+'.mp3',import.meta.url)))
})
