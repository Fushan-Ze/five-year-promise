import assert from 'node:assert/strict'
import test from 'node:test'
import { people } from '../src/content.ts'
import { act, availableConversations, choose, currentStory, endingEpilogue, finishTerm, getEnding, openConversation, restoreGame, selectLocation, startGame } from '../src/game.ts'
import { candidates, changeRelationship, currentPartners, eligiblePeople, meetingChance, relationshipOffers } from '../src/relationships.ts'
import { addRun, readSaveBook } from '../src/saves.ts'

const opening = (gender='male', seed=42) => choose(startGame(seed,false,{name:'  测试  同学  ',gender}),1)
const rows = (game,person) => relationshipOffers(game).filter(row=>row.person===person)
const at = (game, selected, term=game.term) => ({...game,selected,term})
const apply = (game,id,...actions) => actions.reduce((state,action)=>changeRelationship(state,id,action),game)
const ready = (game,id) => apply(game,id,'interest','listen','cooperate')
const runDialogue = (game,id,index) => choose(openConversation(game,id),index)
const drain = game => {
  while (currentStory(game)) {
    const next=choose(game,0)
    assert.notEqual(next,game,currentStory(game).id)
    game=next
  }
  return game
}

test('姓名与性别随周目保存，每种主角各有五位可发展对象',()=>{
  for(const gender of ['male','female']){
    const game=opening(gender)
    assert.equal(game.identity.name,'测试 同学')
    const eligible=eligiblePeople(game)
    assert.equal(eligible.length,5)
    assert.ok(eligible.every(id=>candidates[id].gender!==gender))
    assert.equal(new Set(eligible.map(id=>people[id].name)).size,5)
    const book=addRun(readSaveBook(null),game,'test',1)
    assert.deepEqual(readSaveBook(JSON.stringify(book)).slots[0].game.identity,game.identity)
  }
})

test('相遇要满足时间和地点及个人条件，同局的概率不会因为读档重抽',()=>{
  const acrossSeeds=Array.from({length:200},(_,seed)=>at(opening('male',seed),'archive',1))
  assert.ok(acrossSeeds.every(game=>rows(game,'xu').length===0))
  const unlocked=acrossSeeds.map(game=>({...game,milestones:['radio-start']}))
  assert.ok(unlocked.some(game=>rows(game,'xu').length>0))
  assert.ok(unlocked.some(game=>rows(game,'xu').length===0))
  for(const game of unlocked){
    const original=rows(game,'xu')
    assert.deepEqual(rows(JSON.parse(JSON.stringify(game)),'xu'),original)
    assert.equal(rows(at(game,'library'),'xu').length,0)
    assert.equal(rows(at(game,'archive',9),'xu').length,0)
  }
  const neverMet=drain(opening())
  assert.deepEqual(neverMet.loveLife.records,{})
  const state=at(ready(neverMet,'lin'),'track')
  assert.ok(meetingChance(apply(state,'lin','exclusive'),'su')<meetingChance(state,'su'))
})

test('拒绝联系后无法日常闲聊，后来偶遇可以道歉或让冲突升级',()=>{
  const initial=Array.from({length:200},(_,seed)=>at(opening('male',seed),'track')).find(game=>rows(game,'su').length)
  const meet=rows(initial,'su')[0].id
  const reserved=runDialogue(initial,meet,2)
  assert.equal(reserved.loveLife.records.su,undefined)
  const estranged=runDialogue(initial,meet,3)
  assert.equal(estranged.loveLife.records.su.stage,'estranged')
  const later=[1,2,3,4,5,6,7].map(term=>({...estranged,term,moves:0,conversationsThisTerm:[]})).find(game=>rows(game,'su').some(row=>row.id==='rel-su-estranged'))
  assert.ok(later)
  assert.ok(!availableConversations(later).some(item=>item.id==='talk-track'))
  assert.equal(runDialogue(later,'rel-su-estranged',0).loveLife.records.su.stage,'estranged')
  const push=runDialogue(later,'rel-su-estranged',2)
  assert.equal(push.stats.mind,later.stats.mind-6)
  assert.ok(push.loveLife.records.su.trust<later.loveLife.records.su.trust)
  const rebuild=runDialogue({...later,loveLife:{...later.loveLife,records:{su:{stage:'estranged',affection:30,trust:30}}}},'rel-su-estranged',1)
  assert.equal(rebuild.loveLife.records.su.stage,'friend')
})

test('倾听和协作在不同地点有不同加成',()=>{
  const game=ready(at(opening(),'garden'),'su')
  assert.ok(apply(game,'su','listen').loveLife.records.su.affection>apply(at(game,'track'),'su','listen').loveLife.records.su.affection)
  assert.ok(apply(at(game,'lab'),'su','cooperate').loveLife.records.su.affection>apply(game,'su','cooperate').loveLife.records.su.affection)
})

test('知情开放取决于双方边界，瞒着现任会积累风险并触发可存档冲突',()=>{
  let game=ready(at(opening('female'),'track'),'yan')
  game=apply(game,'yan','open')
  game=ready(at(game,'workshop'),'lu')
  assert.ok(rows(game,'lu').some(item=>item.id==='rel-lu-open'))
  const consensual=runDialogue(game,'rel-lu-open',0)
  assert.deepEqual(currentPartners(consensual),['yan','lu'])
  assert.equal(consensual.loveLife.risk,0)
  const refusal=apply(ready(game,'ji'),'ji','open')
  assert.equal(refusal.loveLife.records.ji.stage,'interested')
  const semesterTwo={...opening('female'),term:1,grades:[{score:65,grade:'通过'}]}
  const exclusive=apply(ready(at(semesterTwo,'track'),'yan'),'yan','exclusive')
  const hidden=runDialogue(ready(at(exclusive,'workshop'),'lu'),'rel-lu-secret',0)
  assert.ok(hidden.loveLife.risk>0)
  const beforeExam={...hidden,moves:3,loveLife:{...hidden.loveLife,risk:100}}
  const exposed=finishTerm(beforeExam)
  assert.equal(exposed.pending[0],'rel-yan-conflict')
  assert.equal(exposed.grades.length,1)
  assert.equal(restoreGame(JSON.parse(JSON.stringify(exposed))).pending[0],'rel-yan-conflict')
  const separated=choose(exposed,1)
  assert.equal(separated.loveLife.records.yan.stage,'estranged')
  assert.equal(separated.loveLife.risk,0)
  assert.equal(finishTerm(separated).term,2)
})

test('带对象的实习主线会更新信任，无对象走普通对白，旧版第三个回复也能读档',()=>{
  const none={...opening('female'),selected:'hospital',term:7,grades:Array.from({length:7},()=>({score:85,grade:'通过'})),pending:['term-7']}
  assert.doesNotMatch(currentStory(none).text,/下次见面/)
  const dating=apply(ready(none,'yan'),'yan','exclusive')
  const after=choose(dating,0)
  assert.equal(after.loveLife.records.yan.trust,dating.loveLife.records.yan.trust+8)
  const legacy={...none,identity:undefined,loveLife:undefined,relationship:'dating',pending:[],reply:{storyId:'term-7',choice:2}}
  assert.equal(restoreGame(JSON.parse(JSON.stringify(legacy))).reply.choice,2)
})

test('两种主角皆可在真实选项中走完十学期，伴侣安排进入结局后记',()=>{
  for(const [gender,id] of [['male','su'],['female','yan']]){
    let game=Array.from({length:200},(_,seed)=>at(opening(gender,seed),'track')).find(state=>rows(state,id).length)
    assert.ok(game)
    game=runDialogue(game,rows(game,id)[0].id,1)
    game=runDialogue(game,'rel-'+id+'-grow',1)
    for(let term=0;term<10;term++){
      game=drain(game)
      if(term===1){
        game=at(game,'track')
        game=runDialogue(game,'rel-'+id+'-grow',1)
        game=runDialogue(game,'rel-'+id+'-single',0)
        assert.deepEqual(currentPartners(game),[id])
      }
      while(game.moves<3){
        const next=drain(act(selectLocation(game,game.moves===2?'dorm':'library'),0))
        assert.notEqual(next,game)
        game=next
      }
      game=drain(finishTerm(game))
    }
    assert.equal(game.grades.length,10)
    assert.ok(game.ending)
    assert.match(endingEpilogue(game),new RegExp('测试 同学和'+people[id].name))
  }
})

test('单人、多方知情、关系破裂和单身进入不同毕业结局',()=>{
  const graduate={...opening('female'),term:9,stats:{...opening('female').stats,study:85},grades:Array.from({length:10},()=>({score:85,grade:'通过'}))}
  assert.equal(getEnding(graduate),'ordinary')
  const one=apply(ready(graduate,'yan'),'yan','exclusive')
  assert.equal(getEnding(one),'campusLove')
  const open=apply(apply(one,'yan','renegotiate'),'yan','quality')
  const multi=apply(ready(open,'lu'),'lu','open','quality')
  assert.equal(getEnding(multi),'honestLove')
  assert.equal(getEnding(apply(one,'yan','end')),'brokenTrust')
})
